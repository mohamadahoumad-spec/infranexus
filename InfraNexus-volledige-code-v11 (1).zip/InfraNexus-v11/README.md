# InfraNexus — portaal en centrale werkruimte

Het InfraNexus-portaal bevat de bestaande conceptomgeving en een centrale beveiligde werkruimte voor **InfraNexus Veiligheid & Milieu**. De uitbreiding van versie 10 staat beschreven in [PORTAAL-V10.md](docs/PORTAAL-V10.md): projectdossiers, verwachte daglogboeken, overdrachten, acties, voortgang, exports en persoonlijke accountuitnodigingen. Bestaande werkstromen en lokale dossiers blijven behouden.

- `/`: bestaande conceptomgeving met voorbeeldrollen en opslag op het eigen apparaat.
- `/werkruimte`: inlogscherm met **Professional**, **Kantoor** en **Klant**, persoonlijke login, serverrechten en centrale D1/R2-opslag; begint zonder voorbeeldrecords.
- `/uitnodiging`: eenmalige accountactivering voor het vooraf ingerichte e-mailadres en dossier.

De eigenaar activeert één keer de hoofdadmin met de afzonderlijke activeringslink. Daarna: **Accounts beheren → Account inrichten → Uitnodigen**. De uitnodigingsmail wordt vanuit de eigen mailbox verstuurd. De rol en dossierkoppeling staan vooraf vast. De startkeuze geeft geen extra rechten; een al aangemeld account wordt naar zijn toegewezen omgeving geleid. Aanmelden verloopt in de huidige hosting via ChatGPT met het uitgenodigde e-mailadres. Een zelfstandige e-mail/wachtwoordlogin is niet toegevoegd.

## De bedrijfsroute

**Klantaanvraag → HR / Planning-controle → raamovereenkomst → inzet → logboek → factuur.**

- Nieuwe werkzaamheden hebben een eigen naam, datums, opgegeven veiligheidsklasse en optioneel V&G-plan.
- HR / Planning accepteert, vraagt aanvulling of wijst gemotiveerd af. Een geaccepteerde aanvraag maakt één project en koppelt het contractdossier.
- Geldige, gecontroleerd ondertekende raamovereenkomsten worden hergebruikt. Anders ontstaat een conceptdossier. PDF-versies, gedeelde versies, ondertekende retourbestanden en beoordelingen blijven bewaard.
- Planning controleert per geselecteerde dag contractlooptijd, aangevraagde werkdagen, vrijgave, kwalificaties, expliciete onbeschikbaarheid en dubbele inzet. Een ontbrekende maandopgave geeft alleen een waarschuwing en blokkeert de inzet niet. Andere ongeldige dagen blokkeren de hele batch.
- De weekmatrix laat meerdere vrije dagen voor één professional aanvinken. Werktijden zijn aanpasbaar; annulering behoudt de oorspronkelijke inzet in de historie.
- HR uploadt het lege klantlogboek. De professional downloadt en vult het in, dient voor een eigen werkdag in en krijgt gerichte correcties terug. De klant ziet alleen goedgekeurde versies. Bestaande digitale registraties blijven toegankelijk.
- VCA en andere certificaten blijven na upload in de HR-wachtrij. Goedkeuring werkt het dossier bij; klantdeling is een afzonderlijke bewuste keuze.
- Het berichtencentrum heeft een herkenbare gesprekkenlijst, een duidelijke ontvanger/afdeling, berichtenballonnen en leesmarkeringen. Klant en professional hebben ieder een eigen lijn met het team; interne gesprekken zijn beperkt tot de deelnemers.
- Zzp-facturen gaan via HR naar Finance. Klantfacturen zijn alleen zichtbaar voor de eigen organisatie na expliciet delen.
- HR-dossiers bevatten telefoon, zzp-bedrijf, KvK en een privé-CV. Klantrelatiebeheer en Business Development blijven beschikbaar.

De huisstijl gebruikt een donkerblauwe zijbalk, oranje accenten, lichte contentvlakken en contrastrijke donkerblauwe tekst. Het bestaande logo is van de buitenste achtergrond ontdaan. Het afzonderlijke beeldmerk wordt gebruikt waar weinig ruimte is; klantlogo’s kunnen naast InfraNexus worden gezet.

## Beoordelen

Open de gepubliceerde Site en kies rechtsboven een **voorbeeldrol**. De demodatum is **6 oktober 2026**; alle basisgegevens zijn fictief.

- Klant: maak een nieuwe aanvraag en volg de terugkoppeling.
- HR / supervisor: richt bij **Accounts beheren** een account en bedrijfsgegevens in en upload de vooraf ondertekende hoofdraamovereenkomst.
- Klant: lever eventueel zelf een ondertekende PDF aan; HR beoordeelt de upload voordat hij actief wordt.
- HR / Planning: controleer de aanvraag en stel de digitale opdrachtafspraak met verwachte kosten op.
- Klant: open de directe melding van de opdrachtbevestiging en accepteer de actuele opdracht conform de hoofdraamovereenkomst.
- InfraNexus: verstuur de definitieve bevestiging zelf per mail en registreer de verzending, eventueel met geplakte tekst en PDF’s.
- Planning: bied meerdere dagen tegelijk aan de professional aan. Na diens akkoord en geregistreerde definitieve mail wordt de inzet bevestigd.
- Professional: geef per maand de eigen beschikbaarheid door, bekijk de inzet en lever het ingevulde klantlogboek in.
- HR: beoordeel logboeken en certificaten. Bekijk als klant welke bestanden daadwerkelijk gedeeld zijn.

Zie `docs/WERKRUIMTE-V2.md` voor de rollen en de uitgewerkte scenario’s.

## Opslag en grenzen

De conceptomgeving bewaart bestaande gegevens op het eigen apparaat. De centrale werkruimte bewaart records in D1 en bestanden in R2, met persoonlijke lidmaatschappen en autorisatie op iedere API- en bestandsaanvraag. De voorbeeldrolwisselaar bestaat uitsluitend in de conceptomgeving. Gegevens worden niet automatisch tussen deze omgevingen gekopieerd; bestaande browsergegevens blijven beschikbaar voor een gecontroleerde migratie.

Host het benodigde geheime `INFRANEXUS_SETUP_TOKEN` via de platforminstellingen; zet nooit een waarde in Git of een clientbundle. De eerste inrichting vereist de eenmalige eigenaarlink. Nieuwe uitnodigingen zijn zeven dagen geldig, worden gehasht opgeslagen en kunnen worden ingetrokken. De migraties bevatten geen bedrijfsrecords of testaccounts.

Definitieve mails worden handmatig verstuurd. Er is geen automatische externe noodmelding, bankbetaling of boekhoudkoppeling. Zie de versie-10-documentatie voor de rollen, migratie en resterende verificatiegrenzen.

## Ontwikkelen en controleren

Node.js 22.18 of nieuwer en de vastgelegde pnpm-versie:

```bash
pnpm install --frozen-lockfile
pnpm dev
pnpm exec tsc --noEmit
pnpm test
pnpm test:render
pnpm build
```

De verificatie omvat 85 domeintests en 22 serverrendercontroles. Opdrachtbevestigings-PDF’s met het logo zijn visueel gecontroleerd. Rendercontroles vervangen geen interactieve browseracceptatie; de browserpreview was in deze werkronde niet beschikbaar.

## Code

| Bestand | Verantwoordelijkheid |
|---|---|
| `components/portal/app.tsx` | Nieuwe shell, rolkeuze, navigatie, zoeken en opslaan |
| `components/portal/overview.tsx` | Werkoverzicht, aanvragen, raamovereenkomsten en projecten |
| `components/portal/work.tsx` | Weekplanning, maandopgave, logboeken en projectdocumenten |
| `components/portal/people.tsx` | Professionals, kandidaten en certificaatcontrole |
| `components/portal/messages.tsx` | Berichtencentrum |
| `components/portal/administration.tsx` | Financiën, klantrelaties, profiel en rechtenoverzicht |
| `components/portal/forms.tsx` | De nieuwe invoerflows en bestandsvoorbeeldweergave |
| `lib/portal.ts` | Contractversies, aanvraagcontrole, planning en migratie |
| `lib/portal-storage.ts` | Lokale IndexedDB-opslag |
| `lib/operations.ts` | Bestaande gedeelde dossier- en factuurregels |
| `public/brand/` | Oorspronkelijke en transparante merkbestanden |

Eerdere schermmodules zijn als bronreferentie behouden, maar maken geen deel uit van de actieve navigatie of applicatiebundel. De bestaande Sites-identiteit en het bestaande publiek zijn behouden.

## Contracten en online akkoord (versie 6)

Zie [CONTRACTEN-V6.md](docs/CONTRACTEN-V6.md) voor het onderscheid tussen eenmalige basisovereenkomsten en opdrachtbevestigingen, bedragen inclusief/exclusief btw, acceptatiebewijs, mailwachtrij en de juridische/productiegrens.

## Zichtbaar akkoord en handmatige HR-mail (versie 7)

Zie [PORTAAL-V7.md](docs/PORTAAL-V7.md) voor de directe offerteactie op project en aanvraag, HR-upload van vooraf ondertekende raamovereenkomsten, bedrijfsgegevens, handmatige mailbevestiging en logboekcontrole binnen 48 uur.

## Accountinrichting en contractdossiers (versie 8)

Zie [PORTAAL-V8.md](docs/PORTAAL-V8.md) voor de twaalf gevraagde verbeteringen, HR-certificaatupload, juridische uitgangspunten, testresultaten en productiegrenzen. Accountbeheer configureert de demo; echte beveiligde gebruikersaanmelding en centrale serverrechten zijn nog niet aangesloten.

## Opdrachtbevestiging en dagbestanden (versie 9)

Zie [PORTAAL-V9.md](docs/PORTAAL-V9.md) voor de nieuwe benamingen en akkoordverklaring, opeenvolgende bijlagenselecties, het V&G-plan bij de zzp-opdrachtmail, medische keuringen A/B en C, btw-gegevens, meerdere dagelijkse documenten/foto’s en sjablonen op bedrijfsniveau met een projectafwijking.
