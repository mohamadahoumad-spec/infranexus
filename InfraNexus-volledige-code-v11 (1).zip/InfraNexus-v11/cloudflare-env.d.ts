declare namespace Cloudflare {
  interface Env {
    INFRANEXUS_SETUP_TOKEN?:string;
    DB?: D1Database;
    BUCKET?: R2Bucket;
  }
}
