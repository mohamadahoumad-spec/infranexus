import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "InfraNexus | Veiligheid & Milieu | Werkruimte",
  description: "Het operationele platform van InfraNexus Veiligheid & Milieu. Interactieve blauwdruk voor backoffice, professionals en klanten.",
  icons: {
    icon: "/brand/mark-v2.png",
    shortcut: "/brand/mark-v2.png",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="nl">
      <body className="antialiased">{children}</body>
    </html>
  );
}
