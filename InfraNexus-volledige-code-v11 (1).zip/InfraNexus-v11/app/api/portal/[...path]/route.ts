import {servePortal} from '@/lib/portal-server';
export const dynamic='force-dynamic';
export const GET=servePortal;
export const POST=servePortal;
