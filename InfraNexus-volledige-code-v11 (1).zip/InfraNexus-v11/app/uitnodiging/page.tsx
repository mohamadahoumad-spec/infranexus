import {SecureEntry} from '@/components/portal/secure-entry';
export const dynamic='force-dynamic';
export default function Invitation(){return <SecureEntry/>;}
