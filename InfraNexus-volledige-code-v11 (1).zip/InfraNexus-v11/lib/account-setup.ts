import {accounts,canReview,canManage,isCustomer,isProfessional,uid,type Account,type DemoState,type Role} from './demo.ts';
import type {PortalState} from './portal.ts';
import type {ContractParty,PortalAccount} from './workflow-types.ts';
import {saveCompanyDetails} from './contracts.ts';
const need=(v:unknown,m:string)=>{if(!v)throw Error(m);};
const now=()=>new Date().toISOString();
export const accountId=(a:Account)=>a.userId||a.professionalId||a.customerId||a.role;
export function initialPortalAccounts(s:DemoState):PortalAccount[]{
 const all:Account[]=[...accounts.filter(a=>a.role!=='ACADEMY BEHEER'),...s.professionals.filter(p=>!accounts.some(a=>a.professionalId===p.id)).map(p=>({role:'PROFESSIONAL' as const,name:p.name,initials:p.initials,professionalId:p.id})),...s.customers.filter(c=>c.status==='Actieve klant'&&!accounts.some(a=>a.customerId===c.id)).map(c=>({role:'KLANT ADMIN' as const,name:c.contact||c.name,initials:c.name.slice(0,2),customerId:c.id}))];
 return all.map(a=>{const id='account-'+accountId(a);return {...a,id,userId:id,email:a.customerId?s.customers.find(c=>c.id===a.customerId)?.email||'':a.professionalId?s.professionals.find(p=>p.id===a.professionalId)?.email||'':'',status:'Ingericht',createdBy:'Bestaande inrichting',createdAt:'2026-10-06T00:00:00Z'};});
}
export const canSetupAccounts=(a:Account)=>canReview(a);
export function assignableRoles(a:Account):Role[]{return canManage(a)?['KLANT ADMIN','KLANT GEBRUIKER','PROFESSIONAL','HR','PLANNING','SUPERVISOR','CUSTOMER SUPPORT','FINANCIEEL','BUSINESS DEVELOPMENT','ADMIN',...(a.role==='SUPER ADMIN'?['SUPER ADMIN' as const]:[])]:canReview(a)?['KLANT ADMIN','KLANT GEBRUIKER','PROFESSIONAL']:[];}
export function provisionAccount(s:PortalState,a:Account,input:{id?:string;role:Role;name:string;email:string;customerId?:string;professionalId?:string;company?:ContractParty;city?:string;professionalRole?:string;projectIds?:string[]}):PortalState {
 need(canSetupAccounts(a),'Alleen HR, supervisor of beheer kan accounts inrichten.');
 const old=s.portalAccounts.find(x=>x.id===input.id);
 need(!input.id||old,'Account ontbreekt.');
 need(assignableRoles(a).includes(input.role)&&(!old||assignableRoles(a).includes(old.role)),'Je mag deze accountrol niet toewijzen of wijzigen.');
 need(input.name.trim()&&/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(input.email),'Vul een naam en geldig e-mailadres in.');
 need(!s.portalAccounts.some(x=>x.id!==input.id&&x.email.toLowerCase()===input.email.trim().toLowerCase()),'Voor dit e-mailadres bestaat al een account.');
 if(old)need(old.role===input.role&&old.customerId===input.customerId&&old.professionalId===input.professionalId,'Een bestaand account blijft bij dezelfde rol en hetzelfde dossier. Maak voor een andere rol een afzonderlijk account.');
 need(!input.projectIds||canManage(a)&&!['PROFESSIONAL','KLANT ADMIN','KLANT GEBRUIKER','SUPER ADMIN'].includes(input.role)&&input.projectIds.every(id=>s.projects.some(p=>p.id===id)),'Alleen beheer kan geldige interne projectbeperkingen instellen.');let next=s,customerId=input.customerId,professionalId=input.professionalId;
 if(isCustomer({role:input.role,name:'',initials:''})){
  if(!customerId){need(input.company?.name.trim(),'Vul de klantonderneming in.');customerId=uid();next={...next,customers:[{id:customerId,name:input.company!.name,contact:input.company!.contact,email:input.company!.email,phone:input.company!.phone||'',address:input.company!.address,city:input.city||'',kvk:input.company!.kvk,vatNumber:input.company!.vatNumber,status:'Actieve klant',notes:''},...next.customers]};}
  need(next.customers.some(c=>c.id===customerId),'Kies een klantdossier.');
  need(!professionalId,'Een klantaccount kan geen professionaldossier hebben.');
  if(input.company)next=saveCompanyDetails(next,a,'customer',customerId!,input.company);
 }else if(input.role==='PROFESSIONAL'){
  if(!professionalId){professionalId=uid();next={...next,professionals:[{id:professionalId,name:input.name,initials:input.name.trim().split(/\s+/).map(x=>x[0]).slice(0,2).join(''),email:input.email,phone:input.company?.phone||'',city:input.city||'',role:input.professionalRole||'DLP',company:input.company?.name||'',kvk:input.company?.kvk||'',vatNumber:input.company?.vatNumber,address:input.company?.address,status:'Vrijgegeven',quality:'Oranje',certificates:[]},...next.professionals]};}
  need(next.professionals.some(p=>p.id===professionalId),'Kies een professionaldossier.');need(!customerId,'Een professionalaccount kan geen klantdossier hebben.');
  need(!next.portalAccounts.some(x=>x.id!==input.id&&x.professionalId===professionalId),'Deze professional heeft al een account.');
  if(input.company)next=saveCompanyDetails(next,a,'professional',professionalId!,input.company);
 }else need(!customerId&&!professionalId,'Een teamaccount wordt niet aan een extern dossier gekoppeld.');
 const id=old?.id||uid();const record:PortalAccount={...old,id,userId:id,role:input.role,name:input.name.trim(),email:input.email.trim().toLowerCase(),initials:input.name.trim().split(/\s+/).map(x=>x[0]).slice(0,2).join(''),customerId,professionalId,projectIds:canManage(a)?input.projectIds:old?.projectIds,status:old?.status||'Ingericht',createdBy:old?.createdBy||a.name,createdAt:old?.createdAt||now(),updatedBy:a.name,updatedAt:now()};
 return {...next,portalAccounts:[record,...next.portalAccounts.filter(x=>x.id!==id)]};
}
export function changeAccountStatus(s:PortalState,a:Account,id:string,status:PortalAccount['status']):PortalState {
 const record=s.portalAccounts.find(x=>x.id===id);need(canSetupAccounts(a)&&record&&assignableRoles(a).includes(record.role),'Je mag dit account niet beheren.');
 need(id!==a.userId&&!(record!.role===a.role&&record!.name===a.name&&!a.userId),'Je kunt je eigen actieve account niet blokkeren.');need(!(status==='Geblokkeerd'&&record!.role==='SUPER ADMIN'&&s.portalAccounts.filter(x=>x.role==='SUPER ADMIN'&&x.status==='Ingericht').length<=1),'Het laatste superbeheeraccount kan niet worden geblokkeerd.');
 return {...s,portalAccounts:s.portalAccounts.map(x=>x.id===id?{...x,status,updatedBy:a.name,updatedAt:now()}:x)};
}
export function demoPortalAccounts(s:PortalState):Account[]{
 const existing=initialPortalAccounts(s),seen=new Set(s.portalAccounts.map(a=>`${a.role}|${a.customerId||a.professionalId||a.name}`));
 return [...s.portalAccounts.filter(a=>a.status==='Ingericht'),...existing.filter(a=>!seen.has(`${a.role}|${a.customerId||a.professionalId||a.name}`))];
}

export function ensurePortalAccounts(s:PortalState):PortalState{const added=initialPortalAccounts(s).filter(a=>(s.production?(!!a.customerId&&s.customers.some(c=>c.id===a.customerId)||!!a.professionalId&&s.professionals.some(p=>p.id===a.professionalId)):(a.customerId||a.professionalId))&&!s.portalAccounts.some(x=>a.professionalId?x.professionalId===a.professionalId:x.customerId===a.customerId));return added.length?{...s,portalAccounts:[...s.portalAccounts,...added]}:s;}
