import type {Account,Role} from './demo.ts';
import type { FileAsset } from './operations-types.ts';
export type PortalAccount = Account & {id:string;email:string;status:'Ingericht'|'Geblokkeerd';createdBy:string;createdAt:string;updatedBy?:string;updatedAt?:string};
export type ContractSubmission = {id:string;customerId:string;file:FileAsset;termsFile?:FileAsset;from:string;until:string;signedOn:string;status:'Ter controle'|'Goedgekeurd'|'Afgewezen';by:string;at:string;reviewedBy?:string;reviewedAt?:string;note?:string;agreementId?:string;agreementVersion?:number};
export type ManualMailEvidence = {revisions?:{by:string;at:string;body?:string;attachments?:FileAsset[];visibleToRecipient?:boolean}[];body?:string;attachments?:FileAsset[];visibleToRecipient?:boolean};
export type Acceptance = {
    actorId?:string;
    by: string;
    role: string;
    partyId: string;
    at: string;
    version: number;
    declaration: string;
    documentNumber?: string;
    email?: string;
    receipt?: FileAsset;
};
export type ContractParty = { name: string; kvk: string; vatNumber?: string; phone?: string; address: string; contact: string; email: string };
export type BaseContractDetails = {
    issuer: ContractParty;
    recipient: ContractParty;
    clauses: string;
    source: 'Gegenereerd concept' | 'Eigen contracttekst';
    releasedBy?: string;
    releasedAt?: string;
};
export type OnlineBase = { registered?: {by:string;at:string;signedOn:string;note:string}; termsFile?:FileAsset; acceptance?: Acceptance; details?: BaseContractDetails; response?: string };
export type ContractMail = {
    id: string; recordId: string; version: number; kind: 'basis' | 'opdracht';
    party: 'customer' | 'professional'; partyId: string; to: string; subject: string;
    at: string; status: 'Wacht op mailkoppeling' | 'Te versturen door HR' | 'Handmatig verzonden'; files: FileAsset[];
    manual?: ManualMailEvidence & {by:string;recordedAt:string;sentAt:string;to:string;note:string};
};
export type Cooperation = {
    id: string;
    professionalId: string;
    number: string;
    versions: (OnlineBase & {
        version: number;
        file: FileAsset;
        from: string;
        until: string;
        by: string;
        at: string;
        sharedAt?: string;
        returns: {
            file: FileAsset;
            proof?: FileAsset;
            by: string;
            at: string;
            status: 'Ingediend' | 'Goedgekeurd' | 'Afgekeurd';
            note?: string;
            reviewedBy?: string;
            reviewedAt?: string;
        }[];
    })[];
};
export type OrderTerms = {
    requestId?: string;
    projectId: string;
    party: 'customer' | 'professional';
    customerId: string;
    professionalId?: string;
    dates: string[];
    start: string;
    end: string;
    breakMinutes: number;
    expectedHoursPerDay: number;
    rateCents: number;
    unit: 'uur' | 'dag' | 'project';
    vat?: '21' | '9' | '0' | 'verlegd' | 'vrijgesteld';
    vatNote?: string;
    supplementCents?: number;
    travelCents?: number;
    supplements: string;
    travel: string;
    billing: string;
    cancellation: string;
    notes: string;
    agreementId: string;
    agreementVersion: number;
    assignmentIds: string[];
};
export type OrderVersion = OrderTerms & {
    projectFiles?: FileAsset[];
    pricingVersion?: 1; manualMailRequired?: boolean;
    snapshot?: { issuer: ContractParty; recipient: ContractParty; projectName: string; projectNumber: string; address: string; role: string; description: string; safetyClass: string; contact: string };
    version: number;
    file: FileAsset;
    createdAt: string;
    createdBy: string;
    status: 'Concept' | 'Ter acceptatie' | 'Wijziging gevraagd' | 'Afgewezen' | 'Geaccepteerd' | 'Definitief bevestigd' | 'Vervangen';
    sharedAt?: string;
    acceptance?: Acceptance;
    response?: string;
    confirmedBy?: string;
    confirmedAt?: string;
};
export type Order = {
    id: string;
    number: string;
    versions: OrderVersion[];
};
export type HourRevision = {
    version: number;
    start: string;
    end: string;
    breakMinutes: number;
    expectedHours: number;
    actualHours: number;
    reason: string;
    note: string;
    customerNote: string;
    submittedAt: string;
    submittedBy: string;
    status: 'Ingediend' | 'Aanvulling gevraagd' | 'Klantcontrole' | 'Goedgekeurd' | 'Gedeeltelijk goedgekeurd' | 'Betwist';
    approvedHours?: number;
    billableHours?: number;
    payableHours?: number;
    reviewNote?: string;
    reviewedBy?: string;
    reviewedAt?: string;
    customerResponse?: {
        action: 'Bevestigd' | 'Vraag' | 'Afwijking';
        note: string;
        by: string;
        at: string;
    };
    finance?: {
        by: string;
        at: string;
        billingCents: number;
        payableCents: number;
        note: string;
    };
};
export type HoursEntry = {
    id: string;
    assignmentId: string;
    projectId: string;
    professionalId: string;
    date: string;
    versions: HourRevision[];
};
export type WeeklyLog = {
    id: string;
    projectId: string;
    week: string;
    revision: number;
    files: {
        logId: string;
        version: number;
    }[];
    status: 'Ter controle' | 'Opmerking' | 'Ontvangen en gecontroleerd';
    sharedBy: string;
    sharedAt: string;
    closingAt?:string; availableAt?:string; dueAt?:string; closingReason?:string;
    response?: {
        by: string;
        at: string;
        note: string;
    };
    deliveryId?: string;
};
export type Delivery = {
    id: string;
    projectId: string;
    weeklyId: string;
    to: string;
    subject: string;
    status: 'Wacht op mailkoppeling' | 'Afgeleverd' | 'Te versturen door HR' | 'Handmatig verzonden';
    files?:FileAsset[]; manual?:ManualMailEvidence & {by:string;recordedAt:string;sentAt:string;to:string;note:string};
    createdAt: string;
    deliveredAt?: string;
    providerId?: string;
    purgedAt?: string;
};
export type WorkflowState = {
    portalAccounts:PortalAccount[];
    contractSubmissions:ContractSubmission[];
    companyDetails: {party:'issuer'|'customer'|'professional';partyId:string;details:ContractParty}[];
    cooperations: Cooperation[];
    orders: Order[];
    hourEntries: HoursEntry[];
    weeklyLogs: WeeklyLog[];
    deliveries: Delivery[];
    notificationReads: {
        id: string;
        actor: string;
        at: string;
    }[];
    retention: {
        customerId: string;
        mode: 'Bewaren' | 'Na aflevering verwijderen';
    }[];
    contractMails: ContractMail[];
};
export const emptyWorkflow = (): WorkflowState => ({ portalAccounts:[], contractSubmissions:[], companyDetails: [], cooperations: [], orders: [], hourEntries: [], weeklyLogs: [], deliveries: [], notificationReads: [], retention: [], contractMails: [] });
