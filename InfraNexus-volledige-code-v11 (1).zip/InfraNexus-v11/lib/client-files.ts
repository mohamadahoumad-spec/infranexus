'use client';
export function readLocalFile(file: File): Promise<string> {
    return new Promise((resolve, reject) => { const reader = new FileReader(); reader.onload = () => resolve(String(reader.result)); reader.onerror = () => reject(new Error('Het bestand kon niet worden gelezen.')); reader.readAsDataURL(file); });
}
/** Resize only demo logbook photos; PDF/certificate originals are never recompressed. */
export async function prepareLogPhoto(file: File): Promise<{
    name: string;
    url: string;
    caption: string;
}> {
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type))
        throw new Error('Gebruik een JPG, PNG of WebP.');
    if (file.size > 12 * 1024 * 1024)
        throw new Error('Een foto mag maximaal 12 MB zijn.');
    const source = await readLocalFile(file);
    const img = new Image();
    await new Promise<void>((resolve, reject) => { img.onload = () => resolve(); img.onerror = () => reject(new Error('Deze afbeelding kon niet worden geopend.')); img.src = source; });
    const scale = Math.min(1, 1600 / Math.max(img.naturalWidth, img.naturalHeight));
    const canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.round(img.naturalWidth * scale));
    canvas.height = Math.max(1, Math.round(img.naturalHeight * scale));
    const ctx = canvas.getContext('2d');
    if (!ctx)
        throw new Error('Fotoverwerking is niet beschikbaar.');
    ctx.fillStyle = '#fff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
    let quality = .86;
    let url = canvas.toDataURL('image/jpeg', quality);
    while (url.length > 950000 && quality > .42) {
        quality -= .1;
        url = canvas.toDataURL('image/jpeg', quality);
    }
    if (url.length > 1100000)
        throw new Error('Kies een kleinere foto; deze afbeelding is te groot voor de demo-opslag.');
    return { name: file.name.replace(/\.[^.]+$/, '.jpg'), url, caption: '' };
}
