import {TODAY} from './demo.ts';
export function workspaceDate(state?:{production?:boolean}){return state&&!state.production?TODAY:new Intl.DateTimeFormat('sv-SE',{timeZone:'Europe/Amsterdam'}).format(new Date());}
export function addDays(date:string,days:number){const d=new Date(date+'T12:00:00Z');d.setUTCDate(d.getUTCDate()+days);return d.toISOString().slice(0,10);}
