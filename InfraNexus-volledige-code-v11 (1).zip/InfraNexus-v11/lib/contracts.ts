import {uniqueFiles} from './file-bundles.ts';
import { canReview, isProfessional, uid, type Account } from './demo.ts';
import { demoPdf, type PortalState, type Agreement } from './portal.ts';
import {sortedDates} from './operations.ts';
import { baseAccepted, baseDeclaration } from './contract-utils.ts';
import type { BaseContractDetails, ContractParty, ContractMail, Acceptance, OrderTerms } from './workflow-types.ts';
import type { FileAsset } from './operations-types.ts';
const need = (v: unknown, message: string) => { if (!v) throw Error(message); };
const now = () => new Date().toISOString();
export const baseClauses = `1. Deze basisovereenkomst regelt de langdurige samenwerking met InfraNexus Veiligheid & Milieu. Een afzonderlijke opdracht ontstaat door het online accepteren van de bijbehorende opdrachtbevestiging door een bevoegde vertegenwoordiger.
2. Per opdracht worden werkzaamheden, locatie, veiligheidsklasse, benodigde dagen, verwachte werktijden en uren, tariefeenheid, tarief, verwachte kosten en btw vastgelegd. Deze basisovereenkomst garandeert geen opdrachten of minimumaantal uren.
3. Verwachte inzet is een raming. Afwijkingen worden gemeld en geregistreerd. Meerwerk, aanvullende kosten en wijzigingen in de afspraken worden vooraf afgestemd en zo nodig in een nieuwe opdrachtversie ter acceptatie aangeboden. Werkelijke uren en de toepasselijke afspraken vormen de basis voor afrekening; een interne controle wijzigt bestaande betalingsrechten niet eenzijdig.
4. De klant levert de relevante locatie- en veiligheidsinformatie aan. Voor uitvoering gelden de toepasselijke wetgeving, het projectplan en de afgesproken kwalificaties. Een online akkoord vervangt geen veiligheidscontrole.
5. De partijen werken de afspraken over aansprakelijkheid, verzekering, beëindiging, opzegtermijn, betaling, privacy, geheimhouding, geschillen en toepasselijk recht vóór gebruik in deze tekst uit. Voor ZZP-samenwerking moeten ook de feitelijke zelfstandigheid en werkwijze afzonderlijk worden beoordeeld.
6. De partijen kunnen de vastgelegde versies en acceptatiebewijzen downloaden. Wijzigingen worden als nieuwe versie aangeboden; eerdere akkoordregistraties blijven bewaard.`;
export function partyDetails(s: PortalState, party: 'customer'|'professional', id: string): ContractParty {
    const c = s.customers.find(c => c.id === id), p = s.professionals.find(p => p.id === id);
    return party === 'customer' ? {name:c?.name || '',kvk:c?.kvk || '',vatNumber:c?.vatNumber || '',phone:c?.phone || '',address:c?.address || c?.city || '',contact:c?.contact || '',email:c?.email || ''} : {name:p?.company || p?.name || '',kvk:p?.kvk || '',vatNumber:p?.vatNumber || '',phone:p?.phone || '',address:p?.address || p?.city || '',contact:p?.name || '',email:p?.email || ''};
}
export function contractDetails(s:PortalState, t:OrderTerms) {
    return t.party === 'customer' ? s.agreements.find(g=>g.id===t.agreementId)?.versions.find(v=>v.version===t.agreementVersion)?.details : s.cooperations.find(g=>g.id===t.agreementId)?.versions.find(v=>v.version===t.agreementVersion)?.details;
}
export function issuerDetails(s: PortalState): ContractParty { return s.companyDetails.find(c=>c.party==='issuer')?.details || {name:s.branding.find(b=>b.id==='infranexus')?.name || 'InfraNexus Veiligheid & Milieu',kvk:'',address:'',contact:'',email:''}; }
function partyLines(label:string,p:ContractParty) { return [`${label}: ${p.name}`,`KvK: ${p.kvk || 'Nog aan te vullen'} | Adres: ${p.address || 'Nog aan te vullen'}`,`Vertegenwoordiger: ${p.contact} | E-mail: ${p.email}`]; }
export function createBaseContract(s:PortalState,a:Account,party:'customer'|'professional',partyId:string,from:string,until:string,details:BaseContractDetails,file?:FileAsset):PortalState {
    need(canReview(a),'Alleen HR / Admin beheert basisovereenkomsten.');
    need(party==='customer' ? s.customers.some(c=>c.id===partyId) : s.professionals.some(p=>p.id===partyId),'Selecteer de juiste contractpartij.');
    need(/^\d{4}-\d{2}-\d{2}$/.test(from) && until>=from,'Controleer de looptijd.');
    need(details.recipient.name.trim() && details.issuer.name.trim() && (file || details.clauses.trim()),'Vul partijen en contracttekst in.');
    need(!file || file.mime==='application/pdf','Voeg de eigen contracttekst als PDF toe.');
    const old = party==='customer' ? s.agreements.find(g=>g.customerId===partyId) : s.cooperations.find(c=>c.professionalId===partyId);
    const version=(old?.versions.length || 0)+1, number=old?.number || `${party==='customer'?'RAAM':'ZZP'}-${new Date().getFullYear()}-${String((party==='customer'?s.agreements:s.cooperations).length+1).padStart(3,'0')}`;
    const clean:BaseContractDetails={issuer:{...details.issuer},recipient:{...details.recipient},clauses:details.clauses,source:file?'Eigen contracttekst':'Gegenereerd concept'};
    const document=file || demoPdf(`${number} v${version}`,['BASISOVEREENKOMST - CONCEPT VOOR JURIDISCHE BEOORDELING',...partyLines('Partij 1',clean.issuer),...partyLines('Partij 2',clean.recipient),`Looptijd: ${from} t/m ${until}`,clean.clauses,'Deze modeltekst is niet juridisch gecertificeerd. Laat de volledige overeenkomst en feitelijke werkwijze beoordelen voor zakelijk gebruik.']);
    const v={version,file:document,from,until,by:a.name,at:now(),details:clean};
    if(party==='customer'){
        const g:Agreement={id:old?.id||uid(),number,customerId:partyId,projectIds:s.projects.filter(p=>p.customerId===partyId).map(p=>p.id),status:'Concept',versions:[...(s.agreements.find(g=>g.id===old?.id)?.versions||[]),{...v,signatures:[]}]};
        return {...s,agreements:[g,...s.agreements.filter(x=>x.id!==g.id)]};
    }
    const c={id:old?.id||uid(),number,professionalId:partyId,versions:[...(s.cooperations.find(c=>c.id===old?.id)?.versions||[]),{...v,returns:[]}]};
    return {...s,cooperations:[c,...s.cooperations.filter(x=>x.id!==c.id)]};
}
export function shareBaseContract(s:PortalState,a:Account,party:'customer'|'professional',id:string,reviewed:boolean):PortalState {
    need(canReview(a),'Alleen HR / Admin deelt basisovereenkomsten.');
    const g=party==='customer'?s.agreements.find(x=>x.id===id):s.cooperations.find(x=>x.id===id),v=g?.versions.at(-1);
    need(v && !v.sharedAt,'Deze versie is al gedeeld of ontbreekt.');need(reviewed,'Controleer de partijgegevens en contracttekst vóór vrijgave.');
    if(v!.details) for(const p of [v!.details.issuer,v!.details.recipient]) need(p.name.trim() && /^\d{8}$/.test(p.kvk) && p.address.trim() && p.contact.trim() && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(p.email),'Vul voor beide partijen naam, KvK (8 cijfers), adres, vertegenwoordiger en geldig e-mailadres in.');
    const publish=<T extends typeof v>(x:T)=>({...x,sharedAt:now(),details:x!.details?{...x!.details,releasedBy:a.name,releasedAt:now()}:undefined});
    const next:PortalState=party==='customer'?{...s,agreements:s.agreements.map(g=>g.id===id?{...g,status:'Ter acceptatie',versions:g.versions.map((v,i)=>i===g.versions.length-1?publish(v):v)}:g)}:{...s,cooperations:s.cooperations.map(g=>g.id===id?{...g,versions:g.versions.map((v,i)=>i===g.versions.length-1?publish(v):v)}:g)};
    const customerId=party==='customer'?s.agreements.find(g=>g.id===id)!.customerId:undefined,professionalId=party==='professional'?s.cooperations.find(c=>c.id===id)!.professionalId:undefined;
    return {...next,notifications:[{id:uid(),title:'Basisovereenkomst ter acceptatie',body:`${g!.number} · versie ${v!.version}`,target:'meldingen',page:'agreements',recordId:id,audience:party,customerId,professionalId,read:false,at:now()},...next.notifications]};
}
export function acceptanceReceipt(number:string,file:FileAsset,acceptance:Acceptance):FileAsset { return demoPdf(`${number} acceptatie v${acceptance.version}`,[`Document: ${file.name}`,`Referentie: ${number} / versie ${acceptance.version}`,`Geaccepteerd door: ${acceptance.by}`,`Accountrol: ${acceptance.role} | Partij: ${acceptance.partyId}`,`Account/e-mail: ${acceptance.email || 'Niet geregistreerd'}`,`Tijdstip (UTC): ${acceptance.at}`,acceptance.declaration,'Registratie in de conceptomgeving. Geen geverifieerde identiteit, server-tijdstempel of elektronische handtekening van een vertrouwensdienst. Bewaar dit bewijs samen met de exacte overeenkomst en bijlagen.']); }
export function queueContractMail(s:PortalState,kind:ContractMail['kind'],recordId:string,version:number,party:'customer'|'professional',partyId:string,to:string,number:string,files:FileAsset[]):PortalState {
    if(s.contractMails.some(m=>m.kind===kind && m.recordId===recordId && m.version===version))return s;
    return {...s,contractMails:[{id:uid(),recordId,version,kind,party,partyId,to,subject:`InfraNexus | Akkoord ${number} v${version}`,at:now(),status:'Te versturen door HR',files},...s.contractMails]};
}
export function acceptBaseContract(s:PortalState,a:Account,party:'customer'|'professional',id:string,version:number,consent:boolean):PortalState {
    const g=party==='customer'?s.agreements.find(g=>g.id===id):s.cooperations.find(c=>c.id===id),v=g?.versions.at(-1);
    const partyId=party==='customer'?s.agreements.find(g=>g.id===id)?.customerId:s.cooperations.find(c=>c.id===id)?.professionalId;
    need(partyId && (party==='customer'?a.role==='KLANT ADMIN' && a.customerId===partyId:isProfessional(a)&&a.professionalId===partyId),'Alleen de bevoegde ontvanger kan deze basisovereenkomst accepteren.');
    need(v && v.sharedAt && v.version===version && !baseAccepted(v),'Deze versie is gewijzigd, niet gedeeld of al geaccepteerd.');need(consent,'Bevestig de voorwaarden en je bevoegdheid.');
    const acceptance:Acceptance={by:a.name,role:a.role,partyId:partyId!,version,at:now(),declaration:baseDeclaration,documentNumber:g!.number,email:v!.details?.recipient.email || partyDetails(s,party,partyId!).email};
    acceptance.receipt=acceptanceReceipt(g!.number,v!.file,acceptance);
    let next:PortalState=party==='customer'?{...s,agreements:s.agreements.map(g=>g.id===id?{...g,status:'Actief',versions:g.versions.map(x=>x.version===version?{...x,acceptance}:x)}:g),projects:s.projects.map(p=>p.customerId===partyId && p.status==='Wacht op overeenkomst' && v!.from<=p.start && v!.until>=p.end?{...p,status:'Planning nodig'}:p)}:{...s,cooperations:s.cooperations.map(c=>c.id===id?{...c,versions:c.versions.map(x=>x.version===version?{...x,acceptance}:x)}:c)};
    next=queueContractMail(next,'basis',id,version,party,partyId!,acceptance.email!,g!.number,[v!.file,acceptance.receipt]);
    return {...next,notifications:[{id:uid(),title:'Basisovereenkomst geaccepteerd',body:`${g!.number} · ${a.name}`,target:'meldingen',page:'agreements',recordId:id,audience:'internal',read:false,at:now()},...next.notifications]};
}
export function contractEmailDraft(m:ContractMail,extra:{attachments?:FileAsset[];body?:string;to?:string}={}) {
    const files=uniqueFiles([...m.files,...(m.manual?.attachments||[]),...(extra.attachments||[])]);
    const safe=(s:string)=>s.replace(/[\r\n"\\]/g,''), boundary='infranexus_'+m.id.replace(/[^a-zA-Z0-9]/g,'');
    return [`To: ${safe(extra.to||m.to)}`,`Subject: ${safe(m.subject)}`,'X-Unsent: 1','MIME-Version: 1.0',`Content-Type: multipart/mixed; boundary="${boundary}"`,'',`--${boundary}`,'Content-Type: text/plain; charset=utf-8','',extra.body||m.manual?.body||'Uw akkoord op de opdrachtbevestiging conform de hoofdraamovereenkomst is geregistreerd. In de bijlagen staan de afspraken, toepasselijke voorwaarden en het acceptatiebewijs. Verwachte inzet en kosten zijn een raming volgens de opdrachtvoorwaarden.','Met vriendelijke groet,','InfraNexus Veiligheid & Milieu',...files.flatMap(f=>[`--${boundary}`,`Content-Type: ${f.mime}`,`Content-Disposition: attachment; filename="${safe(f.name)}"`,'Content-Transfer-Encoding: base64','',(f.url.split(',')[1]||'').match(/.{1,76}/g)?.join('\r\n')||'']),`--${boundary}--`].join('\r\n');
}

export function saveCompanyDetails(s:PortalState,a:Account,party:'issuer'|'customer'|'professional',partyId:string,d:ContractParty):PortalState {
    need(canReview(a),'Alleen HR / Admin beheert de bedrijfsgegevens.');
    need(d.name.trim() && (!d.kvk || /^\d{8}$/.test(d.kvk)) && (!d.email || /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(d.email)),'Controleer bedrijfsnaam, KvK (8 cijfers) en e-mailadres.');
    need(party==='issuer'||(party==='customer'?s.customers.some(c=>c.id===partyId):s.professionals.some(p=>p.id===partyId)),'Contractpartij ontbreekt.');
    return {...s,companyDetails:[{party,partyId,details:{...d}},...s.companyDetails.filter(c=>c.party!==party||c.partyId!==partyId)],customers:s.customers.map(c=>party==='customer'&&c.id===partyId?{...c,name:d.name,kvk:d.kvk,vatNumber:d.vatNumber,address:d.address,contact:d.contact,email:d.email,phone:d.phone||c.phone}:c),professionals:s.professionals.map(p=>party==='professional'&&p.id===partyId?{...p,company:d.name,kvk:d.kvk,vatNumber:d.vatNumber,address:d.address,email:d.email,phone:d.phone||p.phone}:p)};
}
export function registerSignedBase(s:PortalState,a:Account,party:'customer'|'professional',partyId:string,file:FileAsset,from:string,until:string,signedOn:string,checked:boolean,termsFile?:FileAsset):PortalState {
    need(canReview(a),'Alleen HR / Admin registreert de vooraf ondertekende raamovereenkomst.');
    need(checked,'Bevestig dat de overeenkomst vooraf is ondertekend en door HR is gecontroleerd.');
    need(file.mime==='application/pdf' && !!file.url && file.size>0,'Upload de ondertekende PDF.');
    need(!termsFile||termsFile.mime==='application/pdf','Algemene voorwaarden moeten een PDF zijn.');
    sortedDates([from,until,signedOn]);
    need(/^\d{4}-\d{2}-\d{2}$/.test(signedOn) && signedOn<=new Intl.DateTimeFormat('sv-SE',{timeZone:'Europe/Amsterdam'}).format(new Date()),'Vul de werkelijke ondertekeningsdatum in.');
    let next=createBaseContract(s,a,party,partyId,from,until,{issuer:issuerDetails(s),recipient:partyDetails(s,party,partyId),clauses:'De voorwaarden staan in de vooraf ondertekende raamovereenkomst en eventuele bijlage.',source:'Eigen contracttekst'},file);
    const item=party==='customer'?next.agreements[0]:next.cooperations[0],at=now();
    const registration={by:a.name,at,signedOn,note:'Vooraf ondertekende raamovereenkomst, door HR gecontroleerd en geregistreerd.'};
    if(party==='customer')next={...next,agreements:next.agreements.map(g=>g.id===item.id?{...g,status:'Actief',versions:g.versions.map((v,i)=>i===g.versions.length-1?{...v,sharedAt:at,registered:registration,termsFile}:v)}:g),projects:next.projects.map(p=>p.customerId===partyId&&p.status==='Wacht op overeenkomst'&&p.start>=from&&p.end<=until?{...p,status:'Planning nodig'}:p)};
    else next={...next,cooperations:next.cooperations.map(c=>c.id===item.id?{...c,versions:c.versions.map((v,i)=>i===c.versions.length-1?{...v,sharedAt:at,registered:registration,termsFile}:v)}:c)};
    return {...next,notifications:[{id:uid(),title:'Ondertekende raamovereenkomst toegevoegd',body:'Je raamovereenkomst staat bij Contracten. Per opdracht ontvang je een opdrachtbevestiging om online te accepteren.',target:'meldingen',page:'agreements',recordId:item.id,audience:party,customerId:party==='customer'?partyId:undefined,professionalId:party==='professional'?partyId:undefined,read:false,at},...next.notifications]};
}
export function validateManualMail(to:string,sentAt:string,checked:boolean){
    need(checked,'Bevestig dat je de e-mail daadwerkelijk handmatig hebt verstuurd.');
    need(/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(to),'Vul het gebruikte e-mailadres in.');
    need(Number.isFinite(Date.parse(sentAt)) && Date.parse(sentAt)<=Date.now()+60000,'Vul een geldig verzendmoment in dat niet in de toekomst ligt.');
}

export function submitCustomerContract(s:PortalState,a:Account,data:{file:FileAsset;termsFile?:FileAsset;from:string;until:string;signedOn:string}):PortalState{
    need((a.role==='KLANT ADMIN'||a.role==='KLANT GEBRUIKER')&&a.customerId,'Alleen de klant kan een eigen overeenkomst indienen.');
    need(s.customers.some(c=>c.id===a.customerId),'Het klantdossier ontbreekt.');
    need(data.file.mime==='application/pdf'&&data.file.url&&data.file.size>0&&data.file.size<=10*1024*1024,'Upload de overeenkomst als PDF van maximaal 10 MB.');
    need(!data.termsFile||(data.termsFile.mime==='application/pdf'&&data.termsFile.url&&data.termsFile.size>0&&data.termsFile.size<=10*1024*1024),'Algemene voorwaarden moeten een PDF van maximaal 10 MB zijn.');
    sortedDates([data.from,data.until,data.signedOn]);need(data.until>=data.from&&data.signedOn<=new Intl.DateTimeFormat('sv-SE',{timeZone:'Europe/Amsterdam'}).format(new Date()),'Controleer de looptijd en ondertekeningsdatum.');
    const record={...data,id:uid(),customerId:a.customerId!,status:'Ter controle' as const,by:a.name,at:now()};
    return {...s,contractSubmissions:[record,...s.contractSubmissions],notifications:[{id:uid(),title:'Klantovereenkomst ter controle',body:s.customers.find(c=>c.id===a.customerId)?.name||a.name,target:'meldingen',page:'agreements',recordId:record.id,audience:'internal',read:false,at:now()},...s.notifications]};
}
export function reviewCustomerContract(s:PortalState,a:Account,id:string,approve:boolean,checked:boolean,note:string):PortalState{
    const upload=s.contractSubmissions.find(c=>c.id===id);need(canReview(a)&&upload?.status==='Ter controle','Deze klantupload staat niet open voor jouw beoordeling.');
    need(approve?checked:note.trim(),'Controleer de partijen, inhoud en ondertekening of geef de afwijzingsreden.');
    let next=s;if(approve)next=registerSignedBase(s,a,'customer',upload!.customerId,upload!.file,upload!.from,upload!.until,upload!.signedOn,true,upload!.termsFile);
    const agreement=next.agreements.find(g=>g.customerId===upload!.customerId);
    return {...next,contractSubmissions:next.contractSubmissions.map(c=>c.id===id?{...c,status:approve?'Goedgekeurd':'Afgewezen',reviewedBy:a.name,reviewedAt:now(),note,agreementId:approve?agreement?.id:undefined,agreementVersion:approve?agreement?.versions.at(-1)?.version:undefined}:c),notifications:[{id:uid(),title:approve?'Raamovereenkomst goedgekeurd en actief':'Contractupload afgewezen',body:approve?'Je ingediende raamovereenkomst is door InfraNexus gecontroleerd en toegevoegd aan Contracten.':note,target:'meldingen',page:'agreements',recordId:id,audience:'customer',customerId:upload!.customerId,read:false,at:now()},...next.notifications]};
}
