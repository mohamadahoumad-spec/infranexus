import {emptyProjectOps,type ProjectOpsState} from './project-ops-types.ts';
import {initialPortalAccounts} from './account-setup.ts';
import {baseAccepted} from './contract-utils.ts';
import {emptyWorkflow,type WorkflowState,type OnlineBase} from './workflow-types.ts';
import { seed, TODAY, uid, canReview, canPlan, isCustomer, isInternal, isProfessional, visibleProjects, planningIssues, logSnapshot, type Account, type DemoState, type Project, type Logbook } from './demo.ts';
import { hydrateDemoState } from './professional.ts';
import { acceptRequest, scheduleMany } from './operations.ts';
import type { FileAsset } from './operations-types.ts';
export type Page = 'accounts' | 'home' | 'requests' | 'agreements' | 'planning' | 'projects' | 'people' | 'candidates' | 'checks' | 'logs' | 'documents' | 'chat' | 'finance' | 'availability' | 'profile' | 'settings' | 'customers' | 'orders' | 'hours' | 'notifications';
export type AgreementSignature = {
    id: string;
    file: FileAsset;
    by: string;
    at: string;
    status: 'Ingediend' | 'Goedgekeurd' | 'Afgekeurd';
    note?: string;
    reviewedBy?: string;
    reviewedAt?: string;
};
export type AgreementVersion = OnlineBase & {
    version: number;
    file: FileAsset;
    from: string;
    until: string;
    by: string;
    at: string;
    sharedAt?: string;
    signatures: AgreementSignature[];
};
export type Agreement = {
    id: string;
    number: string;
    customerId: string;
    projectIds: string[];
    status: 'Concept' | 'Ter acceptatie' | 'Ter ondertekening' | 'Ondertekend ter controle' | 'Actief' | 'Correctie gevraagd';
    versions: AgreementVersion[];
};
export type RequestEvent = {
    id: string;
    requestId: string;
    actor: string;
    at: string;
    kind: string;
    note: string;
};
export type PortalState = DemoState & WorkflowState & ProjectOpsState & {
    schema: 2;
    agreements: Agreement[];
    requestEvents: RequestEvent[];
    chatRead: {
        conversationId: string;
        actor: string;
        at: string;
    }[];
};
const ensure = (ok: unknown, message: string) => { if (!ok)
    throw new Error(message); };
const now = () => new Date().toISOString();
export function demoPdf(name:string,lines:string[]):FileAsset {
 const ascii=(value:string)=>value.normalize('NFKD').replace(/[^\x20-\x7E\n]/g,'');
 const escape=(value:string)=>value.replace(/[\\()]/g,'\\$&');
 const wrapped=[name,'DEMO - uitsluitend fictief voorbeeld',...lines].flatMap(value=>ascii(value).split('\n').flatMap(line=>{
  const result:string[]=[];let current='';
  for(const word of line.split(/\s+/)){
   if(current.length+word.length+1>90){if(current)result.push(current);current='';}
   if(word.length>90){const parts=word.match(/.{1,90}/g)||[];result.push(...parts.slice(0,-1));current=parts.at(-1)||'';}else current+=(current?' ':'')+word;
  }
  result.push(current);return result;
 }));
 const pages=Array.from({length:Math.ceil(wrapped.length/43)},(_,i)=>wrapped.slice(i*43,(i+1)*43));
 const objects:string[]=['<< /Type /Catalog /Pages 2 0 R >>',`<< /Type /Pages /Kids [${pages.map((_,i)=>`${4+i*2} 0 R`).join(' ')}] /Count ${pages.length} >>`,'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>'];
 pages.forEach((page,i)=>{
  const stream=`BT /F1 10.5 Tf 44 797 Td ${page.map((line,j)=>`${j?'0 -17 Td ':''}(${escape(line)}) Tj`).join('\n')} ET\nBT /F1 9 Tf 44 26 Td (Pagina ${i+1} / ${pages.length}) Tj ET`;
  objects.push(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 3 0 R >> >> /Contents ${5+i*2} 0 R >>`,`<< /Length ${stream.length} >>\nstream\n${stream}\nendstream`);
 });
 let pdf='%PDF-1.4\n';const offsets=[0];
 objects.forEach((object,i)=>{offsets.push(pdf.length);pdf+=`${i+1} 0 obj\n${object}\nendobj\n`;});
 const xref=pdf.length;pdf+=`xref\n0 ${objects.length+1}\n0000000000 65535 f \n${offsets.slice(1).map(offset=>`${String(offset).padStart(10,'0')} 00000 n \n`).join('')}trailer\n<< /Size ${objects.length+1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`;
 return {name:name+'.pdf',mime:'application/pdf',size:pdf.length,url:'data:application/pdf;base64,'+btoa(pdf)};
}
export function portalSeed(): PortalState {
    const s = seed();
    s.branding = [{ id: 'infranexus', logo: '/brand/primary-logo-v2.png', name: 'InfraNexus Veiligheid & Milieu' }];
    s.professionals = s.professionals.map((p, i) => ({ ...p, company: p.company || `${p.name.split(' ').at(-1)} Veiligheid`, kvk: p.kvk || String(12345000 + i) }));
    s.projects = s.projects.map((p, i) => ({ ...p, safetyClass: ['Oranje niet-vluchtig', 'Basishygiëne', 'Oranje vluchtig', 'Zwart CM-stoffen'][i % 4] }));
    const agreements: Agreement[] = s.customers.map((c, i) => ({ id: 'ag' + c.id, number: `RAAM-2026-00${i + 1}`, customerId: c.id, projectIds: s.projects.filter(p => p.customerId === c.id).map(p => p.id), status: i === 2 ? 'Ter ondertekening' : 'Actief', versions: [{ version: 1, file: demoPdf('Raamovereenkomst ' + c.name, ['Fictieve contractregistratie voor het portaal.', 'Geen juridische overeenkomst.', 'Hier komt uw eigen goedgekeurde raamovereenkomst.']), from: '2026-01-01', until: '2026-12-31', by: 'Sophie de Groot', at: '2026-09-21T10:00:00Z', sharedAt: '2026-09-21T11:00:00Z', signatures: i === 2 ? [] : [{ id: 'sig' + i, file: demoPdf('Ondertekend voorbeeld ' + c.name, ['Fictief ondertekend exemplaar - geen echte handtekening.']), by: c.contact, at: '2026-09-22T10:00:00Z', status: 'Goedgekeurd', reviewedBy: 'Sophie de Groot', reviewedAt: '2026-09-22T11:00:00Z' }] }] }));
    s.requests = [{ id: 'rq-new', projectId: '', customerId: 'c1', projectName: 'Sanering Merwehaven', service: 'Personeelsinzet', role: 'DLP', safetyClass: 'Oranje niet-vluchtig', dates: ['2026-10-12', '2026-10-13', '2026-10-14'], date: '2026-10-12', duration: '3 dagen', location: 'Merwehaven, Rotterdam', hours: '07:00 - 16:00', urgent: false, description: 'Begeleiding grondwerk in werkvak B. V&G-plan bijgevoegd ter controle.', status: 'Nieuw', vgPlan: demoPdf('VG-plan Merwehaven', ['VOORBEELD - inhoud door opdrachtgever aan te leveren.']) }, ...s.requests.map(r => ({ ...r, status: r.projectId ? 'Geaccepteerd' : r.status, projectName: s.projects.find(p => p.id === r.projectId)?.name }))];
    s.logTemplates = s.projects.slice(0, 2).map((p, i) => ({ id: 'tpl' + i, projectId: p.id, version: 1, file: demoPdf('Klantlogboek ' + p.name, ['Datum: ____________________', 'Professional: ____________________', 'Project / werkvak: ____________________', 'Werkzaamheden: ____________________', 'Bevindingen: ____________________', 'Afwijkingen en acties: ____________________', 'Overdracht: ____________________', 'Handtekening: ____________________']), uploadedAt: '2026-10-01T10:00:00Z', uploadedBy: 'HR-team' }));
    s.conversations = [{ id: 'conv-c1', kind: 'customer', customerId: 'c1', department: 'Planning', title: 'Afstemming starttijd Maasvlakte', urgent: false, createdAt: '2026-10-06T07:20:00Z' }, { id: 'conv-pro1', kind: 'professional', professionalId: 'pro1', department: 'HR', title: 'Mijn VCA-bewijs vernieuwen', urgent: false, createdAt: '2026-10-06T08:10:00Z' }];
    s.chatMessages = [{ id: 'msg1', conversationId: 'conv-c1', author: 'Delta Infra', side: 'external', body: 'Goedemorgen, kunnen we de start voor morgen afstemmen op 07:30?', at: '2026-10-06T07:20:00Z' }, { id: 'msg2', conversationId: 'conv-c1', author: 'Planner · voorbeeld', side: 'internal', body: 'Goedemorgen Mark. We stemmen dit af en passen daarna de planning voor je aan.', at: '2026-10-06T07:32:00Z' }, { id: 'msg3', conversationId: 'conv-pro1', author: 'Daan Vermeer', side: 'external', body: 'Mijn nieuwe VCA-bewijs is binnen. Kan ik die bij Certificaten uploaden?', at: '2026-10-06T08:10:00Z' }];
    s.certificateSubmissions = [{ id: 'evidence-vca', professionalId: 'pro1', type: 'VCA-VOL', issuer: 'Voorbeeldopleider', achieved: '2026-10-01', expiry: '2031-10-01', name: 'VCA Daan Vermeer.pdf', url: demoPdf('VCA voorbeeld Daan Vermeer', ['Fictief bewijs voor demonstratie.', 'HR controleert het originele certificaat.']).url, mime: 'application/pdf', status: 'Controle nodig', submittedAt: '2026-10-06T08:15:00Z' }];
    s.documents = s.documents.map(d => ({ ...d, url: demoPdf(d.name.replace('.pdf', ''), ['Fictief projectdocument - vervang door uw eigen bestand.']).url, mime: 'application/pdf' }));
    return hydratePortal({ ...s, ...emptyWorkflow(), portalAccounts:initialPortalAccounts(s), schema: 2, agreements, requestEvents: [], chatRead: [] });
}
export function hydratePortal(raw: unknown): PortalState {
    const base = hydrateDemoState(raw), r = raw as Partial<PortalState>;
    for(const request of base.requests){if(request.vgPlan&&!base.documents.some(d=>d.requestId===request.id||(d.projectId===request.projectId&&!!request.projectId&&d.url===request.vgPlan?.url)))base.documents.push({id:'vg-'+request.id,projectId:request.projectId,requestId:request.id,customerId:request.customerId,name:request.vgPlan.name,type:'V&G-plan',audience:'Backoffice',version:1,date:request.date,status:'Controle nodig',url:request.vgPlan.url,mime:request.vgPlan.mime,size:request.vgPlan.size});}
    base.notifications=base.notifications.map(n=>({...n,title:n.title.replace(/offerte \/ opdracht/gi,'opdrachtbevestiging'),body:n.body.replace(/offerte \/ opdracht/gi,'opdrachtbevestiging')}));
    return { ...base,...Object.fromEntries(Object.entries(emptyProjectOps()).map(([k,v])=>[k,Array.isArray((r as any)[k])?(r as any)[k]:v])) as ProjectOpsState,production:r.production===true, ...Object.fromEntries(Object.entries(emptyWorkflow()).map(([key,value])=>[key,Array.isArray((r as any)[key])?(r as any)[key]:value])) as WorkflowState, schema: 2, portalAccounts:Array.isArray(r.portalAccounts)?r.portalAccounts:initialPortalAccounts(base), branding: base.branding.map(b => b.logo === '/brand/infranexus-primary.png' ? { ...b, logo: '/brand/primary-logo-v2.png' } : b), agreements: Array.isArray(r.agreements) ? r.agreements : base.customers.filter(c=>base.projects.some(p=>p.customerId===c.id)).map((c,i)=>({id:'migrated-ag-'+c.id,number:`RAAM-2026-${String(i+1).padStart(3,'0')}`,customerId:c.id,projectIds:base.projects.filter(p=>p.customerId===c.id).map(p=>p.id),status:'Concept' as const,versions:[]})), requestEvents: Array.isArray(r.requestEvents) ? r.requestEvents : [], chatRead: Array.isArray(r.chatRead) ? r.chatRead : [] };
}
export function visibleAgreements(s: PortalState, a: Account) { return isProfessional(a) ? [] : s.agreements.filter(g => !isCustomer(a) || g.customerId === a.customerId).map(g => { if (!isCustomer(a))
    return g; const versions = g.versions.filter(v => v.sharedAt), last = versions.at(-1), sig = last?.signatures.at(-1); return { ...g, versions, status: last?.version !== g.versions.at(-1)?.version ? (last && baseAccepted(last) ? 'Actief' as const : sig?.status === 'Ingediend' ? 'Ondertekend ter controle' as const : sig?.status === 'Afgekeurd' ? 'Correctie gevraagd' as const : 'Ter ondertekening' as const) : g.status }; }).filter(g => !isCustomer(a) || g.versions.length); }
export function activeAgreement(s: PortalState, customerId: string, from: string, until = from) { return s.agreements.find(g => g.customerId === customerId && g.versions.some(v => v.from <= from && v.until >= until && baseAccepted(v))); }
export function projectAgreement(s: PortalState, p: Project, date = TODAY) { return s.agreements.find(g => g.customerId === p.customerId && g.projectIds.includes(p.id) && g.versions.some(v => v.from <= date && v.until >= date && baseAccepted(v))); }
export function reviewRequest(s: PortalState, a: Account, id: string, action: 'accept' | 'question' | 'reject', note: string): PortalState {
    ensure(canPlan(a), 'Alleen HR / Planning kan aanvragen beoordelen.');
    const r = s.requests.find(r => r.id === id);
    ensure(r && !r.projectId && !r.deletedAt && ['Nieuw','Aanvulling nodig'].includes(r.status), 'Deze aanvraag is al afgehandeld.');
    ensure(action === 'accept' || note.trim(), 'Geef een toelichting voor de klant.');
    const event = { id: uid(), requestId: id, actor: a.name, at: now(), kind: action === 'accept' ? 'Geaccepteerd' : action === 'question' ? 'Aanvulling gevraagd' : 'Afgewezen', note };
    if (action !== 'accept')
        return { ...s, notifications:[{id:uid(),title:action==='reject'?'Aanvraag afgewezen':event.kind,body:`${r!.projectName||'Aanvraag'}: ${note}`,target:'aanvragen',page:'requests',recordId:id,customerId:r!.customerId,projectId:r!.projectId||r!.existingProjectId,audience:'customer',read:false},...s.notifications], requests: s.requests.map(x => x.id === id ? { ...x, status: action === 'question' ? 'Aanvulling nodig' : 'Afgewezen' } : x), requestEvents: [event, ...s.requestEvents] };
    const accepted = acceptRequest({ ...s, requests: s.requests.map(x => x.id === id ? { ...x, status: 'Nieuw' } : x) }, a, id);
    const p = accepted.projects[0];
    const existing = activeAgreement(s, r!.customerId, p.start, p.end) || s.agreements.find(g => g.customerId === r!.customerId);
    const agreement: Agreement = existing ? { ...existing, projectIds: [...new Set([...existing.projectIds, p.id])] } : { id: uid(), number: `RAAM-2026-${String(s.agreements.length + 1).padStart(3, '0')}`, customerId: r!.customerId, projectIds: [p.id], status: 'Concept', versions: [] };
    return { ...s, ...accepted, agreements: [agreement, ...s.agreements.filter(g => g.id !== agreement.id)], requestEvents: [event, ...s.requestEvents], projects: accepted.projects.map(x => x.id === p.id ? { ...x, status: activeAgreement(s, p.customerId, p.start, p.end) ? 'Planning nodig' : 'Wacht op overeenkomst' } : x) };
}
export function replyRequest(s: PortalState, a: Account, id: string, note: string): PortalState {
    const r = s.requests.find(r => r.id === id);
    ensure(isCustomer(a) && r?.customerId === a.customerId && r?.status === 'Aanvulling nodig', 'Deze aanvraag wacht niet op jouw reactie.');
    ensure(note.trim(), 'Vul de aanvulling in.');
    return { ...s, notifications:[{id:uid(),title:'Klant heeft gereageerd',body:note,target:'aanvragen',page:'requests',recordId:id,audience:'internal',read:false},...s.notifications], requests: s.requests.map(r => r.id === id ? { ...r, status: 'Nieuw' } : r), requestEvents: [{ id: uid(), requestId: id, actor: a.name, at: now(), kind: 'Klantreactie', note }, ...s.requestEvents] };
}
export function uploadAgreement(s: PortalState, a: Account, id: string, file: FileAsset, from: string, until: string): PortalState {
    ensure(canReview(a), 'Alleen HR / Admin beheert contractbestanden.');
    ensure(file.mime === 'application/pdf' && from && until >= from, 'Upload een PDF en controleer de looptijd.');
    const g = s.agreements.find(g => g.id === id);
    ensure(g, 'Overeenkomst niet gevonden.');
    return { ...s, agreements: s.agreements.map(g => g.id === id ? { ...g, status: 'Concept', versions: [...g.versions, { version: g.versions.length + 1, file, from, until, by: a.name, at: now(), signatures: [] }] } : g) };
}
export function shareAgreement(s: PortalState, a: Account, id: string): PortalState {
    ensure(canReview(a), 'Alleen HR / Admin deelt overeenkomsten.');
    const g = s.agreements.find(g => g.id === id);
    ensure(g?.versions.length && g.status === 'Concept', 'Voeg eerst een nieuwe overeenkomst-PDF toe.');
    return { ...s, agreements: s.agreements.map(g => g.id === id ? { ...g, status: 'Ter ondertekening', versions: g.versions.map((v, i) => i === g.versions.length - 1 ? { ...v, sharedAt: now() } : v) } : g) };
}
export function signAgreement(s: PortalState, a: Account, id: string, file: FileAsset): PortalState {
    const g = s.agreements.find(g => g.id === id);
    ensure(g && ((a.role === 'KLANT ADMIN' && g.customerId === a.customerId) || canReview(a)), 'Geen toegang tot deze overeenkomst.');
    ensure(g && ['Ter ondertekening', 'Correctie gevraagd'].includes(g.status), 'Deze overeenkomst wacht niet op een ondertekend bestand.');
    ensure(file.mime === 'application/pdf', 'Upload het ondertekende exemplaar als PDF.');
    return { ...s, agreements: s.agreements.map(g => g.id === id ? { ...g, status: 'Ondertekend ter controle', versions: g.versions.map((v, i) => i === g.versions.length - 1 ? { ...v, signatures: [...v.signatures, { id: uid(), file, by: a.name, at: now(), status: 'Ingediend' }] } : v) } : g) };
}
export function verifyAgreement(s: PortalState, a: Account, id: string, approve: boolean, note: string): PortalState {
    ensure(canReview(a), 'Alleen HR / Admin kan ondertekening controleren.');
    const g = s.agreements.find(g => g.id === id);
    ensure(g?.status === 'Ondertekend ter controle', 'Geen ondertekend bestand ter controle.');
    ensure(approve || note.trim(), 'Vul de correctiereden in.');
    const next = { ...s, agreements: s.agreements.map(g => g.id === id ? { ...g, status: approve ? 'Actief' as const : 'Correctie gevraagd' as const, versions: g.versions.map((v, i) => i === g.versions.length - 1 ? { ...v, signatures: v.signatures.map((sig, j) => j === v.signatures.length - 1 ? { ...sig, status: approve ? 'Goedgekeurd' as const : 'Afgekeurd' as const, note, reviewedBy: a.name, reviewedAt: now() } : sig) } : v) } : g) };
    return { ...next, projects: next.projects.map(p => g!.projectIds.includes(p.id) && p.status === 'Wacht op overeenkomst' && projectAgreement(next, p, p.start) ? { ...p, status: 'Planning nodig' } : p) };
}
export function portalPlanningIssues(s: PortalState, personId: string, projectId: string, date: string, spoken = false) { const p = s.projects.find(p => p.id === projectId), person=s.professionals.find(p=>p.id===personId), request = s.requests.find(r => r.projectId === projectId), requestedDays=s.requests.filter(r=>r.projectId===projectId).flatMap(r=>r.dates||[r.date]); return [...(person&&!person.certificates.some(c=>['VCA','VCA-VOL'].includes(c.type)&&c.verified&&!c.supersededAt&&c.expiry>=date)?['Geen gecontroleerd VCA-bewijs geldig op de inzetdatum.']:[]), ...(requestedDays.length && !requestedDays.includes(date) ? ['Deze dag valt buiten de aangevraagde werkdagen.'] : []), ...planningIssues(s, personId, projectId, date).filter(i=>i!=='Maandbeschikbaarheid is nog niet ingediend.'), ...(p && !projectAgreement(s, p, date) ? ['Een gecontroleerde raamovereenkomst ontbreekt voor deze datum.'] : []), ...(p && ['Geannuleerd', 'Afgerond', 'On hold'].includes(p.status) ? ['Dit project staat niet open voor nieuwe inzet.'] : [])]; }
export function planWork(s:PortalState,a:Account,projectId:string,personId:string,dates:string[],start:string,end:string,confirmation?:{note:string;spoken:boolean}):PortalState{
 ensure(canPlan(a),'Alleen Planning kan inzet vastleggen.');
 const issues=dates.flatMap(d=>portalPlanningIssues(s,personId,projectId,d).map(i=>`${d}: ${i}`));ensure(!issues.length,issues.join('\n'));
 const missing=[...new Set(dates.map(d=>d.slice(0,7)))].filter(month=>!s.monthlyAvailability.some(m=>m.professionalId===personId&&m.month===month)),at=now();
 // Temporary planning input only. This never becomes a professional's submitted month.
 const input={...s,monthlyAvailability:[...s.monthlyAvailability,...missing.map(month=>({id:uid(),professionalId:personId,month,days:Object.fromEntries(dates.filter(d=>d.startsWith(month)).map(d=>[d,'Beschikbaar'])),submittedAt:at,submittedBy:a.name}))]};
 const planned=scheduleMany(input,a,projectId,personId,dates,start,end);
 const requested=s.requests.filter(r=>r.projectId===projectId).flatMap(r=>r.dates||[r.date]);
 return {...s,...planned,monthlyAvailability:s.monthlyAvailability,assignments:planned.assignments.map(x=>s.assignments.some(y=>y.id===x.id)?x:{...x,...(missing.length?{availabilityWarning:{by:a.name,at,missingMonths:missing}}:{}),...(confirmation?.spoken?{availabilityConfirmation:{by:a.name,at,note:confirmation.note.trim()||'Mondelinge afstemming bevestigd door Planning.'}}:{})}),projects:planned.projects.map(p=>p.id===projectId&&p.status==='Planning nodig'&&requested.length&&requested.every(d=>planned.assignments.some(x=>x.projectId===p.id&&x.date===d&&x.status!=='Geannuleerd'))?{...p,status:'Ingepland'}:p)};
}
export function reviewDigitalLog(s: PortalState, a: Account, id: string, approve: boolean, note: string): PortalState { ensure(canReview(a), 'Alleen HR beoordeelt logboeken.'); const log = s.logbooks.find(l => l.id === id); ensure(log && ['Ingediend', 'Controle nodig'].includes(log.status), 'Dit logboek wacht niet op controle.'); ensure(approve || note.trim(), 'Vul de correctiereden in.'); const status = approve ? 'Goedgekeurd' : 'Correctie gevraagd'; return { ...s, logbooks: s.logbooks.map(l => l.id === id ? { ...l, status, reviewNote: note, versions: [...l.versions, logSnapshot(l, status, l.versions.length + 1, a.name)] } : l) }; }
export function scopeDescription(a: Account) { if (isCustomer(a))
    return 'Je ziet alleen de aanvragen, afspraken, inzet, goedgekeurde logboeken en facturen van jouw organisatie.'; if (isProfessional(a))
    return 'Je ziet je eigen inzet en dossier. Alleen gedeelde projectdocumenten en je eigen berichten zijn zichtbaar.'; if (a.role === 'FINANCIEEL')
    return 'Je beheert klantfacturen en zzp-facturen na HR-akkoord. Privé HR-bestanden blijven bij HR.'; if (a.role === 'PLANNING')
    return 'Je beoordeelt aanvragen en plant inzet. CV’s en andere privé HR-bestanden blijven bij HR.'; if (a.role === 'CUSTOMER SUPPORT')
    return 'Je behandelt klant- en professionalberichten. HR-documenten en facturen vallen buiten je afdeling.'; return 'Je werkt in de interne omgeving. De inhoud van elk dossier blijft gekoppeld aan de juiste klant of professional.'; }
export function allowedPages(a: Account): Page[] { if (isCustomer(a))
    return ['orders', 'hours', 'notifications', 'home', 'requests', 'agreements', 'planning', 'projects', 'logs', 'documents', 'chat', 'finance', 'profile']; if (isProfessional(a))
    return ['orders', 'hours', 'notifications', 'home', 'agreements', 'planning', 'projects', 'logs', 'documents', 'checks', 'availability', 'chat', 'finance', 'profile']; if (a.role === 'PLANNING')
    return ['orders', 'hours', 'notifications', 'home', 'requests', 'agreements', 'planning', 'projects', 'people', 'checks', 'logs', 'documents', 'chat', 'profile','customers']; if (a.role === 'FINANCIEEL')
    return ['orders', 'hours', 'notifications', 'home', 'projects', 'agreements', 'finance', 'chat', 'profile','customers']; if (a.role === 'CUSTOMER SUPPORT')
    return ['notifications', 'home', 'projects', 'chat', 'profile','customers']; if (a.role === 'BUSINESS DEVELOPMENT')
    return ['notifications', 'home', 'requests', 'agreements', 'projects', 'profile', 'chat','customers']; return ['accounts', 'orders', 'hours', 'notifications', 'home', 'requests', 'agreements', 'planning', 'projects', 'people', 'candidates', 'checks', 'logs', 'documents', 'chat', 'finance', 'settings', 'profile','customers']; }
export function cancelWork(s:PortalState,a:Account,id:string,reason:string):PortalState{
 ensure(canPlan(a),'Alleen Planning kan inzet annuleren.');const assignment=s.assignments.find(x=>x.id===id);ensure(assignment&&assignment.status!=='Geannuleerd','Deze inzet is niet actief.');ensure(reason.trim(),'Vul een reden voor annuleren in.');
 return {...s,assignments:s.assignments.map(x=>x.id===id?{...x,status:'Geannuleerd',acknowledgedAt:undefined,cancellationReason:reason}:x),projects:s.projects.map(p=>p.id===assignment!.projectId&&p.status==='Ingepland'?{...p,status:'Planning nodig'}:p),notifications:[{id:uid(),title:'Inzet geannuleerd',body:`${assignment!.date} · ${reason}`,target:'planning',professionalId:assignment!.professionalId,projectId:assignment!.projectId,audience:'professional',read:false},...s.notifications]};
}
