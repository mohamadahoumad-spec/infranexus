import {env} from 'cloudflare:workers';
import {getChatGPTUser} from '../app/chatgpt-auth';
import {createPortalService} from './portal-server-core';
export function servePortal(request:Request){return createPortalService(env,getChatGPTUser).servePortal(request);}
