export const loginPortals = [
  {id:'professional',label:'Professional',description:'Jouw planning, daglogboeken, documenten en beschikbaarheid.'},
  {id:'office',label:'Kantoor',description:'Voor beheer, HR, Planning, Finance en de andere teams van InfraNexus.'},
  {id:'customer',label:'Klant',description:'Jouw projecten, opdrachtbevestigingen, rapportages en facturen.'},
] as const;
export type LoginPortal = typeof loginPortals[number]['id'];
export function parseLoginPortal(value:unknown):LoginPortal|null{return loginPortals.some(p=>p.id===value)?value as LoginPortal:null;}
export function portalForRole(role:string):LoginPortal{return role==='PROFESSIONAL'?'professional':role.startsWith('KLANT')?'customer':'office';}
export function workspacePath(portal:LoginPortal|null){return '/werkruimte'+(portal?'?omgeving='+portal:'');}
export function signInPath(portal:LoginPortal|null){return '/signin-with-chatgpt?return_to='+encodeURIComponent(workspacePath(portal));}
export function invitationPath(role:string,token:string){return '/uitnodiging?omgeving='+portalForRole(role)+'#invite='+encodeURIComponent(token);}
