import type { Acceptance, OrderTerms } from './workflow-types.ts';

export function baseAccepted(v: { acceptance?: Acceptance; registered?:{by:string}; signatures?: {status:string}[]; returns?: {status:string}[] }) {
    return !!v.registered || !!v.acceptance || !!(v.signatures || v.returns)?.some(r => r.status === 'Goedgekeurd');
}
export const money = (cents:number) => new Intl.NumberFormat('nl-NL', {style:'currency',currency:'EUR'}).format(cents / 100);
export function orderEstimate(t: Pick<OrderTerms,'dates'|'expectedHoursPerDay'|'rateCents'|'unit'|'vat'|'supplementCents'|'travelCents'>) {
    if (!['uur','dag','project'].includes(t.unit)) throw Error('Kies uur, dag of project als tariefeenheid.');
    const amounts = [t.rateCents, t.supplementCents ?? 0, t.travelCents ?? 0];
    if (amounts.some(n => !Number.isSafeInteger(n) || n < 0)) throw Error('Bedragen moeten geldige, positieve centbedragen zijn.');
    if (!Number.isFinite(t.expectedHoursPerDay) || t.expectedHoursPerDay < 0) throw Error('Controleer de verwachte uren.');
    const days = new Set(t.dates).size, hours = Math.round(days * t.expectedHoursPerDay * 100) / 100;
    const quantity = t.unit === 'uur' ? hours : t.unit === 'dag' ? days : 1;
    const baseCents = Math.round(quantity * t.rateCents);
    const exCents = baseCents + (t.supplementCents ?? 0) + (t.travelCents ?? 0);
    const vat = t.vat ?? '21';
    if (!['21','9','0','verlegd','vrijgesteld'].includes(vat)) throw Error('Kies een geldige btw-behandeling.');
    const vatCents = Math.round(exCents * (Number(vat) || 0) / 100), totalCents = exCents + vatCents;
    if (!Number.isSafeInteger(totalCents)) throw Error('Dit bedrag is te groot.');
    return {days,hours,quantity,baseCents,exCents,vatCents,totalCents,vatLabel:vat === 'verlegd' ? 'Btw verlegd' : vat === 'vrijgesteld' ? 'Vrijgesteld van btw' : `Btw ${vat}%`};
}
export const baseDeclaration = 'Ik ben bevoegd deze partij te vertegenwoordigen. Ik heb deze basisovereenkomst en de daarin opgenomen voorwaarden kunnen lezen en opslaan en accepteer deze versie.';
export const orderDeclaration = 'Ik ben bevoegd deze partij te vertegenwoordigen. Ik heb deze opdrachtbevestiging, de gekoppelde hoofdraamovereenkomst en de toepasselijke algemene voorwaarden van InfraNexus kunnen lezen en opslaan. Ik aanvaard de in deze opdrachtbevestiging vastgelegde opdracht conform die afspraken, inclusief de verwachte inzet, tarieven en kosten. De verwachte inzet is een raming. Afwijkingen worden geregistreerd en afgehandeld volgens de overeengekomen afspraken over uitvoering en afrekening.';
