import {canPlan,canReview,isCustomer,isProfessional,visibleProjects,type Account} from './demo.ts';
import type {PortalState,Page} from './portal.ts';
import {orderEstimate,money} from './contract-utils.ts';
import {weeklyCurrent} from './workflows.ts';
import {logWindow} from './review-calendar.ts';
export type RequiredAction={key:string;projectId?:string;requestId?:string;page:Page;id:string;title:string;body:string;button:string;kind:'order'|'question'|'log'|'mail'|'review'|'notice';};
export function requiredActions(s:PortalState,a:Account):RequiredAction[]{
    const result:RequiredAction[]=[],customer=isCustomer(a),pro=isProfessional(a),internal=canPlan(a);
    for(const r of s.requests){const pid=r.projectId||r.existingProjectId;
        if(customer && r.customerId===a.customerId && r.status==='Aanvulling nodig')result.push({key:'request-'+r.id,projectId:pid,requestId:r.id,page:'requests',id:r.id,title:'Reactie nodig op je aanvraag',body:[...s.requestEvents].find(e=>e.requestId===r.id&&e.kind==='Aanvulling gevraagd')?.note || 'HR heeft een vraag over deze opdracht.',button:'Vraag bekijken en beantwoorden',kind:'question'});
        if(internal && r.status==='Nieuw'&&!r.projectId)result.push({key:'request-'+r.id,projectId:pid,requestId:r.id,page:'requests',id:r.id,title:'Aanvraag beoordelen',body:r.projectName||'Nieuwe klantaanvraag',button:'Aanvraag openen',kind:'review'});
    }
    for(const o of s.orders){const v=o.versions.at(-1)!;
        const own=customer?v.party==='customer'&&v.customerId===a.customerId:pro?v.party==='professional'&&v.professionalId===a.professionalId:false;
        const project=s.projects.find(p=>p.id===v.projectId);
        if(own && v.status==='Ter acceptatie'&&v.sharedAt){let amount='';try{if(v.pricingVersion)amount=` · verwacht ${money(orderEstimate(v).totalCents)} incl. toepasselijke btw`;}catch{}
            result.push({key:'order-'+o.id,projectId:v.projectId,requestId:v.requestId,page:'orders',id:o.id,title:'Akkoord nodig: opdrachtbevestiging',body:`${project?.name||o.number}${amount}. Accepteer de opdracht conform de raamovereenkomst, zodat de inzet verwerkt kan worden.`,button:customer?'Opdrachtbevestiging bekijken en accepteren':'Opdracht bekijken en accepteren',kind:'order'});
        }
        if(internal&&v.status==='Geaccepteerd')result.push({key:'mail-'+o.id,projectId:v.projectId,requestId:v.requestId,page:'orders',id:o.id,title:'Akkoord ontvangen — bevestiging door InfraNexus',body:`${o.number} · Verstuur de definitieve opdrachtbevestiging per mail en registreer de verzending.`,button:'Mailbevestiging afronden',kind:'mail'});
        if(internal&&['Wijziging gevraagd','Afgewezen'].includes(v.status))result.push({key:'review-'+o.id,projectId:v.projectId,requestId:v.requestId,page:'orders',id:o.id,title:'Reactie op de opdrachtbevestiging',body:v.response||v.status,button:'Reactie behandelen',kind:'review'});
    }
    const ids=new Set(visibleProjects(s,a).map(p=>p.id));
    for(const w of s.weeklyLogs){if(!ids.has(w.projectId)||pro||(!customer&&!internal))continue;
        const latest=s.weeklyLogs.filter(x=>x.projectId===w.projectId&&x.week===w.week).sort((a,b)=>b.revision-a.revision)[0];
        if(latest?.id!==w.id)continue;
        const current=weeklyCurrent(s,w);
        if(!current)continue;
        const window=logWindow(s,w),overdue=Date.now()>Date.parse(window.dueAt);
        if(customer&&w.status==='Ter controle')result.push({key:'log-'+w.id,projectId:w.projectId,page:'logs',id:'week:'+w.id,title:overdue?'Logboeken: bevestigingstermijn verstreken':'Logboeken: ontvangst bevestigen',body:`${s.projects.find(p=>p.id===w.projectId)?.name} · Je hebt 48 uur vanaf het controlemoment om ontvangst te bevestigen.`,button:'Logboeken controleren',kind:'log'});
        if(internal&&(w.status==='Opmerking'||(w.status==='Ter controle'&&overdue)))result.push({key:'log-review-'+w.id,projectId:w.projectId,page:'logs',id:'week:'+w.id,title:w.status==='Opmerking'?'Klantopmerking op logboeken':'48 uur verstreken — ontvangst navragen',body:w.response?.note||'Er is nog geen ontvangstbevestiging van de klant.',button:'Logboekdossier openen',kind:'review'});
        if(internal&&w.status==='Ontvangen en gecontroleerd'&&!s.deliveries.some(d=>d.weeklyId===w.id&&(d.manual||d.status==='Afgeleverd')))result.push({key:'log-mail-'+w.id,projectId:w.projectId,page:'logs',id:'week:'+w.id,title:'Projectinformatie per mail versturen',body:'De klant heeft de logboeken gecontroleerd. Rond de mailbevestiging af.',button:'Projectpakket openen',kind:'mail'});
    }

    if(canReview(a))for(const c of s.contractSubmissions.filter(c=>c.status==='Ter controle'))result.push({key:'contract-'+c.id,page:'agreements',id:c.id,title:'Klantovereenkomst beoordelen',body:`${s.customers.find(x=>x.id===c.customerId)?.name||'Klant'} · ${c.file.name}`,button:'Upload beoordelen',kind:'review'});
    if(customer||pro)for(const n of s.notifications){
        const own=customer?n.audience==='customer'&&(n.customerId===a.customerId||!n.customerId&&s.projects.some(p=>p.id===n.projectId&&p.customerId===a.customerId)):n.audience==='professional'&&n.professionalId===a.professionalId;
        const actor=a.userId||a.professionalId||a.customerId||a.name;
        if(own&&/afgewezen|afgekeurd/i.test(n.title)&&!s.notificationReads.some(r=>r.id===n.id&&r.actor===actor)&&!s.requests.some(r=>r.id===n.recordId&&r.deletedAt))result.push({key:'notice-'+n.id,requestId:n.page==='requests'?n.recordId:undefined,projectId:n.projectId,page:(n.page||'notifications') as Page,id:n.recordId||'',title:n.title,body:n.body,button:'Afwijzing bekijken',kind:'notice'});
    }
    return result;
}
