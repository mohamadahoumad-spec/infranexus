export type FileAsset = {
    name: string;
    url: string;
    mime: string;
    size: number;
};
export type PrivateStaffFile = {
    id: string;
    ownerType: 'candidate' | 'professional';
    ownerId: string;
    kind: 'CV' | 'HR-document';
    file: FileAsset;
    uploadedAt: string;
};
export type MonthAvailability = {
    id: string;
    professionalId: string;
    month: string;
    days: Record<string, string>;
    submittedAt: string;
    submittedBy: string;
};
export type LogTemplate = {
    id: string;
    projectId: string;
    customerId?: string;
    scope?: 'company' | 'project';
    name?: string;
    version: number;
    file: FileAsset;
    uploadedAt: string;
    uploadedBy: string;
};
export type FilledLogVersion = {
    handoverRequested?:boolean;reviewAssignedTo?:string;customerVisible?:boolean;publishedAt?:string;publishedBy?:string;submittedBy?:string;purgedAt?:string;
    files?: LogAttachment[];
    details?: DayLogDetails;
    version: number;
    file: FileAsset;
    templateId: string;
    templateVersion: number;
    status: 'Ingediend' | 'In controle' | 'Goedgekeurd' | 'Definitief' | 'Correctie gevraagd';
    submittedAt: string;
    reviewedBy?: string;
    reviewedAt?: string;
    note?: string;
};
export type LogAttachment = {id:string;file:FileAsset;category:'Daglogboek'|'Foto'|'Meetstaat'|'Transportbewijs'|'Overig';caption?:string;relatedKind?:'Werkzaamheden'|'Bevinding'|'Actie';relatedId?:string};
export type DayLogDetails = {functionNotes?:string;workArea?:string;activities?:string;observations?:string;measurements?:string;materials?:string;deviations?:string};
export type FilledLog = {
    withdrawnAt?:string;withdrawnBy?:string;withdrawReason?:string;
    id: string;
    projectId: string;
    professionalId: string;
    date: string;
    versions: FilledLogVersion[];
};
export type Conversation = {
    id: string;
    kind: 'customer' | 'professional' | 'internal';
    customerId?: string;
    professionalId?: string;
    participants?: string[];
    department: 'HR' | 'Planning' | 'Customer Support' | 'Financieel';
    title: string;
    urgent: boolean;
    createdAt: string;
};
export type ChatMessage = {
    id: string;
    conversationId: string;
    author: string;
    side: 'internal' | 'external';
    body: string;
    at: string;
};
export type InvoiceVersion = {
    version: number;
    file?: FileAsset;
    amountCents: number;
    submittedAt: string;
};
export type Invoice = {
    id: string;
    kind: 'customer' | 'supplier';
    number: string;
    customerId?: string;
    professionalId?: string;
    projectIds: string[];
    week: string;
    issued: string;
    due: string;
    description: string;
    amountCents: number;
    status: 'Concept' | 'Gedeeld' | 'Ingediend' | 'HR akkoord' | 'Correctie gevraagd' | 'In betaling' | 'Betaald';
    versions: InvoiceVersion[];
    hrBy?: string;
    hrAt?: string;
    hrNote?: string;
    financeBy?: string;
    paymentReference?: string;
    paidAt?: string;
};
export type Branding = {
    id: string;
    logo: string;
    name: string;
};
export type OperationsState = {
    staffFiles: PrivateStaffFile[];
    monthlyAvailability: MonthAvailability[];
    logTemplates: LogTemplate[];
    filledLogs: FilledLog[];
    conversations: Conversation[];
    chatMessages: ChatMessage[];
    invoices: Invoice[];
    branding: Branding[];
};
export function operationsSeed(): OperationsState {
    const days = Object.fromEntries(Array.from({ length: 31 }, (_, i) => { const date = `2026-10-${String(i + 1).padStart(2, '0')}`; return [date, [0, 6].includes(new Date(date + 'T12:00:00Z').getUTCDay()) ? 'Niet beschikbaar' : 'Beschikbaar']; }));
    return { staffFiles: [], monthlyAvailability: ['pro1', 'pro2', 'pro3', 'pro4', 'pro5', 'pro6'].map((professionalId, i) => ({ id: `month${i}`, professionalId, month: '2026-10', days: { ...days, ...(professionalId === 'pro5' ? { '2026-10-06': 'Niet beschikbaar' } : {}) }, submittedAt: '2026-09-25T12:00:00Z', submittedBy: 'Voorbeeldprofessional' })), logTemplates: [], filledLogs: [], conversations: [], chatMessages: [], invoices: [], branding: [{ id: 'infranexus', logo: '/brand/infranexus-primary.png', name: 'InfraNexus Veiligheid & Milieu' }] };
}
