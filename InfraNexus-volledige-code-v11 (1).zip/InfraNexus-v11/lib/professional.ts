/** Shared professional workflows. These are demo rules, not server authorization. */
import { type Account, type Assignment, type CertificateSubmission, type DemoState, type DocumentReceipt, type Logbook, type ProjectReport, TODAY, canReview, canPlan, isInternal, isProfessional, seed, uid, visibleAssignments, visibleDocs, visibleProjects, } from './demo.ts';
export function hydrateDemoState(raw: unknown): DemoState {
    if (!raw || typeof raw !== 'object')
        throw new Error('Ongeldige demo-opslag.');
    const value = raw as Record<string, unknown>;
    const base = seed();
    const original = ['projects', 'customers', 'professionals', 'assignments', 'availability', 'candidates', 'logbooks', 'documents', 'requests', 'audit', 'notifications'];
    if (!original.every(key => Array.isArray(value[key])))
        throw new Error('Ongeldige demo-opslag.');
    // Missing extension collections receive defaults; existing user edits are retained.
    const result = Object.fromEntries(Object.entries(base).map(([key, fallback]) => [key, Array.isArray(value[key]) ? value[key] : fallback])) as DemoState;
    result.projects = result.projects.map(p => p.role === 'V&G' ? { ...p, role: 'Geen personeelsinzet', service: 'V&G-plan' } : p);
    result.requests = result.requests.map(r => r.role === 'V&G' ? { ...r, role: 'Geen personeelsinzet', service: 'V&G-plan' } : r);
    result.professionals = result.professionals.map(p => p.role === 'V&G' ? { ...p, role: 'Functie afstemmen' } : p);
    result.candidates = result.candidates.map(p => p.role === 'V&G' ? { ...p, role: 'Functie afstemmen' } : p);
    return result;
}
export function isoRange(from: string, to: string): string[] {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(from) || !/^\d{4}-\d{2}-\d{2}$/.test(to))
        throw new Error('Vul een geldige periode in.');
    const start = Date.parse(`${from}T12:00:00Z`), end = Date.parse(`${to}T12:00:00Z`);
    if (!Number.isFinite(start) || !Number.isFinite(end) || end < start)
        throw new Error('De einddatum moet op of na de startdatum liggen.');
    const days = Math.round((end - start) / 86400000) + 1;
    if (days > 62)
        throw new Error('Kies maximaal 62 dagen per wijziging in deze demo.');
    return Array.from({ length: days }, (_, i) => new Date(start + i * 86400000).toISOString().slice(0, 10));
}
function requireProfessional(account: Account): string {
    if (!isProfessional(account) || !account.professionalId)
        throw new Error('Deze handeling is alleen voor de eigen professional.');
    return account.professionalId;
}
export function availabilityConflicts(s: DemoState, a: Account, from: string, to: string, status: string): Assignment[] {
    const id = requireProfessional(a);
    const dates = isoRange(from, to);
    return status === 'Beschikbaar' ? [] : s.assignments.filter(x => x.professionalId === id && dates.includes(x.date));
}
export function setOwnAvailability(s: DemoState, a: Account, from: string, to: string, status: string): DemoState {
    const id = requireProfessional(a), dates = isoRange(from, to);
    if (!['Beschikbaar', 'Niet beschikbaar', 'Vakantie / afwezig'].includes(status))
        throw new Error('Ongeldige beschikbaarheid.');
    if (availabilityConflicts(s, a, from, to, status).length)
        throw new Error('Er staat al inzet in deze periode. Stem een wijziging af met planning.');
    return { ...s, availability: [...s.availability.filter(v => v.professionalId !== id || !dates.includes(v.date)), ...dates.map(date => ({ id: uid(), professionalId: id, date, status }))], notifications: [{ id: uid(), title: 'Beschikbaarheid gewijzigd', body: `${a.name} · ${from} t/m ${to} · ${status}`, target: 'planning', read: false, professionalId: id, audience: 'internal' }, ...s.notifications] };
}
export function acknowledgeWeek(s: DemoState, a: Account, dates: string[]): DemoState {
    const id = requireProfessional(a);
    const at = new Date().toISOString();
    const changed = s.assignments.filter(x => x.professionalId === id && dates.includes(x.date) && !hasSeenPlanning(x));
    return { ...s, assignments: s.assignments.map(x => changed.some(c => c.id === x.id) ? { ...x, acknowledgedAt: at } : x), notifications: changed.length ? [{ id: uid(), title: 'Weekplanning bekeken', body: `${a.name} · ${dates[0]}`, target: 'planning', read: false, professionalId: id, audience: 'internal' }, ...s.notifications] : s.notifications };
}
export const hasSeenPlanning = (assignment: Assignment) => !!assignment.acknowledgedAt || assignment.status === 'Bevestigd';
export function professionalReports(s: DemoState, a: Account) {
    if (isInternal(a))
        return s.reports;
    if (!isProfessional(a))
        return [];
    const allowed = new Set(visibleProjects(s, a).map(p => p.id));
    return s.reports.filter(r => r.professionalId === a.professionalId && allowed.has(r.projectId));
}
export function addReport(s: DemoState, a: Account, data: Pick<ProjectReport, 'projectId' | 'type' | 'title' | 'description' | 'date'>): DemoState {
    const professionalId = requireProfessional(a);
    if (!visibleProjects(s, a).some(p => p.id === data.projectId))
        throw new Error('Dit project hoort niet bij jouw inzet.');
    if (!data.title.trim() || !data.description.trim())
        throw new Error('Vul een onderwerp en toelichting in.');
    const now = new Date().toISOString();
    const report: ProjectReport = { ...data, id: uid(), professionalId, title: data.title.trim(), description: data.description.trim(), status: 'Nieuw', response: '', createdAt: now, updatedAt: now };
    return { ...s, reports: [report, ...s.reports], notifications: [{ id: uid(), title: 'Nieuwe projectmelding', body: `${a.name} · ${data.title}`, target: 'meldingen', read: false, projectId: data.projectId, professionalId, audience: 'internal' }, ...s.notifications] };
}
export function respondToReport(s: DemoState, a: Account, id: string, status: ProjectReport['status'], response: string): DemoState {
    if (!canReview(a) && !canPlan(a))
        throw new Error('Geen bevoegdheid om projectmeldingen te beoordelen.');
    const report = s.reports.find(r => r.id === id);
    if (!report)
        throw new Error('Melding niet gevonden.');
    if (status === 'Afgehandeld' && !response.trim())
        throw new Error('Leg de terugkoppeling vast voordat je de melding afhandelt.');
    return { ...s, reports: s.reports.map(r => r.id === id ? { ...r, status, response: response.trim(), updatedAt: new Date().toISOString() } : r), notifications: [{ id: uid(), title: 'Reactie op je projectmelding', body: `${report.title} · ${status}`, target: 'meldingen', read: false, projectId: report.projectId, professionalId: report.professionalId, audience: 'professional' }, ...s.notifications] };
}
export function acknowledgeDocument(s: DemoState, a: Account, id: string): DemoState {
    const professionalId = requireProfessional(a);
    const doc = visibleDocs(s, a).find(d => d.id === id);
    if (!doc)
        throw new Error('Dit document is niet voor jou beschikbaar.');
    if (s.documentReceipts.some(r => r.documentId === id && r.version === doc.version && r.professionalId === professionalId))
        return s;
    const receipt: DocumentReceipt = { id: uid(), documentId: id, version: doc.version, professionalId, at: new Date().toISOString() };
    return { ...s, documentReceipts: [receipt, ...s.documentReceipts] };
}
export function submitCertificate(s: DemoState, a: Account, data: Omit<CertificateSubmission, 'id' | 'professionalId' | 'status' | 'submittedAt'>): DemoState {
    const professionalId = requireProfessional(a);
    if (!data.type || !data.issuer.trim() || !data.expiry || !data.url)
        throw new Error('Vul de gegevens in en voeg het bewijs toe.');
    if (data.achieved && data.achieved > data.expiry)
        throw new Error('De vervaldatum ligt vóór de behaaldatum.');
    const submission: CertificateSubmission = { ...data, id: uid(), professionalId, status: 'Controle nodig', submittedAt: new Date().toISOString() };
    return { ...s, certificateSubmissions: [submission, ...s.certificateSubmissions], notifications: [{ id: uid(), title: 'Kwalificatiebewijs ter controle', body: `${a.name} · ${data.type}`, target: 'professionals', read: false, professionalId, audience: 'internal' }, ...s.notifications] };
}
export function reviewCertificate(s: DemoState, a: Account, id: string, approved: boolean, reason: string): DemoState {
    if (!canReview(a))
        throw new Error('Alleen de backoffice kan een bewijs controleren.');
    const submission = s.certificateSubmissions.find(c => c.id === id);
    if (!submission || submission.status !== 'Controle nodig')
        throw new Error('Deze controle is al afgehandeld.');
    if (!reason.trim())
        throw new Error('Leg je beoordeling vast.');
    // Human review records only this certificate; it never changes a professional's release/quality status.
    const reviewed = { ...submission, status: (approved ? 'Goedgekeurd' : 'Afgekeurd') as CertificateSubmission['status'], reason: reason.trim(), reviewedBy: a.name, reviewedAt: new Date().toISOString() };
    return { ...s, certificateSubmissions: s.certificateSubmissions.map(c => c.id === id ? reviewed : c), professionals: approved ? s.professionals.map(p => p.id === submission.professionalId ? { ...p, certificates: [...p.certificates.map(c => c.type === submission.type ? { ...c, supersededAt: new Date().toISOString() } : c), { id: uid(), type: submission.type, expiry: submission.expiry, verified: true, submissionId: submission.id }] } : p) : s.professionals, notifications: [{ id: uid(), title: approved ? 'Kwalificatiebewijs gecontroleerd' : 'Aanvulling kwalificatiebewijs nodig', body: `${submission.type} · ${reason.trim()}`, target: 'kwalificaties', read: false, professionalId: submission.professionalId, audience: 'professional' }, ...s.notifications] };
}
export function ownLogForAssignment(s: DemoState, a: Account, assignment: Assignment): Logbook | undefined {
    if (!isProfessional(a) || assignment.professionalId !== a.professionalId)
        return undefined;
    return s.logbooks.find(l => l.professionalId === a.professionalId && l.projectId === assignment.projectId && l.date === assignment.date);
}
export function professionalTasks(s: DemoState, a: Account) {
    const own = visibleAssignments(s, a).filter(x => x.date <= TODAY);
    return own.filter(x => { if (s.filledLogs.some(l => l.professionalId === x.professionalId && l.projectId === x.projectId && l.date === x.date && ['Ingediend', 'Goedgekeurd'].includes(l.versions.at(-1)?.status || '')))
        return false; const log = ownLogForAssignment(s, a, x); return !log || ['Concept', 'Correctie gevraagd'].includes(log.status); }).map(x => ({ assignment: x, log: ownLogForAssignment(s, a, x) }));
}
