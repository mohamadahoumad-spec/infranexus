import type {PortalState} from './portal.ts';
import type {OrderTerms} from './workflow-types.ts';
import type {FileAsset} from './operations-types.ts';
export function projectOrderFiles(s:PortalState,t:OrderTerms):FileAsset[]{
 const p=s.projects.find(p=>p.id===t.projectId);if(!p)return [];
 const vg=s.documents.find(d=>d.id===p.vgDocumentId&&d.projectId===p.id)||s.documents.filter(d=>d.projectId===p.id&&d.type==='V&G-plan'&&(d.status==='Gecontroleerd'||s.requests.some(r=>r.id===d.requestId&&r.projectId===p.id&&r.status==='Geaccepteerd'))).sort((a,b)=>b.version-a.version)[0];
 return vg?.url?[{name:vg.name,url:vg.url,mime:vg.mime||'application/pdf',size:vg.size||1}]:[];
}
