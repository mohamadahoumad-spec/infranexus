import {operationsSeed,type OperationsState,type FileAsset} from './operations-types.ts';
/** Fictional data for blueprint review. Never use this store as an authorization boundary. */
export const TODAY = '2026-10-06';
export type Role = 'SUPERVISOR'|'SUPER ADMIN'|'ADMIN'|'PLANNING'|'BACKOFFICE'|'FINANCIEEL'|'ACADEMY BEHEER'|'PROFESSIONAL'|'KLANT ADMIN'|'KLANT GEBRUIKER'|'HR'|'CUSTOMER SUPPORT'|'BUSINESS DEVELOPMENT';
export type View = 'dashboard'|'planning'|'projecten'|'professionals'|'kandidaten'|'klanten'|'logboeken'|'documenten'|'opdrachten'|'academy'|'aanvragen'|'financieel'|'meldingen'|'rapportages'|'beheer'|'kwalificaties'|'profiel'|'chat'|'beschikbaarheid'|'branding';
export type Account = {projectIds?:string[];userId?:string;email?:string;role:Role; name:string; initials:string; professionalId?:string; customerId?:string};
export const accounts: Account[] = [
 {role:'SUPER ADMIN',name:'Sophie de Groot',initials:'SG'},
 {role:'ADMIN',name:'Admin · voorbeeld',initials:'AD'},
 {role:'PLANNING',name:'Planner · voorbeeld',initials:'PL'},
 {role:'BACKOFFICE',name:'Backoffice · voorbeeld',initials:'BO'},
 {role:'FINANCIEEL',name:'Finance · voorbeeld',initials:'FI'},
 {role:'ACADEMY BEHEER',name:'Academy · voorbeeld',initials:'AC'},
 {role:'PROFESSIONAL',name:'Daan Vermeer',initials:'DV',professionalId:'pro1'},
 {role:'PROFESSIONAL',name:'Lisa van Dijk',initials:'LD',professionalId:'pro2'},
 {role:'KLANT ADMIN',name:'Delta Infra',initials:'DI',customerId:'c1'},
 {role:'KLANT GEBRUIKER',name:'Noordlijn Civiel',initials:'NC',customerId:'c2'},
 {role:'HR',name:'HR-team',initials:'HR'},
 {role:'CUSTOMER SUPPORT',name:'Customer Support',initials:'CS'},
 {role:'BUSINESS DEVELOPMENT',name:'Business Development',initials:'BD'},
];
export const isCustomer=(a:Account)=>a.role.startsWith('KLANT');
export const isProfessional=(a:Account)=>a.role==='PROFESSIONAL';
export const isInternal=(a:Account)=>!isCustomer(a)&&!isProfessional(a);
export const canFinance=(a:Account)=>['SUPER ADMIN','ADMIN','FINANCIEEL'].includes(a.role);
export const canManage=(a:Account)=>['SUPER ADMIN','ADMIN'].includes(a.role);
export const canPlan=(a:Account)=>['SUPER ADMIN','ADMIN','SUPERVISOR','PLANNING','HR','BACKOFFICE'].includes(a.role);
export const canReview=(a:Account)=>['SUPER ADMIN','ADMIN','SUPERVISOR','BACKOFFICE','HR'].includes(a.role);
export const projectStatuses=['Concept','Aanvraag','Planning nodig','Ingepland','Actief','On hold','Afronding','Afgerond','Geannuleerd'];
export const candidateStages=['Nieuw','Te beoordelen','Contact opnemen','Screening','Documentencontrole','Onboarding','Praktijkcheck','Voorwaardelijk vrijgegeven','Vrijgegeven','Gewonnen','Niet passend'];
export const checklistItems=['Eerste screening afgerond','Documenten gecontroleerd','Kwalificaties gecontroleerd','InfraNexus Protocol afgerond','Logboekwerkwijze uitgelegd','Projectcommunicatie uitgelegd','Kledingafspraken bevestigd','Praktijk-/testfase beoordeeld','Beoordeling afgerond','Vrijgave goedgekeurd'];
export type Customer={kvk?:string;vatNumber?:string;logoUrl?:string;id:string;name:string;city:string;contact:string;email:string;phone:string;status:string;address:string;notes:string};
export type Project={postcode?:string;street?:string;houseNumber?:string;startTime?:string;endTime?:string;breakMinutes?:number;expectedHoursPerDay?:number;vgDocumentId?:string;safetyClass?:string;service?:string;id:string;number:string;name:string;customerId:string;city:string;address:string;role:string;start:string;end:string;status:string;contact:string;phone:string;description:string;notes:string};
export type Certificate={supersededAt?:string;submissionId?:string;id:string;type:string;expiry:string;verified:boolean};
export type Professional={vatNumber?:string;address?:string;company?:string;kvk?:string;id:string;name:string;initials:string;city:string;role:string;status:string;quality:string;email:string;phone:string;certificates:Certificate[]};
export type Assignment={cancellationReason?:string;availabilityWarning?:{by:string;at:string;missingMonths:string[]};orderId?:string;expectedHours?:number;availabilityConfirmation?:{by:string;at:string;note:string};acknowledgedAt?:string;id:string;projectId:string;professionalId:string;date:string;role:string;start:string;end:string;status:string};
export type Availability={id:string;professionalId:string;date:string;status:string};
export type Candidate={vatNumber?:string;phone?:string;company?:string;kvk?:string;id:string;name:string;city:string;role:string;email:string;status:string;experience:string;date:string;checklist:string[];convertedId?:string};
export type LogVersion={projectId?:string;professionalId?:string;date?:string;start?:string;end?:string;photos?:{name:string;url:string;caption:string}[];version:number;status:string;at:string;actor:string;work:string;findings:string;deviations:string;actions:string;handover:string;comment:string};
export type Logbook={reviewNote?:string;id:string;projectId:string;professionalId:string;date:string;start:string;end:string;status:string;work:string;findings:string;deviations:string;actions:string;handover:string;comment:string;photos:{name:string;url:string;caption:string}[];versions:LogVersion[]};
export type Doc={previous?:Doc[];userIds?:string[];requestId?:string;customerId?:string;id:string;projectId:string;name:string;type:string;audience:string;version:number;date:string;status:string;url?:string;mime?:string;size?:number};
export type RequestItem={withdrawnAt?:string;withdrawnBy?:string;deletedAt?:string;existingProjectId?:string;projectNumber?:string;street?:string;houseNumber?:string;postcode?:string;city?:string;contactName?:string;contactPhone?:string;startTime?:string;endTime?:string;breakMinutes?:number;expectedHoursPerDay?:number;revision?:number;projectName?:string;dates?:string[];safetyClass?:string;service?:string;vgPlan?:FileAsset;id:string;customerId:string;projectId:string;role:string;date:string;duration:string;location:string;hours:string;urgent:boolean;description:string;status:string};
export type Audit={id:string;at:string;actor:string;action:string;entity:string;entityId:string;before:string;after:string};
export type Notification={customerId?:string;recordId?:string;page?:string;at?:string;id:string;title:string;body:string;target:View;read:boolean;projectId?:string;professionalId?:string;audience:'internal'|'professional'|'customer'};
export type ProjectReport={id:string;projectId:string;professionalId:string;date:string;type:string;title:string;description:string;status:'Nieuw'|'In behandeling'|'Afgehandeld';response:string;createdAt:string;updatedAt:string};
export type CertificateSubmission={submittedBy?:string;source?:'Professional'|'Per e-mail aan HR'|'Door HR toegevoegd';candidateId?:string;sharedWithCustomer?:boolean;id:string;professionalId:string;type:string;issuer:string;achieved:string;expiry:string;name:string;url:string;mime:string;status:'Controle nodig'|'Goedgekeurd'|'Afgekeurd';submittedAt:string;reviewedBy?:string;reviewedAt?:string;reason?:string};
export type DocumentReceipt={id:string;documentId:string;version:number;professionalId:string;at:string};
export type CourseEnrollment={id:string;professionalId:string;name:string;status:string;date?:string;location:string;steps:{label:string;complete:boolean}[]};
export type DemoState=OperationsState & {reports:ProjectReport[];certificateSubmissions:CertificateSubmission[];documentReceipts:DocumentReceipt[];enrollments:CourseEnrollment[];projects:Project[];customers:Customer[];professionals:Professional[];assignments:Assignment[];availability:Availability[];candidates:Candidate[];logbooks:Logbook[];documents:Doc[];requests:RequestItem[];audit:Audit[];notifications:Notification[]};

export function seed():DemoState{return {...operationsSeed(),
 reports:[],certificateSubmissions:[],documentReceipts:[],
 enrollments:[{id:'en1',professionalId:'pro1',name:'R-DLP traject / theorie',status:'In uitvoering',location:'Nog af te stemmen',steps:[{label:'Inschrijving bevestigd',complete:true},{label:'Theorie',complete:true},{label:'Toetsing / externe onderdelen',complete:false},{label:'Praktijkontwikkeling',complete:false}]},{id:'en2',professionalId:'pro2',name:'KVP + asbestherkenning',status:'In voorbereiding',location:'Nog af te stemmen',steps:[{label:'Inschrijving bevestigd',complete:true},{label:'Theorie',complete:false},{label:'Toetsing / externe onderdelen',complete:false},{label:'Praktijkontwikkeling',complete:false}]}],
 customers:[
 {id:'c1',name:'Delta Infra',city:'Rotterdam',contact:'Mark de Bruin',email:'projecten@delta-infra.example',phone:'010 000 0101',status:'Actieve klant',address:'Havenstraat 24, Rotterdam',notes:'Vaste projectafstemming op maandag. Contact via projectleider.'},
 {id:'c2',name:'Noordlijn Civiel',city:'Utrecht',contact:'Eva Jansen',email:'projecten@noordlijn.example',phone:'030 000 0202',status:'Actieve klant',address:'Kanaalweg 18, Utrecht',notes:'Werkvoorbereiding ontvangt de weekplanning.'},
 {id:'c3',name:'Terra Bouw & Milieu',city:'Breda',contact:'Pieter Visser',email:'planning@terra.example',phone:'076 000 0303',status:'Actieve klant',address:'Industrieweg 10, Breda',notes:'Nieuwe raamovereenkomst nog afstemmen.'}],
 projects:[
 {id:'p1',number:'INX-2026-041',name:'Bodemsanering Maasvlakte',customerId:'c1',city:'Rotterdam',address:'Europaweg 12, Maasvlakte',role:'R-DLP',start:'2026-09-21',end:'2026-11-13',status:'Actief',contact:'Mark de Bruin',phone:'010 000 0101',description:'Begeleiding van de bodemsanering op het werkterrein Maasvlakte. Dagelijkse afstemming met de uitvoerder en vastlegging in het projectdossier.',notes:'Interne afstemming: bezetting voor week 43 controleren.'},
 {id:'p2',number:'INX-2026-042',name:'Herinrichting Stationsgebied',customerId:'c2',city:'Utrecht',address:'Stationsplein 8, Utrecht',role:'DLP',start:'2026-10-05',end:'2026-12-04',status:'Actief',contact:'Eva Jansen',phone:'030 000 0202',description:'Toezicht en projectbegeleiding bij de herinrichting van het stationsgebied. Verzamelen bij de bouwkeet aan de zuidzijde.',notes:'Contact met werkvoorbereiding over vervolgopdracht.'},
 {id:'p3',number:'INX-2026-043',name:'Kabeltracé Westpoort',customerId:'c1',city:'Amsterdam',address:'Westhavenweg 14, Amsterdam',role:'DLP + KVP',start:'2026-10-07',end:'2026-10-30',status:'Planning nodig',contact:'Mark de Bruin',phone:'010 000 0101',description:'Begeleiding van grondwerkzaamheden voor het nieuwe kabeltracé in Westpoort.',notes:'Inzet voor woensdag nog bevestigen.'},
 {id:'p4',number:'INX-2026-038',name:'Reconstructie N279',customerId:'c3',city:'Veghel',address:'N279, werkvak 3, Veghel',role:'KVP',start:'2026-09-14',end:'2026-10-23',status:'Actief',contact:'Pieter Visser',phone:'076 000 0303',description:'Kwaliteitsbegeleiding tijdens reconstructie van het wegvak.',notes:'Project loopt volgens planning.'},
 {id:'p5',number:'INX-2026-040',name:'Waterberging De Rietvelden',customerId:'c2',city:'Den Bosch',address:'Rietveldenweg 5, Den Bosch',role:'DLP',start:'2026-09-28',end:'2026-10-16',status:'Afronding',contact:'Eva Jansen',phone:'030 000 0202',description:'Afronden projectadministratie na werkzaamheden aan de waterberging.',notes:'Einddossier controleren.'},
 {id:'p6',number:'INX-2026-044',name:'Gebiedsontwikkeling Havenkwartier',customerId:'c3',city:'Breda',address:'Havenkade 20, Breda',service:'V&G-plan',role:'Geen personeelsinzet',start:'2026-10-19',end:'2026-12-18',status:'Ingepland',contact:'Pieter Visser',phone:'076 000 0303',description:'Voorbereiding en begeleiding van de gebiedsontwikkeling.',notes:'Startoverleg staat gepland.'}],
 professionals:[
 {id:'pro1',name:'Daan Vermeer',initials:'DV',city:'Rotterdam',role:'R-DLP',status:'Vrijgegeven',quality:'Groen',email:'daan@voorbeeld.example',phone:'06 0000 0101',certificates:[{id:'cert1',type:'R-DLP',expiry:'2027-06-30',verified:true},{id:'cert2',type:'VCA-VOL',expiry:'2026-10-30',verified:true}]},
 {id:'pro2',name:'Lisa van Dijk',initials:'LD',city:'Utrecht',role:'DLP',status:'Vrijgegeven',quality:'Groen',email:'lisa@voorbeeld.example',phone:'06 0000 0202',certificates:[{id:'cert3',type:'DLP',expiry:'2027-04-15',verified:true},{id:'cert4',type:'VCA-VOL',expiry:'2028-08-15',verified:true}]},
 {id:'pro3',name:'Thomas Bakker',initials:'TB',city:'Amsterdam',role:'DLP + KVP',status:'Vrijgegeven',quality:'Groen',email:'thomas@voorbeeld.example',phone:'06 0000 0303',certificates:[{id:'cert5',type:'DLP',expiry:'2027-12-10',verified:true},{id:'cert6',type:'KVP',expiry:'2027-06-01',verified:true}]},
 {id:'pro4',name:'Ruben Smit',initials:'RS',city:'Eindhoven',role:'KVP',status:'Vrijgegeven',quality:'Groen',email:'ruben@voorbeeld.example',phone:'06 0000 0404',certificates:[{id:'cert7',type:'KVP',expiry:'2027-07-01',verified:true}]},
 {id:'pro5',name:'Nora de Jong',initials:'NJ',city:'Den Bosch',role:'DLP',status:'Voorwaardelijk',quality:'Oranje',email:'nora@voorbeeld.example',phone:'06 0000 0505',certificates:[{id:'cert8',type:'DLP',expiry:'2026-11-01',verified:true}]},
 {id:'pro6',name:'Jasper Meijer',initials:'JM',city:'Breda',role:'DLP',status:'Vrijgegeven',quality:'Groen',email:'jasper@voorbeeld.example',phone:'06 0000 0606',certificates:[]}],
 assignments:[0,1,2,3,4].flatMap(d=>[
 {id:`a1${d}`,projectId:'p1',professionalId:'pro1',date:`2026-10-${String(5+d).padStart(2,'0')}`,role:'R-DLP',start:'07:00',end:'16:00',status:d>1?'Ingepland':'Bevestigd'},
 {id:`a2${d}`,projectId:d<3?'p2':'p5',professionalId:'pro2',date:`2026-10-${String(5+d).padStart(2,'0')}`,role:'DLP',start:'07:30',end:'16:30',status:'Bevestigd'},
 {id:`a4${d}`,projectId:'p4',professionalId:'pro4',date:`2026-10-${String(5+d).padStart(2,'0')}`,role:'KVP',start:'07:00',end:'16:00',status:'Bevestigd'},
 ...(d>2?[{id:`a3${d}`,projectId:'p3',professionalId:'pro3',date:`2026-10-0${5+d}`,role:'DLP + KVP',start:'07:00',end:'16:00',status:'Voorlopig'}]:[])]),
 availability:[{id:'av1',professionalId:'pro5',date:'2026-10-06',status:'Niet beschikbaar'}],
 candidates:[
 {id:'k1',name:'Tim van Leeuwen',city:'Dordrecht',role:'DLP',email:'tim@voorbeeld.example',status:'Nieuw',experience:'3 jaar ervaring',date:'2026-10-06',checklist:[]},
 {id:'k2',name:'Anouk Peters',city:'Amersfoort',role:'KVP',email:'anouk@voorbeeld.example',status:'Nieuw',experience:'5 jaar ervaring',date:'2026-10-05',checklist:[]},
 {id:'k3',name:'Sander Bos',city:'Breda',role:'R-DLP',email:'sander@voorbeeld.example',status:'Screening',experience:'8 jaar ervaring',date:'2026-10-02',checklist:[checklistItems[0]]},
 {id:'k4',name:'Femke Mulder',city:'Leiden',role:'DLP',email:'femke@voorbeeld.example',status:'Documentencontrole',experience:'4 jaar ervaring',date:'2026-09-30',checklist:checklistItems.slice(0,2)},
 {id:'k5',name:'Kevin de Wit',city:'Tilburg',role:'KVP',email:'kevin@voorbeeld.example',status:'Onboarding',experience:'6 jaar ervaring',date:'2026-09-25',checklist:checklistItems.slice(0,6)}],
 logbooks:[
 {id:'l1',projectId:'p1',professionalId:'pro1',date:'2026-10-05',start:'07:00',end:'16:00',status:'Ingediend',work:'Werkvak A begeleid. Afstemming met de uitvoerder bij de dagstart.',findings:'Werkzaamheden uitgevoerd volgens afgesproken planning.',deviations:'Geen afwijkingen gemeld.',actions:'Werkvak B voorbereiden voor morgen.',handover:'Overdracht aan Mark de Bruin.',comment:'',photos:[],versions:[{version:1,status:'Ingediend',at:'2026-10-05T16:10:00Z',actor:'Daan Vermeer',work:'Werkvak A begeleid. Afstemming met de uitvoerder bij de dagstart.',findings:'Werkzaamheden uitgevoerd volgens afgesproken planning.',deviations:'Geen afwijkingen gemeld.',actions:'Werkvak B voorbereiden voor morgen.',handover:'Overdracht aan Mark de Bruin.',comment:''}]},
 {id:'l2',projectId:'p2',professionalId:'pro2',date:'2026-10-05',start:'07:30',end:'16:30',status:'Goedgekeurd',work:'Begeleiding werkzaamheden stationsplein, zuidelijk werkvak.',findings:'Dagstart en documentcontrole afgerond.',deviations:'Geen afwijkingen gemeld.',actions:'Werkvak noord afstemmen.',handover:'Overdracht aan Eva Jansen.',comment:'',photos:[],versions:[{version:1,status:'Goedgekeurd',at:'2026-10-06T06:45:00Z',actor:'Sophie de Groot',work:'Begeleiding werkzaamheden stationsplein, zuidelijk werkvak.',findings:'Dagstart en documentcontrole afgerond.',deviations:'Geen afwijkingen gemeld.',actions:'Werkvak noord afstemmen.',handover:'Overdracht aan Eva Jansen.',comment:''}]}],
 documents:[
 {id:'d1',projectId:'p1',name:'Projectinformatie Maasvlakte.pdf',type:'Projectdocument',audience:'Beide',version:2,date:'2026-10-05',status:'Gecontroleerd'},
 {id:'d2',projectId:'p1',name:'Werkafspraken en contactgegevens.pdf',type:'Projectdocument',audience:'Professional',version:1,date:'2026-10-02',status:'Gecontroleerd'},
 {id:'d3',projectId:'p1',name:'Interne projectafstemming.pdf',type:'Overig',audience:'Backoffice',version:1,date:'2026-10-05',status:'Controle nodig'},
 {id:'d4',projectId:'p2',name:'Situatietekening stationsgebied.pdf',type:'Projectdocument',audience:'Beide',version:3,date:'2026-10-04',status:'Gecontroleerd'},
 {id:'d5',projectId:'p3',name:'Projectinformatie Westpoort.pdf',type:'Projectdocument',audience:'Beide',version:1,date:'2026-10-06',status:'Controle nodig'},
 {id:'d6',projectId:'p4',name:'Werkplanning N279.pdf',type:'Projectdocument',audience:'Klant',version:2,date:'2026-10-03',status:'Gecontroleerd'}],
 requests:[{id:'r1',customerId:'c1',projectId:'p3',role:'DLP + KVP',date:'2026-10-07',duration:'3 weken',location:'Amsterdam',hours:'07:00 – 16:00',urgent:true,description:'Inzet voor het kabeltracé Westpoort.',status:'Nieuw'},{id:'r2',customerId:'c3',projectId:'p6',service:'V&G-plan',role:'Geen personeelsinzet',date:'2026-10-19',duration:'8 weken',location:'Breda',hours:'08:00 – 17:00',urgent:false,description:'Begeleiding startfase Havenkwartier.',status:'In behandeling'}],
 audit:[{id:'au1',at:'2026-10-06T07:15:00Z',actor:'Sophie de Groot',action:'Logboek goedgekeurd',entity:'Logboek',entityId:'l2',before:'Ingediend',after:'Goedgekeurd'},{id:'au2',at:'2026-10-06T06:40:00Z',actor:'Sophie de Groot',action:'Project aangemaakt',entity:'Project',entityId:'p3',before:'—',after:'Planning nodig'},{id:'au3',at:'2026-10-05T16:10:00Z',actor:'Daan Vermeer',action:'Logboek ingediend',entity:'Logboek',entityId:'l1',before:'Concept',after:'Ingediend'},{id:'au4',at:'2026-10-05T13:30:00Z',actor:'Sophie de Groot',action:'Document bijgewerkt',entity:'Document',entityId:'d1',before:'Versie 1',after:'Versie 2'}],
 notifications:[{id:'n1',title:'Westpoort: inzet nog open',body:'Woensdag 7 oktober · DLP + KVP',target:'planning',read:false,projectId:'p3',audience:'internal'},{id:'n2',title:'Logboek N279 ontbreekt',body:'Ruben Smit · maandag 5 oktober',target:'logboeken',read:false,projectId:'p4',audience:'internal'},{id:'n3',title:'VCA-VOL verloopt binnen 30 dagen',body:'Daan Vermeer · 30 oktober 2026',target:'kwalificaties',read:false,professionalId:'pro1',audience:'professional'},{id:'n4',title:'Nieuw projectdocument',body:'Projectinformatie Maasvlakte · versie 2',target:'documenten',read:false,projectId:'p1',audience:'customer'}]
};}

export function visibleProjects(s:DemoState,a:Account){return s.projects.filter(p=>isCustomer(a)?p.customerId===a.customerId:isProfessional(a)?s.assignments.some(x=>x.projectId===p.id&&x.professionalId===a.professionalId):true);}
export function visibleLogs(s:DemoState,a:Account){const ids=new Set(visibleProjects(s,a).map(p=>p.id));return s.logbooks.filter(l=>ids.has(l.projectId)&&(isProfessional(a)?l.professionalId===a.professionalId:isCustomer(a)?['Goedgekeurd','Definitief'].includes(l.status):true));}
export function documentSharedWith(d:Doc,a:Account){return d.status==='Gecontroleerd'&&(['Beide',isCustomer(a)?'Klant':'Professional'].includes(d.audience)||d.audience==='Specifieke gebruikers'&&!!a.userId&&d.userIds?.includes(a.userId));}
export function visibleDocs(s:DemoState,a:Account){const ids=new Set(visibleProjects(s,a).map(p=>p.id));return s.documents.filter(d=>isInternal(a)||(isCustomer(a)&&d.requestId&&s.requests.some(r=>r.id===d.requestId&&r.customerId===a.customerId))||(ids.has(d.projectId)&&documentSharedWith(d,a)));}
export function visibleAssignments(s:DemoState,a:Account){const ids=new Set(visibleProjects(s,a).map(p=>p.id));return s.assignments.filter(x=>x.status!=='Geannuleerd'&&ids.has(x.projectId)&&(!isProfessional(a)||x.professionalId===a.professionalId));}
export function certStatus(c:Certificate,date=TODAY){if(c.supersededAt)return 'Vervangen';if(!c.verified)return 'Controle nodig';const days=Math.ceil((Date.parse(c.expiry)-Date.parse(date))/86400000);return days<0?'Verlopen':days<=90?'Verloopt binnenkort':'Geldig';}
export function planningIssues(s:DemoState,personId:string,projectId:string,date:string){
 const p=s.professionals.find(p=>p.id===personId),project=s.projects.find(p=>p.id===projectId);if(!p||!project)return ['Selecteer een project en professional.'];
 const issues:string[]=[];
 const month=s.monthlyAvailability.find(m=>m.professionalId===personId&&m.month===date.slice(0,7));
 if(!month)issues.push('Maandbeschikbaarheid is nog niet ingediend.');
 else if(month.days[date]!=='Beschikbaar')issues.push('Professional heeft deze datum niet als beschikbaar opgegeven.');
 if(p.status!=='Vrijgegeven')issues.push('Professional is niet volledig vrijgegeven.');
 if(s.assignments.some(x=>x.status!=='Geannuleerd'&&x.professionalId===personId&&x.date===date))issues.push('Deze professional is al ingepland op deze dag.');
 if(s.availability.some(x=>x.professionalId===personId&&x.date===date&&x.status!=='Beschikbaar'))issues.push('Professional heeft deze dag als niet beschikbaar opgegeven.');
 if(project.service==='V&G-plan'||project.role==='Geen personeelsinzet')issues.push('Een V&G-plan is een dienst, geen personeelsinzet.');
 else if(project.role!=='V&G')project.role.split(' + ').forEach(role=>{if(!p.certificates.some(c=>c.type===role&&c.verified&&!c.supersededAt&&c.expiry>=date))issues.push(`Geen gecontroleerd ${role}-bewijs geldig op de inzetdatum.`);});
 if(project.role==='V&G')issues.push('Een V&G-plan is een dienst, geen personeelsinzet.');
 if(date<project.start||date>project.end)issues.push('Datum valt buiten de projectperiode.');
 return issues;
}
export const formatDate=(d:string)=>new Intl.DateTimeFormat('nl-NL',{day:'numeric',month:'short',year:'numeric',timeZone:'Europe/Amsterdam'}).format(new Date(d));
export const uid=()=>crypto.randomUUID();
export function weekDates(offset=0){return Array.from({length:5},(_,i)=>{const d=new Date('2026-10-05T12:00:00Z');d.setUTCDate(d.getUTCDate()+offset*7+i);return d.toISOString().slice(0,10);});}
export function missingLogs(s:DemoState){return s.assignments.filter(x=>x.status!=='Geannuleerd'&&x.date<TODAY&&!s.filledLogs.some(l=>l.projectId===x.projectId&&l.professionalId===x.professionalId&&l.date===x.date&&['Ingediend','Goedgekeurd'].includes(l.versions.at(-1)?.status||''))&&!s.logbooks.some(l=>l.projectId===x.projectId&&l.professionalId===x.professionalId&&l.date===x.date&&l.status!=='Concept'));}

/** A new immutable snapshot; photo objects are copied to preserve the earlier version. */
export function logSnapshot(log: Pick<Logbook,'projectId'|'professionalId'|'date'|'start'|'end'|'photos'|'work'|'findings'|'deviations'|'actions'|'handover'|'comment'>, status:string, version:number, actor:string, at=new Date().toISOString()):LogVersion {
 return {projectId:log.projectId,professionalId:log.professionalId,date:log.date,start:log.start,end:log.end,photos:log.photos.map(p=>({...p})),work:log.work,findings:log.findings,deviations:log.deviations,actions:log.actions,handover:log.handover,comment:log.comment,status,version,actor,at};
}
