'use client';
import type {FileAsset} from './operations-types';
import type {ContractMail,WeeklyLog} from './workflow-types';
import type {PortalState} from './portal';
import {contractEmailDraft} from './contracts';
import {emailDraft,projectMailFiles} from './workflows';
import {uniqueFiles} from './file-bundles';
export async function inlineMailFiles(files:FileAsset[]):Promise<FileAsset[]>{return Promise.all(uniqueFiles(files).map(async f=>{if(f.url.startsWith('data:'))return f;const response=await fetch(f.url,{credentials:'same-origin'});if(!response.ok)throw Error(`Bijlage niet beschikbaar: ${f.name}`);const bytes=new Uint8Array(await response.arrayBuffer());let text='';for(let i=0;i<bytes.length;i+=32768)text+=String.fromCharCode(...bytes.subarray(i,i+32768));return {...f,url:`data:${f.mime};base64,${btoa(text)}`,size:bytes.length};}));}
type Extra={attachments?:FileAsset[];body?:string;to?:string};
export async function contractDraftAsync(m:ContractMail,extra:Extra={}){const files=await inlineMailFiles([...m.files,...(m.manual?.attachments||[]),...(extra.attachments||[])]);return contractEmailDraft({...m,files,manual:m.manual?{...m.manual,attachments:[]}:undefined},{...extra,attachments:[]});}
export async function projectDraftAsync(s:PortalState,w:WeeklyLog,extra:Extra={}){const d=s.deliveries.find(d=>d.weeklyId===w.id),files=await inlineMailFiles([...(d?.files||projectMailFiles(s,w)),...(d?.manual?.attachments||[]),...(extra.attachments||[])]);return emailDraft({...s,deliveries:[{...d,id:d?.id||'download',projectId:w.projectId,weeklyId:w.id,to:d?.to||'',subject:d?.subject||'',status:d?.status||'Te versturen door HR',createdAt:d?.createdAt||'',files,manual:d?.manual?{...d.manual,attachments:[]}:undefined},...s.deliveries.filter(x=>x.weeklyId!==w.id)]},w,{...extra,attachments:[]});}
export function downloadEmail(text:string,name:string){const url=URL.createObjectURL(new Blob([text],{type:'message/rfc822'})),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),5000);}
