import {canReview,canPlan,isCustomer,isProfessional,visibleProjects,uid,type Account,type DemoState} from './demo.ts';
import type {PortalState} from './portal.ts';
import type {LogTemplate,LogAttachment,FilledLogVersion,FileAsset,DayLogDetails} from './operations-types.ts';
import {validateFiles} from './file-bundles.ts';
const need=(v:unknown,m:string)=>{if(!v)throw Error(m);};
export function logFiles(v:FilledLogVersion):LogAttachment[]{return v.files||[{id:'legacy-file',file:v.file,category:v.file.mime.startsWith('image/')?'Foto':'Daglogboek'}];}
export function templateApplies(s:DemoState,t:LogTemplate,projectId:string){const p=s.projects.find(p=>p.id===projectId);return !!p&&(t.scope==='company'?t.customerId===p.customerId:t.projectId===projectId);}
export function templatesForProject(s:DemoState,projectId:string){return s.logTemplates.filter(t=>templateApplies(s,t,projectId)).sort((a,b)=>Number(b.scope!=='company')-Number(a.scope!=='company')||b.version-a.version);}
export function publishCompanyTemplate(s:DemoState,a:Account,customerId:string,file:FileAsset,name=''):DemoState{
 need((canReview(a)||isCustomer(a)&&a.customerId===customerId)&&s.customers.some(c=>c.id===customerId),'Alleen HR of de eigen klant kan een bedrijfssjabloon plaatsen.');validateFiles([file],true);
 const t:LogTemplate={id:uid(),scope:'company',customerId,projectId:'',name:name.trim()||file.name,version:Math.max(0,...s.logTemplates.filter(t=>t.scope==='company'&&t.customerId===customerId).map(t=>t.version))+1,file,uploadedAt:new Date().toISOString(),uploadedBy:a.name};
 return {...s,logTemplates:[t,...s.logTemplates]};
}
export function saveDayBundle(s:PortalState,a:Account,projectId:string,professionalId:string,date:string,files:LogAttachment[],templateId='',details:DayLogDetails={}):PortalState{
 need(canPlan(a)||(isProfessional(a)&&professionalId===a.professionalId),'Alleen HR, Planning of de eigen professional wijzigt daglogboeken.');
 const today=new Intl.DateTimeFormat('sv-SE',{timeZone:'Europe/Amsterdam'}).format(new Date());
 need(s.assignments.some(x=>x.projectId===projectId&&x.professionalId===professionalId&&x.date===date&&(s.production?x.status==='Bevestigd':x.status!=='Geannuleerd'))&&date<=today,'Kies een eigen ingeplande, verstreken werkdag.');
 validateFiles(files.map(f=>f.file),true);need(new Set(files.map(f=>f.id)).size===files.length,'Een bestandsreferentie komt dubbel voor.');
 const t=s.logTemplates.find(t=>t.id===templateId);need(!templateId||t&&templateApplies(s,t,projectId),'Dit sjabloon hoort niet bij dit bedrijf of project.');
 const old=s.filledLogs.find(l=>l.projectId===projectId&&l.professionalId===professionalId&&l.date===date);
 const version:FilledLogVersion={version:(old?.versions.length||0)+1,file:{...files[0].file},files:files.map(f=>({...f,file:{...f.file}})),details:{...details},templateId:t?.id||'',templateVersion:t?.version||0,status:'Ingediend',...(s.production?{customerVisible:false}:{}),submittedAt:new Date().toISOString(),submittedBy:a.name};
 const l={id:old?.id||uid(),projectId,professionalId,date,withdrawnAt:undefined,versions:[...(old?.versions||[]),version]};
 return {...s,filledLogs:[l,...s.filledLogs.filter(x=>x.id!==l.id)]};
}
export const logDetailFields=[['workArea','Werkvak / locatie'],['activities','Werkzaamheden en voortgang'],['observations','Waarnemingen en omstandigheden'],['measurements','Metingen en monsterreferenties'],['materials','Grondstromen en transportreferenties'],['deviations','Afwijkingen, maatregelen en afspraken'],['functionNotes','Functiegerichte registratie']] as const;
export function logDetailLines(v:FilledLogVersion){return logDetailFields.flatMap(([key,label])=>v.details?.[key]?[`${label}: ${v.details[key]}`]:[]);}
