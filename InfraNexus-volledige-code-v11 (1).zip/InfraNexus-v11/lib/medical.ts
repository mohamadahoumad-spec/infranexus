export const medicalCertificateTypes=['Medische keuring bodemsanering A/B','Medische keuring bodemsanering C'];
export const isMedicalCertificate=(type:string)=>type.startsWith('Medische keuring bodemsanering');
