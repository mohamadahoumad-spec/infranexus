import type {PortalState} from './portal.ts';
import type {WeeklyLog} from './workflow-types.ts';
import {weekBounds} from './operations.ts';
export const amsterdamDateTime=(value:string|Date)=>new Intl.DateTimeFormat('sv-SE',{timeZone:'Europe/Amsterdam',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).format(new Date(value)).replace(' ','T');
export function amsterdamToIso(value:string){
    if(!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(value))throw Error('Kies een geldig tijdstip.');
    const desired=Date.parse(value+'Z');let guess=desired;
    for(let i=0;i<3;i++){const observed=Date.parse(amsterdamDateTime(new Date(guess))+'Z');guess+=desired-observed;}
    if(amsterdamDateTime(new Date(guess))!==value)throw Error('Dit lokale tijdstip bestaat niet. Kies een ander tijdstip.');
    return new Date(guess).toISOString();
}
export function reviewWindow(s:PortalState,projectId:string,week:string,sharedAt:string){
    const p=s.projects.find(p=>p.id===projectId);if(!p)throw Error('Project ontbreekt.');
    const [start,until]=weekBounds(week),friday=new Date(start+'T12:00:00Z');friday.setUTCDate(friday.getUTCDate()+4);
    const fridayDate=friday.toISOString().slice(0,10),end=p.end>=start&&p.end<=until&&p.end<fridayDate?p.end:fridayDate;
    const closingAt=amsterdamToIso(end+'T'+(p.endTime||'16:00'));
    const availableAt=new Date(Math.max(Date.parse(closingAt),Date.parse(sharedAt))).toISOString();
    return {closingAt,availableAt,dueAt:new Date(Date.parse(availableAt)+48*3600000).toISOString(),closingReason:end<fridayDate?'Projectafsluiting':'Vrijdagcontrole'};
}
export function logWindow(s:PortalState,w:WeeklyLog){return w.availableAt&&w.dueAt?{closingAt:w.closingAt!,availableAt:w.availableAt,dueAt:w.dueAt,closingReason:w.closingReason||'Logboekcontrole'}:reviewWindow(s,w.projectId,w.week,w.sharedAt);}
export const showDateTime=(iso:string)=>new Intl.DateTimeFormat('nl-NL',{timeZone:'Europe/Amsterdam',dateStyle:'medium',timeStyle:'short'}).format(new Date(iso));
