import {validateFiles} from './file-bundles.ts';
import {isMedicalCertificate,medicalCertificateTypes} from './medical.ts';
/** Prototype workflows. A production backend must enforce the same scopes. */
import { canReview, canPlan, canFinance, canManage, isInternal, isCustomer, isProfessional, visibleProjects, visibleAssignments, planningIssues, checklistItems, TODAY, uid, type Account, type DemoState, type RequestItem, type Candidate, type CertificateSubmission, type Project } from './demo.ts';
import type { FileAsset, Conversation, Invoice, FilledLogVersion } from './operations-types.ts';
export const staffRoles = ['DLP', 'R-DLP', 'KVP', 'MVK', 'HVK', 'DLP + KVP', 'R-DLP + KVP'];
export const safetyClasses = ['Basishygiëne', 'Oranje vluchtig', 'Oranje niet-vluchtig', 'Rood niet-vluchtig', 'Rood vluchtig', 'Zwart niet-vluchtig', 'Zwart vluchtig', 'Zwart CM-stoffen'];
export const certificateTypes = ['VCA', 'VCA-VOL', ...medicalCertificateTypes, 'DLP', 'R-DLP', 'KVP', 'MVK', 'HVK', 'BHV', 'Overig'];
const now = () => new Date().toISOString();
const requireRule = (ok: unknown, message: string) => { if (!ok)
    throw new Error(message); };
export const monthDates = (month: string) => {
    requireRule(/^\d{4}-(0[1-9]|1[0-2])$/.test(month), 'Kies een geldige maand.');
    const [y, m] = month.split('-').map(Number);
    return Array.from({ length: new Date(Date.UTC(y, m, 0)).getUTCDate() }, (_, i) => `${month}-${String(i + 1).padStart(2, '0')}`);
};
export const sortedDates = (dates: string[]) => { requireRule(dates.every(d => /^\d{4}-\d{2}-\d{2}$/.test(d) && !Number.isNaN(Date.parse(d)) && new Date(d).toISOString().slice(0, 10) === d), 'Kies geldige datums.'); return [...new Set(dates)].sort(); };
export function submitMonth(s: DemoState, a: Account, month: string, selected: string[]): DemoState {
    requireRule(isProfessional(a) && a.professionalId, 'Alleen de professional kan de eigen maand indienen.');
    const dates = monthDates(month), selectedSet = new Set(selected);
    requireRule(selected.every(d => dates.includes(d)), 'Een gekozen dag valt buiten deze maand.');
    const conflict = s.assignments.find(x => x.status!=='Geannuleerd'&&x.professionalId === a.professionalId && dates.includes(x.date) && !selectedSet.has(x.date));
    requireRule(!conflict, `Je bent al ingepland op ${conflict?.date}. Stem dit eerst af met Planning via de centrale chat.`);
    const days = Object.fromEntries(dates.map(d => [d, selectedSet.has(d) ? 'Beschikbaar' : 'Niet beschikbaar']));
    const record = { id: uid(), professionalId: a.professionalId!, month, days, submittedAt: now(), submittedBy: a.name };
    return { ...s, monthlyAvailability: [record, ...s.monthlyAvailability.filter(m => !(m.professionalId === a.professionalId && m.month === month))], availability: [...s.availability.filter(v => !(v.professionalId === a.professionalId && dates.includes(v.date))), ...dates.map(date => ({ id: uid(), professionalId: a.professionalId!, date, status: days[date] }))] };
}
export function scheduleMany(s: DemoState, a: Account, projectId: string, professionalId: string, dates: string[], start: string, end: string, status = 'Ingepland'): DemoState {
    requireRule(canPlan(a), 'Alleen HR en Planning kunnen inzet plannen.');
    const unique = sortedDates(dates);
    requireRule(unique.length > 0, 'Selecteer één of meer dagen.');
    requireRule(start < end, 'De eindtijd moet na de starttijd liggen.');
    const issues = unique.flatMap(d => planningIssues(s, professionalId, projectId, d).map(i => `${d}: ${i}`));
    requireRule(!issues.length, issues.join('\n'));
    const p = s.projects.find(p => p.id === projectId)!;
    return { ...s, assignments: [...s.assignments, ...unique.map(date => ({ id: uid(), projectId, professionalId, date, start, end, status, role: p.role }))], notifications: [{ id: uid(), title: 'Nieuwe meerdaagse inzet', body: `${p.name} · ${unique.length} dagen`, audience: 'professional', target: 'planning', professionalId, projectId, read: false }, ...s.notifications] };
}
export function createRequest(s: DemoState, a: Account, data: Omit<RequestItem, 'id' | 'projectId' | 'date' | 'duration' | 'status'>): DemoState {
    requireRule(isCustomer(a) || canPlan(a), 'Geen toegang tot aanvragen.');
    requireRule(!isCustomer(a) || data.customerId === a.customerId, 'Klant hoort niet bij dit account.');
    const dates = sortedDates(data.dates || []);
    requireRule(data.projectName?.trim() && dates.length && data.location.trim(), 'Vul projectnaam, locatie en datums in.');
    requireRule(safetyClasses.includes(data.safetyClass || ''), 'Kies de veiligheidsklasse zoals door de klant opgegeven.');
    requireRule(s.customers.some(c => c.id === data.customerId), 'Selecteer een klant.');
    requireRule(data.service === 'V&G-plan' || staffRoles.includes(data.role), 'Selecteer een geldige functie.');
    const r: RequestItem = { ...data, projectName: data.projectName!.trim(), dates, id: uid(), projectId: '', date: dates[0], duration: `${dates.length} dagen`, status: 'Nieuw', role: data.service === 'V&G-plan' ? 'Geen personeelsinzet' : data.role };
    return { ...s, documents: r.vgPlan ? [{ id: uid(), projectId: '', requestId: r.id, customerId: r.customerId, name: r.vgPlan.name, type: 'V&G-plan', audience: 'Backoffice', version: 1, date: TODAY, status: 'Controle nodig', url: r.vgPlan.url, mime: r.vgPlan.mime, size: r.vgPlan.size }, ...s.documents] : s.documents, requests: [r, ...s.requests], notifications: [{ id: uid(), title: 'Nieuwe klantaanvraag voor HR / Planning', body: `${r.projectName} · ${dates.length} dagen`, target: 'aanvragen', recordId:r.id, page:'requests', audience: 'internal', read: false }, ...s.notifications] };
}
export function acceptRequest(s: DemoState, a: Account, id: string): DemoState {
    requireRule(canPlan(a), 'Alleen HR / Planning verwerkt aanvragen.');
    const r = s.requests.find(r => r.id === id);
    requireRule(r && r.status === 'Nieuw' && !r.projectId, 'Deze aanvraag is al verwerkt.');
    const dates = sortedDates(r!.dates || [r!.date]), customer = s.customers.find(c => c.id === r!.customerId)!;
    requireRule(!r!.projectNumber || !s.projects.some(p => p.number === r!.projectNumber && p.id !== r!.existingProjectId), 'Dit projectnummer bestaat al.');
    const existing = s.projects.find(p=>p.id===r!.existingProjectId && p.customerId===r!.customerId);
    requireRule(!r!.existingProjectId || existing, 'Bestaand project hoort niet bij deze klant.');
    const project: Project = { ...existing, id: existing?.id || uid(), number: r!.projectNumber || existing?.number || `INX-${2026}-${String(Math.max(0,...s.projects.map(p=>Number(p.number.split('-').at(-1))||0))+1).padStart(3, '0')}`, name: r!.projectName || 'Nieuwe klus', customerId: customer.id, city: r!.city || r!.location, address: r!.location, street:r!.street,houseNumber:r!.houseNumber,postcode:r!.postcode,startTime:r!.startTime,endTime:r!.endTime,breakMinutes:r!.breakMinutes,expectedHoursPerDay:r!.expectedHoursPerDay, role: r!.role, service: r!.service, safetyClass: r!.safetyClass, start: existing&&existing.start<dates[0]?existing.start:dates[0], end: existing&&existing.end>dates.at(-1)!?existing.end:dates.at(-1)!, status: r!.service === 'V&G-plan' ? 'Aanvraag' : 'Planning nodig', contact: r!.contactName || customer.contact, phone: r!.contactPhone || customer.phone, description: r!.description, notes: 'Aanvraag door HR / Planning geaccepteerd.' };
    const vg=s.documents.find(d=>d.requestId===id&&d.type==='V&G-plan');if(vg)project.vgDocumentId=vg.id;
    return { ...s, projects: [project, ...s.projects.filter(p=>p.id!==project.id)], requests: s.requests.map(x => x.id === id ? { ...x, status: 'Geaccepteerd', projectId: project.id } : x), documents: s.documents.some(d=>d.requestId===id) ? s.documents.map(d=>d.requestId===id?{...d,projectId:project.id}:d) : r!.vgPlan ? [{id:uid(),requestId:id,customerId:r!.customerId,projectId:project.id,name:r!.vgPlan.name,type:'V&G-plan',audience:'Backoffice',version:1,date:TODAY,status:'Controle nodig',url:r!.vgPlan.url,mime:r!.vgPlan.mime,size:r!.vgPlan.size},...s.documents] : s.documents, notifications: [{ id: uid(), title: 'Aanvraag geaccepteerd', body: project.name, target: 'projecten', projectId: project.id, customerId:r!.customerId, page:'requests',recordId:id, audience: 'customer', read: false }, ...s.notifications] };
}
export function convertCandidate(s: DemoState, a: Account, id: string): DemoState {
    requireRule(canReview(a), 'Alleen HR kan een kandidaat omzetten.');
    const k = s.candidates.find(k => k.id === id);
    requireRule(k && (k.status === 'Gewonnen' || k.status === 'Vrijgegeven' && checklistItems.every(i => k.checklist.includes(i))) && !k.convertedId, 'Rond de vrijgave af voordat je een professional aanmaakt.');
    requireRule(!s.professionals.some(p=>p.email.toLowerCase()===k!.email.toLowerCase()), 'Er bestaat al een professionalaccount met dit e-mailadres. Gebruik dat dossier.');
    const professionalId = uid(), evidence = s.certificateSubmissions.filter(c => c.candidateId === id && c.status === 'Goedgekeurd');
    const latest = [...new Map([...evidence].reverse().map(c => [c.type, c])).values()];
    return { ...s, professionals: [{ id: professionalId, name: k!.name, initials: k!.name.split(' ').map(p => p[0]).slice(0, 2).join(''), city: k!.city, role: k!.role, status: 'Vrijgegeven', quality: 'Groen', email: k!.email, phone: k!.phone || '', company: k!.company || '', kvk: k!.kvk || '', vatNumber:k!.vatNumber||'', certificates: latest.map(c => ({ id: uid(), type: c.type, expiry: c.expiry, verified: true, submissionId: c.id })) }, ...s.professionals], candidates: s.candidates.map(c => c.id === id ? { ...c, convertedId: professionalId } : c), staffFiles: s.staffFiles.map(f => f.ownerType === 'candidate' && f.ownerId === id ? { ...f, ownerType: 'professional', ownerId: professionalId } : f), certificateSubmissions: s.certificateSubmissions.map(c => c.candidateId === id ? { ...c, professionalId } : c) };
}
export function staffFilesFor(s: DemoState, a: Account, ownerId: string) { return canReview(a) ? s.staffFiles.filter(f => f.ownerId === ownerId) : []; }
export function uploadCertificate(s: DemoState, a: Account, target: {
    professionalId?: string;
    candidateId?: string;
}, data: {
    source?:'Professional'|'Per e-mail aan HR'|'Door HR toegevoegd';
    type: string;
    issuer: string;
    achieved: string;
    expiry: string;
    file: FileAsset;
}): DemoState {
    requireRule(canReview(a) || (isProfessional(a) && target.professionalId === a.professionalId && !target.candidateId), 'Geen toegang tot dit certificaatdossier.');
    requireRule(target.candidateId ? s.candidates.some(c => c.id === target.candidateId) : s.professionals.some(p => p.id === target.professionalId), 'Dossier ontbreekt.');
    requireRule(certificateTypes.includes(data.type) && data.issuer.trim() && data.expiry && data.file, 'Vul de bewijsgegevens in.');
    requireRule(!data.achieved || data.achieved <= data.expiry, 'De vervaldatum ligt vóór de behaaldatum.');
    const record: CertificateSubmission = { ...target, professionalId: target.professionalId || '', id: uid(), type: data.type, issuer: data.issuer, achieved: data.achieved, expiry: data.expiry, name: data.file.name, url: data.file.url, mime: data.file.mime, status: 'Controle nodig', source:canReview(a)?data.source||'Door HR toegevoegd':'Professional',submittedBy:a.name, submittedAt: now(), sharedWithCustomer: false };
    return { ...s, certificateSubmissions: [record, ...s.certificateSubmissions], notifications: [{ id: uid(), title: 'Nieuw bewijs ter controle', body: `${data.type} · ${a.name}`,page:'checks',recordId:record.id,target: target.candidateId ? 'kandidaten' : 'professionals', audience: 'internal', read: false }, ...s.notifications] };
}
export function customerCertificates(s: DemoState, a: Account, projectId: string) {
    const project = visibleProjects(s, a).find(p => p.id === projectId);
    if (!project)
        return [];
    const ids = new Set(s.assignments.filter(x => x.projectId === projectId).map(x => x.professionalId));
    return s.certificateSubmissions.filter(c => ids.has(c.professionalId) && c.status === 'Goedgekeurd' && !isMedicalCertificate(c.type) && c.sharedWithCustomer && s.professionals.find(p => p.id === c.professionalId)?.certificates.some(x => x.submissionId === c.id && !x.supersededAt));
}
export function publishTemplate(s: DemoState, a: Account, projectId: string, file: FileAsset): DemoState {
    requireRule((canReview(a) || isCustomer(a)) && visibleProjects(s,a).some(p => p.id === projectId), 'Alleen HR of de betrokken klant kan een projectsjabloon plaatsen.');
    validateFiles([file],true);
    return { ...s, logTemplates: [{ id: uid(), projectId, scope:'project' as const,customerId:s.projects.find(p=>p.id===projectId)?.customerId, version: Math.max(0, ...s.logTemplates.filter(t => t.projectId === projectId).map(t => t.version)) + 1, file, uploadedAt: now(), uploadedBy: a.name }, ...s.logTemplates] };
}
export function submitFilledLog(s: DemoState, a: Account, templateId: string, date: string, file: FileAsset): DemoState {
    const t = s.logTemplates.find(t => t.id === templateId);
    requireRule(t && isProfessional(a) && s.assignments.some(x => x.status!=='Geannuleerd'&&x.professionalId === a.professionalId && x.projectId === t.projectId && x.date === date), 'Kies een eigen ingeplande projectdag.');
    const previous = s.filledLogs.find(l => l.projectId === t!.projectId && l.professionalId === a.professionalId && l.date === date);
    requireRule(!previous || previous.versions.at(-1)?.status === 'Correctie gevraagd', 'Dit logboek is al ingediend. Wacht op de beoordeling.');
    const version: FilledLogVersion = { version: (previous?.versions.length || 0) + 1, file, templateId, templateVersion: t!.version, status: 'Ingediend', submittedAt: now() };
    const record = previous ? { ...previous, versions: [...previous.versions, version] } : { id: uid(), projectId: t!.projectId, professionalId: a.professionalId!, date, versions: [version] };
    return { ...s, filledLogs: [record, ...s.filledLogs.filter(l => l.id !== record.id)] };
}
export function reviewFilledLog(s: DemoState, a: Account, id: string, approve: boolean, note: string): DemoState {
    requireRule(canReview(a), 'Alleen HR kan logboeken beoordelen.');
    const l = s.filledLogs.find(l => l.id === id), v = l?.versions.at(-1);
    requireRule(v && ['Ingediend','In controle'].includes(v.status), 'Dit bestand wacht niet op beoordeling.');
    requireRule(approve || note.trim(), 'Vul de correctiereden in.');
    return { ...s, filledLogs: s.filledLogs.map(x => x.id === id ? { ...x, versions: x.versions.map((v, i) => i === x.versions.length - 1 ? { ...v, status: approve ? 'Goedgekeurd' : 'Correctie gevraagd', reviewedBy: a.name, reviewedAt: now(), note } : v) } : x) };
}
export function visibleFilledLogs(s: DemoState, a: Account, projectId?: string) {
    const ids = new Set(visibleProjects(s, a).map(p => p.id));
    return s.filledLogs.filter(l => (!isCustomer(a)||(!l.withdrawnAt&&['Goedgekeurd','Definitief'].includes(l.versions.at(-1)?.status||'')&&l.versions.at(-1)?.customerVisible!==false)) && (!projectId || l.projectId === projectId) && ids.has(l.projectId) && (!isProfessional(a) || l.professionalId === a.professionalId)).map(l => isCustomer(a) ? { ...l, versions: l.versions.filter(v => ['Goedgekeurd','Definitief'].includes(v.status)&&v.customerVisible!==false).map(v=>({...v,note:undefined,reviewedBy:undefined})) } : l).filter(l => l.versions.length);
}
export function visibleConversations(s: DemoState, a: Account) { return s.conversations.filter(c => isCustomer(a) ? c.kind === 'customer' && c.customerId === a.customerId : isProfessional(a) ? c.kind === 'professional' && c.professionalId === a.professionalId : c.kind !== 'internal' || !!c.participants?.includes(a.name)); }
export function openConversation(s: DemoState, a: Account, data: Pick<Conversation, 'title' | 'department' | 'urgent'>, body: string, target?: {
    kind: 'customer' | 'professional' | 'internal';
    id: string;
}): DemoState {
    requireRule(data.title.trim() && body.trim(), 'Vul een onderwerp en bericht in.');
    let scoped: Partial<Conversation> = {};
    if (isCustomer(a))
        scoped = { kind: 'customer', customerId: a.customerId };
    else if (isProfessional(a))
        scoped = { kind: 'professional', professionalId: a.professionalId };
    else {
        requireRule(target, 'Kies de ontvanger.');
        if (target!.kind === 'customer') {
            requireRule(s.customers.some(c => c.id === target!.id), 'Klant ontbreekt.');
            scoped = { kind: 'customer', customerId: target!.id };
        }
        else if (target!.kind === 'professional') {
            requireRule(s.professionals.some(p => p.id === target!.id), 'Professional ontbreekt.');
            scoped = { kind: 'professional', professionalId: target!.id };
        }
        else
            scoped = { kind: 'internal', participants: [a.name, target!.id] };
    }
    const conversation = { ...data, ...scoped, id: uid(), createdAt: now() } as Conversation;
    return { ...s, conversations: [conversation, ...s.conversations], chatMessages: [...s.chatMessages, { id: uid(), conversationId: conversation.id, author: a.name, side: isInternal(a) ? 'internal' : 'external', body: body.trim(), at: now() }] };
}
export function sendChat(s: DemoState, a: Account, conversationId: string, body: string): DemoState {
    requireRule(visibleConversations(s, a).some(c => c.id === conversationId), 'Gesprek hoort niet bij jouw omgeving.');
    requireRule(body.trim(), 'Schrijf eerst een bericht.');
    return { ...s, chatMessages: [...s.chatMessages, { id: uid(), conversationId, author: a.name, side: isInternal(a) ? 'internal' : 'external', body: body.trim(), at: now() }] };
}
export function visibleInvoices(s: DemoState, a: Account) { return s.invoices.filter(i => isCustomer(a) ? i.kind === 'customer' && i.customerId === a.customerId && i.status !== 'Concept' : isProfessional(a) ? i.kind === 'supplier' && i.professionalId === a.professionalId : canFinance(a) || (canReview(a) && i.kind === 'supplier')); }
export const euro = (cents: number) => new Intl.NumberFormat('nl-NL', { style: 'currency', currency: 'EUR' }).format(cents / 100);
export function weekBounds(week: string) { requireRule(/^\d{4}-W\d{2}$/.test(week), 'Kies een week.'); const [y, w] = week.split('-W').map(Number); requireRule(w >= 1 && w <= 53, 'Ongeldige week.'); const fourth = new Date(Date.UTC(y, 0, 4)); fourth.setUTCDate(fourth.getUTCDate() - ((fourth.getUTCDay() + 6) % 7) + (w - 1) * 7); const start = fourth.toISOString().slice(0, 10); fourth.setUTCDate(fourth.getUTCDate() + 6); return [start, fourth.toISOString().slice(0, 10)]; }
export function invoiceProjects(s: DemoState, a: Account, week: string, customerId?: string) { const [start, end] = weekBounds(week); return visibleProjects(s, a).filter(p => (!customerId || p.customerId === customerId) && visibleAssignments(s, a).some(x => x.projectId === p.id && x.date >= start && x.date <= end)); }
export function createInvoice(s: DemoState, a: Account, data: Pick<Invoice, 'kind' | 'number' | 'customerId' | 'week' | 'issued' | 'due' | 'description' | 'amountCents' | 'projectIds'>, file?: FileAsset): DemoState {
    const supplier = data.kind === 'supplier';
    requireRule(supplier ? isProfessional(a) : canFinance(a), 'Je kunt deze factuur niet aanmaken.');
    const options = invoiceProjects(s, a, data.week, supplier ? undefined : data.customerId);
    requireRule(data.projectIds.length && data.projectIds.every(id => options.some(p => p.id === id)), 'Selecteer alleen projecten met inzet in deze week.');
    requireRule(data.number.trim() && Number.isSafeInteger(data.amountCents) && data.amountCents > 0 && data.due >= data.issued, 'Controleer nummer, bedrag en datums.');
    requireRule(!supplier || file?.mime === 'application/pdf', 'Voeg de zzp-factuur als PDF toe.');
    requireRule(!s.invoices.some(i => i.kind === data.kind && i.number === data.number && (supplier ? i.professionalId === a.professionalId : i.customerId === data.customerId)), 'Dit factuurnummer bestaat al in dit dossier.');
    const i: Invoice = { ...data, id: uid(), professionalId: supplier ? a.professionalId : undefined, status: supplier ? 'Ingediend' : 'Concept', versions: [{ version: 1, file, amountCents: data.amountCents, submittedAt: now() }] };
    return { ...s, invoices: [i, ...s.invoices] };
}
export function reviewInvoice(s: DemoState, a: Account, id: string, approve: boolean, note: string): DemoState {
    requireRule(canReview(a), 'Alleen HR kan de inhoud goedkeuren.');
    const i = s.invoices.find(i => i.id === id);
    requireRule(i?.kind === 'supplier' && i.status === 'Ingediend', 'Deze factuur wacht niet op HR.');
    requireRule(approve || note.trim(), 'Geef aan wat aangepast moet worden.');
    return { ...s, invoices: s.invoices.map(x => x.id === id ? { ...x, status: approve ? 'HR akkoord' : 'Correctie gevraagd', hrBy: approve ? a.name : undefined, hrAt: approve ? now() : undefined, hrNote: note } : x) };
}
export function reviseInvoice(s: DemoState, a: Account, id: string, file: FileAsset, amountCents: number): DemoState {
    const i = s.invoices.find(i => i.id === id);
    requireRule(isProfessional(a) && i?.professionalId === a.professionalId && i?.kind === 'supplier' && i.status === 'Correctie gevraagd', 'Deze factuur kan niet worden aangepast.');
    requireRule(file.mime === 'application/pdf' && Number.isSafeInteger(amountCents) && amountCents > 0, 'Controleer de PDF en het bedrag.');
    return { ...s, invoices: s.invoices.map(x => x.id === id ? { ...x, status: 'Ingediend', amountCents, hrBy: undefined, hrAt: undefined, hrNote: undefined, financeBy: undefined, paymentReference: undefined, paidAt: undefined, versions: [...x.versions, { version: x.versions.length + 1, file, amountCents, submittedAt: now() }] } : x) };
}
export function financeTransition(s: DemoState, a: Account, id: string, status: 'Gedeeld' | 'In betaling' | 'Betaald', reference = ''): DemoState {
    requireRule(canFinance(a), 'Alleen Finance verwerkt betalingen.');
    const i = s.invoices.find(i => i.id === id);
    requireRule(i, 'Factuur ontbreekt.');
    if (i!.kind === 'supplier')
        requireRule(!!i!.hrBy && !!i!.hrAt && ((status === 'In betaling' && i!.status === 'HR akkoord') || (status === 'Betaald' && i!.status === 'In betaling')), 'HR moet eerst goedkeuren, daarna verwerkt Finance de betaling.');
    else
        requireRule((status === 'Gedeeld' && i!.status === 'Concept') || (status === 'Betaald' && i!.status === 'Gedeeld'), 'Ongeldige factuurstap.');
    requireRule(status !== 'Gedeeld' || !!i!.versions.at(-1)?.file, 'Voeg eerst de definitieve factuur-PDF toe.');
    requireRule(status !== 'Betaald' || reference.trim(), 'Leg de betalingsreferentie vast.');
    return { ...s, invoices: s.invoices.map(x => x.id === id ? { ...x, status, financeBy: a.name, paymentReference: status === 'Betaald' ? reference : x.paymentReference, paidAt: status === 'Betaald' ? now() : x.paidAt } : x) };
}
