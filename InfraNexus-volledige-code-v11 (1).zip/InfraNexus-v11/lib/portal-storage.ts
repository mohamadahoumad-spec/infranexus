import { hydratePortal, portalSeed, type PortalState } from './portal';
const DB = 'infranexus-workspace-v2';
let observedToken:string|undefined;
function openStore(): Promise<IDBDatabase> {
 return new Promise((resolve,reject)=>{
  const request=indexedDB.open(DB,1);
  request.onupgradeneeded=()=>request.result.createObjectStore('workspace');
  request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error);
 });
}
export async function loadPortal():Promise<PortalState>{
 const db=await openStore();
 try {
  const raw=await new Promise<(PortalState & {_storageToken?:string})|undefined>((resolve,reject)=>{
   const request=db.transaction('workspace').objectStore('workspace').get('current');
   request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error);
  });
  const previous=!raw?localStorage.getItem('infranexus-blueprint-v1'):null;
  const state=raw?hydratePortal(raw):previous?hydratePortal(JSON.parse(previous)):portalSeed();
  observedToken=raw?._storageToken||'';
  return state;
 }finally{db.close();}
}
export async function savePortal(state:PortalState){
 if(observedToken===undefined)throw new Error('De opgeslagen werkruimte is niet geladen. Ververs de pagina voordat je wijzigingen opslaat.');
 const db=await openStore(),token=crypto.randomUUID();
 try{
  await new Promise<void>((resolve,reject)=>{
   const tx=db.transaction('workspace','readwrite'),store=tx.objectStore('workspace'),read=store.get('current');
   let conflict=false;
   read.onsuccess=()=>{
    if((read.result?._storageToken||'')!==observedToken){conflict=true;tx.abort();return;}
    store.put({...state,_storageToken:token},'current');
   };
   tx.oncomplete=()=>{observedToken=token;resolve();};
   tx.onerror=()=>reject(tx.error);
   tx.onabort=()=>reject(conflict?new Error('De werkruimte is in een ander tabblad gewijzigd. Ververs deze pagina; de andere wijzigingen zijn behouden.'):tx.error);
  });
 }finally{db.close();}
}
