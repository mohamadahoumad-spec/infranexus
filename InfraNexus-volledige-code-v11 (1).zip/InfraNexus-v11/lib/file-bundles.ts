import type {FileAsset} from './operations-types.ts';
export const documentAccept='application/pdf,image/jpeg,image/png,image/webp,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,text/plain,text/csv';
const allowed=new Set(documentAccept.split(','));
export function validateFiles(files:FileAsset[],required=false){
 if(required&&!files.length)throw Error('Voeg ten minste één bestand of foto toe.');
 if(files.length>50)throw Error('Voeg maximaal 50 bestanden per dossier toe.');
 if(files.some(f=>!allowed.has(f.mime)||!f.url||f.size<=0||f.size>10*1024*1024))throw Error('Gebruik PDF, foto, Word, Excel, CSV of tekst van maximaal 10 MB per bestand.');
 if(files.reduce((n,f)=>n+f.size,0)>50*1024*1024)throw Error('De bestanden zijn samen groter dan 50 MB. Verdeel de upload over kleinere dossiers.');
}
export function uniqueFiles(files:FileAsset[]){return files.filter((f,i)=>files.findIndex(x=>x.name===f.name&&x.url===f.url)===i);}
