# InfraNexus — volledige broncode, versie 11

Dit pakket bevat de broncode van het huidige InfraNexus-portaal, inclusief
schermen, bedrijfsregels, API, logo’s, database-migraties en tests. Je kunt deze
code blijven aanpassen en in een eigen Git-repository beheren.

Bronversie: f717c91e3e090e6deb13cf9f16c14cd57e78cb1e
Exportdatum: 22 oktober 2026

## 1. Lokaal openen

Pak de ZIP uit en open de map `InfraNexus-v11` in bijvoorbeeld Visual Studio Code.
Installeer Node.js 24 en pnpm 11.25.0 (de versie uit `package.json`). Open daarna
een terminal in die map:

```bash
pnpm install --frozen-lockfile
pnpm dev
```

Open http://localhost:5173/ voor de conceptomgeving. `/werkruimte` bevat de
centrale omgeving; `/uitnodiging` bevat de accountactivering. De centrale omgeving
heeft daarnaast een ingericht databaseschema en accountlidmaatschap nodig.
De lokale ontwikkelconfiguratie gebruikt een gesimuleerde platformidentiteit;
dit maakt niet automatisch een bevoegd account aan.

De eerste installatie downloadt de afhankelijkheden. `node_modules` en gebouwde
bestanden zitten daarom niet in de ZIP. De lockfile legt de pakketversies vast.

## 2. Controleren en bouwen

```bash
pnpm exec tsc --noEmit --incremental false
pnpm test
pnpm test:render
pnpm build
```

Na de build start `pnpm start` een lokale Wrangler-preview. Dit commando
publiceert niets op internet. Gebruik het lokale adres dat Wrangler vermeldt.

## 3. Lokale database voorbereiden

De tabellen staan in `db/schema.ts`. De bestaande SQL-migraties staan in
`drizzle/`. Voer na `pnpm build` onderstaande opdrachten één keer uit voor een
lege lokale database. Voer de tweede migratie na de eerste uit.

```bash
node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0000_bumpy_thundra.sql
node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0001_graceful_kang.sql
```

Deze opdrachten werken uitsluitend op lokale opslag. Ze bevatten geen klantdata
of testaccounts. `pnpm db:generate` is voor nieuwe schemawijzigingen; het past de
bestaande migraties niet toe.

## 4. Accountinrichting en hosting

De huidige hosting gebruikt Sites/ChatGPT voor de aanmelding en Cloudflare D1 en
R2 voor de centrale gegevens en bestanden. De keuzes Professional, Kantoor en
Klant bepalen het startscherm; de toegekende accountrol bepaalt de rechten.
De hoofdadmin richt accounts in en maakt persoonlijke uitnodigingen. De
uitnodigingsmail wordt via de eigen mailbox verstuurd.

Voor de eerste inrichting is `INFRANEXUS_SETUP_TOKEN` als servergeheim nodig.
`.env.example` toont alleen de naam; kies zelf een geheime waarde en bewaar die
buiten versiebeheer. Bij de bestaande hosting gebeurt dit via de
platforminstellingen. Na de eenmalige hoofdadmin-inrichting worden volgende
accounts door bevoegde beheerders ingericht.

Voor zelfstandige hosting moet een ontwikkelaar eigen D1/R2-resources en
bindings instellen en een geverifieerde inlogkoppeling aansluiten. De huidige
server vertrouwt op door het Sites-platform aangeleverde identiteitsheaders.
Een zelfstandig gehoste server mag zulke headers niet rechtstreeks van
bezoekers vertrouwen. Alleen de bestanden op een webhost zetten levert dus nog
geen zelfstandige veilige accountaanmelding op.

De bestaande Site-configuratie staat ongewijzigd in `.openai/hosting.json`.
Die verwijst naar de oorspronkelijke Site. De placeholders in `vite.config.ts`
zijn bedoeld voor lokale ontwikkeling. Gebruik bij eigen hosting de eigen
resourceconfiguratie en laat de account- en dossierrechten controleren.

Het pakket bevat de volledige broncode. De live database, geüploade
klantbestanden, wachtwoorden, activeringstokens en andere servergeheimen maken
geen deel uit van een broncode-export. Voor het verhuizen van bestaande echte
dossiers is een afzonderlijke gecontroleerde data-overdracht nodig.

## 5. Waar pas je iets aan?

| Map of bestand | Inhoud |
| --- | --- |
| `app/` | Routes, basisopmaak en API-ingang |
| `components/portal/` | Portaal, formulieren, planning, dossiers, accounts en login |
| `app/globals.css` | Huisstijl, kleuren en algemene opmaak |
| `lib/` | Bedrijfsregels, contracten, logboeken, bestandsbeheer, exports en serverrechten |
| `db/` en `drizzle/` | Databaseschema en bestaande migraties |
| `public/brand/` | Logo’s en beeldmerken |
| `tests/` | Domein-, server- en rendercontroles |
| `build/` en `scripts/` | Hostingintegratie, lokaal starten en bouwen |
| `docs/PORTAAL-V10.md` | Centrale werkruimte, accounts, dossiers en autorisatie |
| `README.md` en overige `docs/` | Uitgebreide uitleg en geschiedenis van eerdere versies |

Versie 11 voegt de drie inlogkeuzes toe. Oudere versiedocumenten beschrijven de
situatie van die versie; gebruik voor de centrale opslag en accounts vooral
`docs/PORTAAL-V10.md` en de actuele broncode. Eerdere schermmodules zijn als
bronreferentie bewaard, zoals in de oorspronkelijke repository.

`BRON-VERSIE.txt` identificeert de bronversie. `SHA256SUMS.txt` bevat de
SHA-256-controlewaarde van ieder meegeleverd bestand behalve dat manifest zelf.
De bronbestanden zijn ongewijzigd overgenomen uit die Git-versie. Alleen de
gegenereerde TypeScript-buildcache is weggelaten. Deze handleiding, de
versieverklaring en het controlemanifest zijn toegevoegd voor deze export.
