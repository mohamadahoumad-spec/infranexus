CREATE TABLE `portal_server_audit` (
	`id` text PRIMARY KEY NOT NULL,
	`actor` text NOT NULL,
	`at` text NOT NULL,
	`action` text NOT NULL,
	`record_id` text NOT NULL,
	`revision` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `portal_files` (
	`id` text PRIMARY KEY NOT NULL,
	`object_key` text NOT NULL,
	`name` text NOT NULL,
	`mime` text NOT NULL,
	`size` integer NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `portal_invitations` (
	`id` text PRIMARY KEY NOT NULL,
	`account_id` text NOT NULL,
	`email` text NOT NULL,
	`token_hash` text NOT NULL,
	`expires_at` text NOT NULL,
	`created_by` text NOT NULL,
	`created_at` text NOT NULL,
	`revoked_at` text,
	`accepted_by` text,
	`accepted_at` text
);
--> statement-breakpoint
CREATE UNIQUE INDEX `portal_invitations_token_hash_unique` ON `portal_invitations` (`token_hash`);--> statement-breakpoint
CREATE TABLE `portal_members` (
	`identity_id` text PRIMARY KEY NOT NULL,
	`account_id` text NOT NULL,
	`email` text NOT NULL,
	`accepted_at` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `portal_members_account_id_unique` ON `portal_members` (`account_id`);--> statement-breakpoint
CREATE TABLE `portal_records` (
	`id` text PRIMARY KEY NOT NULL,
	`kind` text NOT NULL,
	`record_id` text NOT NULL,
	`payload` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `portal_workspaces` (
	`id` text PRIMARY KEY NOT NULL,
	`revision` integer DEFAULT 0 NOT NULL,
	`nonce` text NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE TRIGGER `portal_audit_no_update` BEFORE UPDATE ON `portal_server_audit` BEGIN SELECT RAISE(ABORT, 'Audit records are append-only'); END;
--> statement-breakpoint
CREATE TRIGGER `portal_audit_no_delete` BEFORE DELETE ON `portal_server_audit` BEGIN SELECT RAISE(ABORT, 'Audit records are append-only'); END;
