CREATE INDEX `portal_invitations_account` ON `portal_invitations` (`account_id`,`created_at`);--> statement-breakpoint
CREATE INDEX `portal_records_kind` ON `portal_records` (`kind`);