'use client';
import React, { useState } from 'react';
import { CalendarDays, CheckCircle2, ChevronRight, Download, FileText, MessageSquare, ShieldCheck } from 'lucide-react';
import { toast } from 'sonner';
import { Checkbox } from '@/components/ui/checkbox';
import { useInfra } from './infra-context';
import { Badge, Btn, DataTable, Empty, Field, Notice, Section } from './infra-ui';
import { canReview, formatDate, isInternal } from '@/lib/demo';
import { professionalReports, reviewCertificate } from '@/lib/professional';
export function ProjectReports({ projectId }: {
    projectId?: string;
}) {
    const { state, account, setModal } = useInfra();
    const reports = professionalReports(state, account).filter(r => !projectId || r.projectId === projectId);
    return <Section title="Projectmeldingen" note="Gedeeld tussen de professional en de backoffice"><div className="pro-report-list">{reports.map(r => <button key={r.id} onClick={() => setModal({ type: 'pro-report-detail', id: r.id })}><span className="pro-report-icon"><MessageSquare size={19}/></span><div><b>{r.title}</b><small>{state.projects.find(p => p.id === r.projectId)?.name} · {formatDate(r.date)}</small>{r.response && <span className="pro-report-response">Reactie beschikbaar</span>}</div><Badge>{r.status}</Badge><ChevronRight size={17}/></button>)}{!reports.length && <Empty title="Geen projectmeldingen" text="Een nieuwe melding verschijnt bij de professional én in het projectdossier."/>}</div></Section>;
}
export function AvailabilityOverview({ professionalId }: {
    professionalId: string;
}) {
    const { state } = useInfra();
    const records = state.availability.filter(a => a.professionalId === professionalId).sort((a, b) => a.date.localeCompare(b.date));
    return <Section title="Doorgegeven beschikbaarheid"><DataTable headers={['Datum', 'Beschikbaarheid']} rows={records.map(a => [formatDate(a.date), <Badge key={a.id}>{a.status}</Badge>])} empty="Er zijn nog geen afwijkende beschikbaarheidsafspraken vastgelegd."/></Section>;
}
export function CertificateInbox({ professionalId }: {
    professionalId: string;
}) {
    const { state } = useInfra();
    const items = state.certificateSubmissions.filter(c => c.professionalId === professionalId);
    if (!items.length)
        return null;
    return <Section title="Aangeleverde kwalificatiebewijzen" note="Aanleveren en inhoudelijk controleren zijn afzonderlijke stappen"><div className="pro-evidence-list">{items.map(c => <EvidenceItem key={c.id} id={c.id}/>)}</div></Section>;
}
function EvidenceItem({ id }: {
    id: string;
}) {
    const { state, account, change } = useInfra();
    const record = state.certificateSubmissions.find(c => c.id === id)!;
    const [reason, setReason] = useState(''), [checked, setChecked] = useState(false), [error, setError] = useState('');
    function review(approved: boolean) { try {
        if (approved && !checked)
            throw new Error('Bevestig eerst dat je het originele bewijs hebt gecontroleerd.');
        reviewCertificate(state, account, id, approved, reason);
        change(s => reviewCertificate(s, account, id, approved, reason), 'Kwalificatiebewijs beoordeeld', 'Professional', record.professionalId, record.status, approved ? 'Goedgekeurd' : 'Afgekeurd');
        toast.success(approved ? 'Verificatie vastgelegd; beschikbaar voor de kwalificatiecontrole.' : 'Beoordeling teruggestuurd aan de professional.');
    }
    catch (err) {
        setError((err as Error).message);
    } }
    return <details className="pro-evidence-item"><summary><span className="file-icon"><ShieldCheck size={20}/></span><div><b>{record.type}</b><small>{record.name} · {formatDate(record.submittedAt)}</small></div><Badge>{record.status}</Badge></summary><div className="pro-evidence-body"><p>Uitgever: <b>{record.issuer}</b><br />Vervaldatum: <b>{formatDate(record.expiry)}</b></p><a className="btn" href={record.url} download={record.name}><Download size={17}/>Bewijs downloaden</a>{record.status === 'Controle nodig' && canReview(account) ? <><Field label="Beoordeling / toelichting"><textarea rows={3} maxLength={2000} value={reason} onChange={e => setReason(e.target.value)}/></Field><label className="checkbox-field"><Checkbox checked={checked} onCheckedChange={v => setChecked(v === true)}/><span>Ik heb het bewijs en de ingevoerde gegevens gecontroleerd.</span></label>{error && <p className="form-error" role="alert">{error}</p>}<div className="pro-inline-actions"><Btn onClick={() => review(false)}>Aanvulling vragen</Btn><Btn primary disabled={!checked || !reason.trim()} onClick={() => review(true)}>Verificatie vastleggen</Btn></div><small>De vrijgavestatus van de professional wordt hierdoor niet gewijzigd.</small></> : record.reason ? <div className="pro-feedback"><b>Terugkoppeling backoffice</b><p>{record.reason}</p></div> : <Notice>De backoffice controleert dit bewijs. Tot die tijd blijft de huidige kwalificatieregistratie leidend.</Notice>}</div></details>;
}
