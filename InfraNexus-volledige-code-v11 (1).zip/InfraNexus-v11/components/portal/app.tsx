'use client';
import React, { useEffect, useRef, useState } from 'react';
import { LayoutDashboard, ClipboardList, FileSignature, CalendarDays, FolderKanban, Users, UserRoundPlus, ShieldCheck, NotebookPen, Files, MessageCircle, Wallet, Settings2, UserRound, Search, Menu, ArrowUpRight, ChevronRight, Check, Info, LifeBuoy, Building2, HardHat } from 'lucide-react';
import {portalRequest,uploadPortalAssets} from '@/lib/remote-portal';
import {portalDelta} from '@/lib/portal-delta';
import {applyOps,type OpsCommand} from '@/lib/project-ops';
import {OpsHome} from './ops-register';
import {AccountsWorkspace} from './accounts';
import {accountId,demoPortalAccounts} from '@/lib/account-setup';
import {ActionCenter} from './action-center';
import {requiredActions} from '@/lib/project-actions';
import {ContractsWorkspace,OrdersWorkspace,HoursWorkspace,NotificationWorkspace,WorkflowCards} from './workflow-pages';
import {visibleNotifications,actorKey,completeWorkflowNotifications} from '@/lib/workflows';
import { Toaster, toast } from 'sonner';
import { Sheet, SheetContent, SheetTitle, SheetDescription } from '../ui/sheet';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '../ui/dialog';
import { PortalContext, type PortalModal } from './context';
import { Action, Choice, Brand, Blank, Hint, FilePreview } from './ui';
import { portalSeed, hydratePortal, allowedPages, scopeDescription, type PortalState, type Page } from '@/lib/portal';
import { loadPortal, savePortal } from '@/lib/portal-storage';
import { accounts, uid, isCustomer, isProfessional, isInternal, visibleProjects, type Account, type DemoState } from '@/lib/demo';
import { visibleConversations } from '@/lib/operations';
import { PortalForms } from './forms';
import { HomeOverview, RequestWorkspace, AgreementWorkspace, ProjectWorkspace } from './overview';
import { PlanningWorkspace, LogbookWorkspace, DocumentWorkspace, AvailabilityWorkspace } from './work';
import { PeopleWorkspace, CandidateWorkspace, CertificateWorkspace } from './people';
import { MessageWorkspace } from './messages';
import { CustomerWorkspace, FinanceWorkspace, SettingsWorkspace, ProfileWorkspace } from './administration';
const navigation: {
    page: Page;
    title: string;
    Icon: React.ElementType;
    group: string;
}[] = [
    { page: 'home', title: 'Werkoverzicht', Icon: LayoutDashboard, group: 'WERKEN' },
    { page: 'requests', title: 'Aanvragen', Icon: ClipboardList, group: 'WERKEN' },
    { page: 'agreements', title: 'Contracten', Icon: FileSignature, group: 'WERKEN' },
    {page:'orders',title:'Opdrachtbevestigingen',Icon:FileSignature,group:'WERKEN'},
    {page:'hours',title:'Uren & afwijkingen',Icon:CalendarDays,group:'WERKEN'},
    {page:'notifications',title:'Meldingen',Icon:Info,group:'SAMENWERKEN'},
    { page: 'planning', title: 'Planning', Icon: CalendarDays, group: 'WERKEN' },
    { page: 'projects', title: 'Projecten', Icon: FolderKanban, group: 'WERKEN' },
    { page: 'logs', title: 'Logboeken', Icon: NotebookPen, group: 'WERKEN' },
    { page: 'chat', title: 'Berichtencentrum', Icon: MessageCircle, group: 'SAMENWERKEN' },
    { page: 'people', title: 'Professionals', Icon: Users, group: 'SAMENWERKEN' },
    { page: 'candidates', title: 'Kandidaten', Icon: UserRoundPlus, group: 'SAMENWERKEN' },
    { page: 'checks', title: 'Certificaten', Icon: ShieldCheck, group: 'SAMENWERKEN' },
    { page: 'documents', title: 'Documenten', Icon: Files, group: 'SAMENWERKEN' },
    { page: 'availability', title: 'Mijn beschikbaarheid', Icon: CalendarDays, group: 'SAMENWERKEN' },
    { page: 'finance', title: 'Financiën', Icon: Wallet, group: 'ORGANISATIE' },
    { page: 'profile', title: 'Mijn profiel & rol', Icon: UserRound, group: 'ORGANISATIE' },
    {page:'customers',title:'Klanten & relaties',Icon:Building2,group:'ORGANISATIE'},
    { page:'accounts',title:'Accounts beheren',Icon:Users,group:'ORGANISATIE'},
    { page: 'settings', title: 'Organisatie & toegang', Icon: Settings2, group: 'ORGANISATIE' }
];
export function PortalApp({remote}:{remote?:{state:PortalState;account:Account;revision:number}}={}) {
    const [state, setState] = useState<PortalState>(()=>remote?.state||portalSeed()), [loaded, setLoaded] = useState(!!remote), [account, setAccount] = useState<Account>(remote?.account||{...accounts[0],userId:'account-SUPER ADMIN'}), [page, setPage] = useState<Page>('home'), [record, setRecord] = useState<string | null>(null), [modal, setModal] = useState<PortalModal>(null), [mobile, setMobile] = useState(false), [search, setSearch] = useState(false), [searchText, setSearchText] = useState(''), [about, setAbout] = useState(false), [storageStatus, setStorageStatus] = useState('Laden…');
    const [previewFile,setPreview]=useState<import('@/lib/operations-types').FileAsset|null>(null);
    const previewRef=useRef(previewFile);previewRef.current=previewFile;
    const setPreviewFile=(file:import('@/lib/operations-types').FileAsset|null)=>{setPreview(file);if(typeof window==='undefined')return;if(file&&!previewRef.current)window.history.pushState({infranexusPreview:true},'',window.location.href);else if(!file&&window.history.state?.infranexusPreview)window.history.back();};
    const ref = useRef(state), writeQueue = useRef<Promise<void>>(Promise.resolve());
    useEffect(() => { if(remote){setStorageStatus('Centrale opslag');return;}let active = true; loadPortal().then(data => { if (active) {
        ref.current = data;
        setState(data);
        try { const key=localStorage.getItem('infranexus-active-role-v2'); const known=demoPortalAccounts(data).find(a=>accountId(a)===key||(a.professionalId||a.customerId||a.role)===key);if(known)setAccount(known); }catch{}
        setLoaded(true);
    } }).catch(() => { if (active) {
        setLoaded(true);
        setStorageStatus('Alleen deze sessie');
        toast.error('De opgeslagen werkruimte kon niet worden geladen. Voorbeeldgegevens zijn geopend.');
    } }); return () => { active = false; }; }, []);
    useEffect(() => { if (remote||!loaded)
        return; setStorageStatus('Opslaan…'); writeQueue.current = writeQueue.current.catch(() => { }).then(() => savePortal(state)).then(() => setStorageStatus('Opgeslagen')).catch(error => { setStorageStatus('Opslaan geblokkeerd'); toast.error(error instanceof Error?error.message:'Opslaan is niet gelukt. Houd deze sessie open om je wijzigingen te behouden.'); }); }, [state, loaded]);
    const go = (next: Page, id?: string) => { setPage(next); setRecord(id || null); setMobile(false); if (typeof window !== 'undefined') {
        window.history.pushState(null, '', `#${next}${id ? '?id=' + encodeURIComponent(id) : ''}`);
        window.scrollTo({ top: 0, behavior: 'instant' });
    } };
    useEffect(() => { const restore = () => { setPreview(null);const [raw,params]=window.location.hash.slice(1).split('?');const aliases:Record<string,Page>={dashboard:'home',aanvragen:'requests',projecten:'projects',professionals:'people',kandidaten:'candidates',logboeken:'logs',documenten:'documents',kwalificaties:'checks',financieel:'finance',profiel:'profile',beheer:'settings',branding:'settings',beschikbaarheid:'availability',meldingen:'notifications',klanten:'customers'};const p=aliases[raw]||raw;if (navigation.some(n => n.page === p)) {
        setPage(p as Page);
        const id=new URLSearchParams(params).get('id');setRecord(p==='logs'&&id&&!id.includes(':')?'digital:'+id:id);
    } }; restore(); window.addEventListener('popstate', restore); const keys = (e: KeyboardEvent) => { if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        setSearch(true);
    } }; window.addEventListener('keydown', keys); return () => { window.removeEventListener('popstate', restore); window.removeEventListener('keydown', keys); }; }, []);
    const revision=useRef(remote?.revision||0),remoteBusy=useRef(false);
    const acceptSession=(data:any)=>{revision.current=data.revision;ref.current=data.state;setState(data.state);if(data.account)setAccount(data.account);setStorageStatus('Centraal opgeslagen');};
    const refresh=async()=>{if(!remote)return;try{acceptSession(await portalRequest('session'));}catch(e){setStorageStatus('Toegang opnieuw controleren');if([401,403].includes((e as any).status)){window.location.replace('/werkruimte');return;}toast.error(e instanceof Error?e.message:'Verversen mislukt.');}};
    const remoteChange=async(payload:any,label:string)=>{if(remoteBusy.current){toast.error('Wacht tot de vorige wijziging is opgeslagen.');return false;}remoteBusy.current=true;setStorageStatus('Centraal opslaan…');try{const data=await portalRequest('command',{revision:revision.current,...await uploadPortalAssets(payload)});acceptSession(data);toast.success(label);return true;}catch(e){setStorageStatus('Niet opgeslagen');toast.error(e instanceof Error?e.message:'Opslaan mislukt.');if([401,403,409].includes((e as any).status))await refresh();return false;}finally{remoteBusy.current=false;}};
    const runAsync=async(update:(s:PortalState)=>DemoState,label:string)=>{if(!remote)return run(update,label);try{const before=ref.current,after={...before,...update(before)};return await remoteChange({changes:portalDelta(before,after),label},label);}catch(e){toast.error(e instanceof Error?e.message:'Wijziging mislukt.');return false;}};
    const act=async(command:OpsCommand,label:string)=>remote?remoteChange({command},label):run(s=>applyOps(s,account,command),label);
    useEffect(()=>{if(!remote)return;const update=()=>{if(!remoteBusy.current)void refresh();};window.addEventListener('focus',update);const timer=setInterval(update,30000);return()=>{window.removeEventListener('focus',update);clearInterval(timer);};},[!!remote]);
    const run = (update: (s: PortalState) => DemoState, label: string) => { if(remote){void runAsync(update,label);return false;}try {
        const previous = ref.current;
        if(account.userId&&previous.portalAccounts.some(a=>a.id===account.userId&&a.status==='Geblokkeerd'))throw Error('Dit account is geblokkeerd.');
        const result = update(previous);
        const next: PortalState = { ...completeWorkflowNotifications(previous,{...previous,...result}), schema: 2, audit: ['Gesprek gelezen','Melding gelezen'].includes(label) ? result.audit : [{ id: uid(), at: new Date().toISOString(), actor: account.name, action: label, entity: page, entityId: record || modal?.id || modal?.projectId || '', before: '—', after: label }, ...result.audit] };
        ref.current = next;
        setState(next);
        if (!['Gesprek gelezen','Melding gelezen'].includes(label))
            toast.success(label);
        return true;
    }
    catch (e) {
        toast.error(e instanceof Error ? e.message : 'De wijziging kon niet worden opgeslagen.');
        return false;
    } };
    const allowed = allowedPages(account), internal = isInternal(account), professional = isProfessional(account), customer = isCustomer(account);
    const demoAccounts: Account[] = demoPortalAccounts(state);
    const switchAccount = (key: string) => { const next = demoAccounts.find(a => accountId(a) === key); if (next) {
        setAccount(next);
        setModal(null);setPreview(null);
        go('home');
    } };
    const accountKey = accountId(account);
    useEffect(()=>{if(loaded&&!remote)try{localStorage.setItem('infranexus-active-role-v2',accountKey);}catch{}},[accountKey,loaded]);
    const nav = navigation.filter(n => allowed.includes(n.page));
    const active = navigation.find(n => n.page === page);
    const actions=requiredActions(state,account);
    const requestsCount = state.requests.filter(r => r.status === 'Nieuw' && !r.projectId && (!customer || r.customerId === account.customerId)).length;
    const requestActions=actions.filter(a=>a.requestId).length,projectActions=new Set(actions.filter(a=>a.projectId).map(a=>a.projectId)).size,orderActions=actions.filter(a=>a.kind==='order'||a.kind==='mail').length;
    const unreadNotifications=visibleNotifications(state,account).filter(n=>!state.notificationReads.some(r=>r.id===n.id&&r.actor===actorKey(account))).length;
    const noticeCount=Math.max(unreadNotifications,actions.length);
    const unseen = visibleConversations(state, account).filter(c => { const latest = state.chatMessages.filter(m => m.conversationId === c.id).at(-1); const read = state.chatRead.find(r => r.actor === account.name && r.conversationId === c.id); return latest && latest.author !== account.name && (!read || read.at < latest.at); }).length;
    const sidebar = <><div className="sidebar-brand"><button onClick={() => go('home')} aria-label="InfraNexus werkoverzicht"><Brand /></button></div><div className="workspace-switch"><span className="workspace-symbol">{professional ? <HardHat size={19}/> : customer ? <Building2 size={19}/> : <ShieldCheck size={19}/>}</span><div><b>{customer ? account.name : 'InfraNexus'}</b><small>{professional ? 'Professionalomgeving' : customer ? 'Klantomgeving' : 'Teamomgeving'}</small></div><span className="workspace-dot"/></div><nav aria-label="Hoofdnavigatie" className="portal-navigation">{['WERKEN', 'SAMENWERKEN', 'ORGANISATIE'].map(group => { const list = nav.filter(n => n.group === group); return list.length ? <div className="nav-group" key={group}><span>{group}</span>{list.map(n => <button key={n.page} aria-current={page === n.page ? 'page' : undefined} className={page === n.page ? 'active' : ''} onClick={() => go(n.page)}><n.Icon size={18}/><span>{n.page === 'home' && !internal ? 'Mijn overzicht' : n.page === 'people' ? 'Professionals' : n.title}</span>{n.page === 'notifications'&&noticeCount>0&&<em>{noticeCount}</em>}{n.page === 'requests' && Math.max(requestsCount,requestActions) > 0 && <em>{Math.max(requestsCount,requestActions)}</em>}{n.page==='projects'&&projectActions>0&&<em className="pending-count">{projectActions}</em>}{n.page==='orders'&&orderActions>0&&<em className="pending-count">{orderActions}</em>}{n.page === 'chat' && unseen > 0 && <em className="chat-count">{unseen}</em>}</button>)}</div> : null; })}</nav><div className="sidebar-bottom"><button className="sidebar-help" onClick={() => go('chat')}><LifeBuoy size={18}/><span>Even afstemmen?<small>Open het berichtencentrum</small></span><ArrowUpRight size={15}/></button><div className="sidebar-identity"><Brand small/><span><b>Veiligheid & milieu</b><small>Samen verder, veilig vooruit.</small></span></div></div></>;
    let content: React.ReactNode;
    if (!allowed.includes(page))
        content = <Blank title="Deze pagina hoort niet bij jouw rol" text={scopeDescription(account)} action={<Action primary onClick={() => go('home')}>Naar mijn overzicht</Action>}/>;
    else
        switch (page) {
            case 'accounts':content=<AccountsWorkspace/>;break;
            case 'home':
                content = <><OpsHome/><ActionCenter/><WorkflowCards/><HomeOverview /></>;
                break;
            case 'requests':
                content = <RequestWorkspace />;
                break;
            case 'agreements':
                content = <ContractsWorkspace />;
                break;
            case 'orders':content=<OrdersWorkspace/>;break;case 'hours':content=<HoursWorkspace/>;break;case 'notifications':content=<NotificationWorkspace/>;break;case 'planning':
                content = <PlanningWorkspace />;
                break;
            case 'projects':
                content = <ProjectWorkspace />;
                break;
            case 'logs':
                content = <LogbookWorkspace />;
                break;
            case 'chat':
                content = <MessageWorkspace />;
                break;
            case 'people':
                content = <PeopleWorkspace />;
                break;
            case 'candidates':
                content = <CandidateWorkspace />;
                break;
            case 'checks':
                content = <CertificateWorkspace />;
                break;
            case 'documents':
                content = <DocumentWorkspace />;
                break;
            case 'availability':
                content = <AvailabilityWorkspace />;
                break;
            case 'customers':content=<CustomerWorkspace/>;break;case 'finance':
                content = <FinanceWorkspace />;
                break;
            case 'profile':
                content = <ProfileWorkspace />;
                break;
            case 'settings':
                content = <SettingsWorkspace />;
                break;
        }
    const searchResults = [...visibleProjects(state, account).map(p => ({ label: p.name, description: `Project · ${p.city}`, page: 'projects' as Page, id: p.id })), ...(allowed.includes('people') ? state.professionals.map(p => ({ label: p.name, description: `Professional · ${p.role}`, page: 'people' as Page, id: p.id })) : []), ...(allowed.includes('candidates') ? state.candidates.map(k => ({ label: k.name, description: `Kandidaat · ${k.status}`, page: 'candidates' as Page, id: k.id })) : []), ...nav.map(n => ({ label: n.title, description: 'Pagina openen', page: n.page, id: undefined }))].filter(r => `${r.label} ${r.description}`.toLowerCase().includes(searchText.toLowerCase())).slice(0, 15);
    return <PortalContext.Provider value={{ state, account, page, record, go, modal, setModal, run,runAsync,act,request:remote?portalRequest:undefined,refresh,previewFile,setPreviewFile }}><div className="portal-app"><aside className="portal-sidebar">{sidebar}</aside><Sheet open={mobile} onOpenChange={setMobile}><SheetContent side="left" className="mobile-sidebar"><SheetTitle className="sr-only">Navigatie</SheetTitle><SheetDescription className="sr-only">Open een onderdeel van jouw werkomgeving.</SheetDescription>{sidebar}</SheetContent></Sheet><div className="portal-body"><header className="portal-header"><div className="header-path"><button className="circle-action mobile-menu" aria-label="Menu openen" onClick={() => setMobile(true)}><Menu size={21}/></button><span>{internal ? 'Teamomgeving' : professional ? 'Mijn werkomgeving' : 'Klantomgeving'}</span><ChevronRight size={14}/><b>{active?.title}</b></div><div className="header-tools"><button className="header-search" onClick={() => setSearch(true)}><Search size={16}/><span>Zoeken</span><kbd>⌘ K</kbd></button><button className="header-messages" aria-label="Meldingen openen" onClick={()=>go('notifications')}><Info size={20}/>{noticeCount>0&&<i className="orange-indicator"/>}</button><button className="header-messages" aria-label="Berichtencentrum openen" onClick={() => go('chat')}><MessageCircle size={20}/>{unseen > 0 && <i />}</button><span className="header-divider"/><span className="account-avatar">{account.initials}</span></div></header><div className="environment-bar">{remote?<span><i/>Beveiligde werkruimte · {account.email}</span>:<span><i />Conceptomgeving <span>·</span> voorbeelddata <span>·</span> 6 oktober 2026</span>}{remote?<a href="/signout-with-chatgpt?return_to=%2Fwerkruimte" target="_top">Afmelden</a>:<div><a className="text-action" href="/werkruimte">Beveiligde werkruimte</a><span>Bekijk als</span><Choice value={accountKey} onChange={switchAccount} label="Voorbeeldrol kiezen" options={demoAccounts.map(a => ({ value: accountId(a), label: `${a.name} · ${a.role}` }))}/><button className="circle-action" onClick={() => setAbout(true)} aria-label="Over deze omgeving"><Info size={16}/></button></div>}</div>{customer && state.customers.find(c => c.id === account.customerId)?.logoUrl && <div className="co-brand"><Brand customerId={account.customerId}/></div>}<main className="portal-main" key={`${accountKey}-${page}-${record || ''}`}>{content}</main><footer className="portal-footer"><span>© 2026 InfraNexus Veiligheid & Milieu</span><span><i className={storageStatus === 'Opgeslagen' ? 'saved' : ''}/>{storageStatus} · {remote?'centrale werkruimte':'op dit apparaat'}</span></footer></div></div><nav className="mobile-bottom" aria-label="Snelle navigatie"><button aria-current={page === 'home' ? 'page' : undefined} onClick={() => go('home')}><LayoutDashboard /><span>Overzicht</span></button><button aria-current={page === 'planning' ? 'page' : undefined} onClick={() => go(allowed.includes('planning') ? 'planning' : allowed.includes('projects') ? 'projects' : 'requests')}><CalendarDays /><span>{allowed.includes('planning') ? 'Planning' : 'Projecten'}</span></button><button aria-current={page === 'chat' ? 'page' : undefined} onClick={() => go('chat')}><MessageCircle /><span>Berichten</span></button><button onClick={() => setMobile(true)}><Menu /><span>Meer</span></button></nav><PortalForms /><Dialog open={!!previewFile} onOpenChange={open=>{if(!open)setPreviewFile(null);}}><DialogContent className="portal-modal file-preview-modal"><DialogHeader><DialogTitle>{previewFile?.name||'Document bekijken'}</DialogTitle><DialogDescription>{modal?'Je formulier blijft geopend en je invoer blijft bewaard.':'Document uit je dossier.'}</DialogDescription></DialogHeader><Action onClick={()=>setPreviewFile(null)}>← {modal?'Terug naar het formulier':'Terug naar het dossier'}</Action>{previewFile&&<FilePreview file={previewFile}/>}</DialogContent></Dialog><Dialog open={about} onOpenChange={setAbout}><DialogContent className="portal-modal"><DialogHeader><DialogTitle>InfraNexus, opnieuw opgebouwd</DialogTitle><DialogDescription>Een samenhangende conceptomgeving voor de operationele werkwijze.</DialogDescription></DialogHeader><p>Aanvragen, raamovereenkomsten, planning, logboeken, certificaten, berichten en facturen volgen dezelfde dossiers.</p><Hint>{scopeDescription(account)}</Hint><p>Deze versie bewaart wijzigingen en testbestanden op dit apparaat. De voorbeeldrol is bedoeld om de omgevingen te beoordelen. Echte login, serverrechten, centrale opslag en betalingen zijn nog niet aangesloten.</p></DialogContent></Dialog><Dialog open={search} onOpenChange={setSearch}><DialogContent className="portal-modal search-modal"><DialogHeader><DialogTitle>Zoeken in jouw omgeving</DialogTitle><DialogDescription>Open een project, dossier of pagina.</DialogDescription></DialogHeader><div className="p-search"><Search size={18}/><input autoFocus aria-label="Zoekterm" placeholder="Project, professional of pagina…" value={searchText} onChange={e => setSearchText(e.target.value)}/></div><div className="search-results">{searchResults.map((r, i) => <button key={i} onClick={() => { setSearch(false); go(r.page, r.id); }}><span><b>{r.label}</b><small>{r.description}</small></span><ArrowUpRight size={16}/></button>)}{!searchResults.length && <Blank title="Geen resultaten"/>}</div></DialogContent></Dialog><Toaster position="bottom-right" richColors/></PortalContext.Provider>;
}
