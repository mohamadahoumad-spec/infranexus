'use client';
import {useState} from 'react';
import {usePortal} from './context';
import {applyOps,type OpsCommand} from '@/lib/project-ops';
export function useOps(){const p=usePortal();return {...p,perform:async(command:OpsCommand,label:string)=>p.act?p.act(command,label):p.run(s=>applyOps(s,p.account,command),label)};}
export function useOpsSubmit(){const p=useOps(),[busy,setBusy]=useState(false),[error,setError]=useState('');return {...p,busy,error,submit:async(build:()=>OpsCommand|Promise<OpsCommand>,label:string,close=true)=>{setBusy(true);setError('');try{const ok=await p.perform(await build(),label);if(ok&&close)p.setModal(null);if(!ok)setError('De wijziging is niet opgeslagen. Controleer de melding en probeer opnieuw. Je invoer blijft staan.');return ok;}catch(e){setError(e instanceof Error?e.message:'Opslaan is niet gelukt.');return false;}finally{setBusy(false);}}};}
