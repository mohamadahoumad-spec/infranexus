'use client';
import {workspaceDate,addDays} from '@/lib/workspace-date';
import React, { useState } from 'react';
import { usePortal } from './context';
import { Panel, Chip, Hint, Field } from './ui';
import { TODAY } from '@/lib/demo';
export function MonthAvailabilityView({ professionalId }: {
    professionalId: string;
}) { const { state } = usePortal(); const [month, setMonth] = useState(workspaceDate(state).slice(0, 7)); const record = state.monthlyAvailability.find(m => m.professionalId === professionalId && m.month === month); return <Panel title="Beschikbaarheid per maand" action={<input className="month-input" type="month" aria-label="Maand kiezen" value={month} onChange={e => setMonth(e.target.value)}/>}><div className="panel-pad">{record ? <><Chip>Ingediend</Chip><p className="muted spaced">{record.submittedBy} · {new Date(record.submittedAt).toLocaleDateString('nl-NL')}</p><div className="availability-calendar readonly">{Object.entries(record.days).map(([date, status]) => <div className={status === 'Beschikbaar' ? 'available' : ''} key={date}><small>{new Date(date).toLocaleDateString('nl-NL', { weekday: 'short' })}</small><b>{+date.slice(8)}</b><span>{status === 'Beschikbaar' ? '✓' : '–'}</span></div>)}</div><p className="muted">Groen = beschikbaar · grijs = niet beschikbaar</p></> : <Hint tone="amber">Deze maand is nog niet ingediend. Planning kan de inzet wel afstemmen en inplannen; de waarschuwing blijft zichtbaar.</Hint>}</div></Panel>; }
