'use client';
import React from 'react';
import {usePortal} from './context';
import {isInternal} from '@/lib/demo';
import {FileLink} from './ui';
import type {ManualMailEvidence} from '@/lib/workflow-types';
export function MailEvidence({evidence}:{evidence?:ManualMailEvidence}){
 const {account}=usePortal();if(!evidence||(!isInternal(account)&&!evidence.visibleToRecipient)||(!evidence.body&&!evidence.attachments?.length))return null;
 return <details className="mail-evidence"><summary>Verzonden mail en bijlagen bekijken</summary>{evidence.body&&<pre>{evidence.body}</pre>}{evidence.attachments?.map((file,i)=><div key={i} className="attachment-row"><b>{file.name}</b><FileLink file={file}/></div>)}</details>;
}
