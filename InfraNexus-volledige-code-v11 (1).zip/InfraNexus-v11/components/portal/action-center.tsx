'use client';
import React from 'react';
import {ArrowUpRight, BellRing} from 'lucide-react';
import {usePortal} from './context';
import {markNotification} from '@/lib/workflows';
import {requiredActions} from '@/lib/project-actions';
export function ActionCenter({projectId,requestId}:{projectId?:string;requestId?:string}){
 const {state,account,go,run}=usePortal();const actions=requiredActions(state,account).filter(a=>(!projectId||a.projectId===projectId)&&(!requestId||a.requestId===requestId));
 if(!actions.length)return null;
 return <section className="action-center" aria-label="Actie nodig"><div className="action-center-heading"><BellRing size={19}/><b>{actions.length===1?'Actie nodig':`${actions.length} openstaande acties`}</b><span>Blijft zichtbaar tot je de actie afrondt</span></div>{actions.map(a=><div className="required-action" key={a.key}><span className="action-dot" aria-hidden="true"/><div className="grow"><h3>{a.title}</h3><p>{a.body}</p></div><button className="action primary" onClick={()=>{if(a.kind==='notice')run(s=>markNotification(s,account,a.key.slice(7)),'Melding gelezen');go(a.page,a.id);}}>{a.button}<ArrowUpRight size={17}/></button></div>)}</section>;
}
export function ActionBadge({projectId,requestId}:{projectId?:string;requestId?:string}){const {state,account}=usePortal();const actions=requiredActions(state,account).filter(a=>(!projectId||a.projectId===projectId)&&(!requestId||a.requestId===requestId));if(!actions.length)return null;return <span className="needs-action-badge"><i/>{actions.some(a=>a.kind==='order')?'Akkoord nodig':actions.some(a=>a.kind==='question')?'Reactie nodig':`${actions.length} actie${actions.length===1?'':'s'} nodig`}</span>;}
