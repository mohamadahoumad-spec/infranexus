'use client';
import React,{useEffect,useState} from 'react';
import {PortalApp} from './app';
import {portalRequest} from '@/lib/remote-portal';
import {LoginLanding} from './login-landing';
import {parseLoginPortal,portalForRole,type LoginPortal} from '@/lib/login-portals';
export function SecureEntry(){const [session,setSession]=useState<any>(null),[error,setError]=useState(''),[needsLogin,setLogin]=useState(false),[loading,setLoading]=useState(true),[selected,setSelected]=useState<LoginPortal|null>(null);
 useEffect(()=>{let alive=true;async function load(){setSelected(parseLoginPortal(new URLSearchParams(window.location.search).get('omgeving')));const params=new URLSearchParams(window.location.hash.slice(1));if(params.get('setup'))sessionStorage.setItem('infranexus-setup',params.get('setup')!);if(params.get('invite'))sessionStorage.setItem('infranexus-invite',params.get('invite')!);if(params.has('setup')||params.has('invite'))history.replaceState(null,'',window.location.pathname+window.location.search);try{let s;try{s=await portalRequest('session');}catch(e){if((e as any).status===403&&sessionStorage.getItem('infranexus-invite')){await portalRequest('accept-invite',{token:sessionStorage.getItem('infranexus-invite')});sessionStorage.removeItem('infranexus-invite');s=await portalRequest('session');}else throw e;}if(s.setupRequired&&sessionStorage.getItem('infranexus-setup')){s=await portalRequest('setup',{token:sessionStorage.getItem('infranexus-setup')});sessionStorage.removeItem('infranexus-setup');}if(alive)setSession(s);}catch(e){if(alive){setError(e instanceof Error?e.message:'Openen is niet gelukt.');setLogin((e as any).status===401);}}finally{if(alive)setLoading(false);}}void load();return()=>{alive=false;};},[]);
 if(session?.state&&(!selected||selected===portalForRole(session.account.role)))return <PortalApp remote={session}/>;
 const choose=(portal:LoginPortal)=>{setSelected(portal);const url=new URL(window.location.href);url.searchParams.set('omgeving',portal);history.replaceState(history.state,'',url.pathname+url.search+url.hash);};
 return <LoginLanding selected={selected} onSelect={choose} loading={loading} needsLogin={needsLogin} setupRequired={session?.setupRequired} error={error} accountRole={session?.account?.role}/>;
}
