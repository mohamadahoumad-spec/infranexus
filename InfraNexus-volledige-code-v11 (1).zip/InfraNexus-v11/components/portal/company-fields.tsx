'use client';
import React from 'react';
import {Field,textValue} from './ui';
import type {ContractParty} from '@/lib/workflow-types';
export function CompanyFields({prefix,value,requiredName=true}:{prefix:string;value:ContractParty;requiredName?:boolean}){
 return <div className="fields">{[['name','Naam onderneming'],['kvk','KvK-nummer'],['vatNumber','Btw-nummer'],['address','Straat, huisnummer, postcode en plaats'],['contact','Contactpersoon'],['email','E-mailadres onderneming'],['phone','Telefoonnummer']].map(([key,label])=><Field key={key} label={label+(key==='name'&&requiredName?' *':'')} wide={key==='name'||key==='address'}><input name={`${prefix}-${key}`} type={key==='email'?'email':'text'} required={key==='name'&&requiredName} pattern={key==='kvk'?'[0-9]{8}':undefined} defaultValue={value[key as keyof ContractParty]||''}/></Field>)}</div>;
}
export const readCompanyFields=(f:FormData,prefix:string):ContractParty=>Object.fromEntries(['name','kvk','vatNumber','address','contact','email','phone'].map(k=>[k,textValue(f,`${prefix}-${k}`)])) as ContractParty;
