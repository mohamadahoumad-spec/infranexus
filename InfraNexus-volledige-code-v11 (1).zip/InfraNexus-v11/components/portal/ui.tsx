'use client';
import React from 'react';
import { Search, ArrowUpRight, Download, Eye, Inbox, Check, ShieldCheck, ChevronRight } from 'lucide-react';
import { Button } from '../ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Tabs, TabsList, TabsTrigger } from '../ui/tabs';
import { Checkbox } from '../ui/checkbox';
import { usePortal } from './context';
import type { FileAsset } from '@/lib/operations-types';
export function Action({ children, primary = false, quiet = false, ...props }: React.ComponentProps<typeof Button> & {
    primary?: boolean;
    quiet?: boolean;
}) { return <Button {...props} type={props.type || 'button'} className={`action ${primary ? 'is-primary' : ''} ${quiet ? 'is-quiet' : ''} ${props.className || ''}`}>{children}</Button>; }
export function Chip({ children, tone }: {
    children: React.ReactNode;
    tone?: string;
}) { const text = String(children), t = tone || (/Goedgekeurd|Actief|Geldig|Vrijgegeven|Akkoord|Ingepland|Betaald|Geaccepteerd/.test(text) ? 'green' : /Afgekeurd|Afgewezen|Verlopen|Geblokkeerd/.test(text) ? 'red' : /wacht|Wacht|controle|Controle|ondertekening|Nieuw|Correctie|Aanvulling|Voorlopig|Concept|Binnenkort/.test(text) ? 'amber' : 'neutral'); return <span className={`chip ${t}`}>{children}</span>; }
export function Heading({ eyebrow, title, description, children }: {
    eyebrow?: string;
    title: string;
    description?: string;
    children?: React.ReactNode;
}) { return <div className="p-heading"><div>{eyebrow && <span className="eyebrow">{eyebrow}</span>}<h1>{title}</h1>{description && <p>{description}</p>}</div><div className="p-heading-actions">{children}</div></div>; }
export function Panel({ title, note, action, children, className = '' }: {
    title?: string;
    note?: string;
    action?: React.ReactNode;
    children: React.ReactNode;
    className?: string;
}) { return <section className={`p-panel ${className}`}>{title && <div className="p-panel-head"><div><h2>{title}</h2>{note && <p>{note}</p>}</div>{action}</div>}{children}</section>; }
export function Blank({ title = 'Nog niets toegevoegd', text, action }: {
    title?: string;
    text?: string;
    action?: React.ReactNode;
}) { return <div className="blank"><Inbox size={28}/><h3>{title}</h3>{text && <p>{text}</p>}{action}</div>; }
export function Hint({ children, tone = 'neutral' }: {
    children: React.ReactNode;
    tone?: string;
}) { return <div className={`p-hint ${tone}`}>{children}</div>; }
export function Field({ label, children, wide = false, help }: {
    label: string;
    children: React.ReactNode;
    wide?: boolean;
    help?: string;
}) { return <label className={`p-field ${wide ? 'wide' : ''}`}><span>{label}</span>{children}{help && <small>{help}</small>}</label>; }
export function Choice({ value, onChange, options, label, disabled = false }: {
    value: string;
    onChange: (v: string) => void;
    options: (string | {
        value: string;
        label: string;
    })[];
    label: string;
    disabled?: boolean;
}) { const empty='__infranexus_empty__',chosen=options.find(o=>(typeof o==='string'?o:o.value)===value),display=typeof chosen==='string'?chosen:chosen?.label;return <Select disabled={disabled} value={value===''&&chosen?empty:value} onValueChange={v=>onChange(v===empty?'':v)}><SelectTrigger className="p-select" aria-label={label}><SelectValue placeholder={label}>{display}</SelectValue></SelectTrigger><SelectContent>{options.map(o=>{const v=typeof o==='string'?o:o.value;return <SelectItem value={v||empty} key={v}>{typeof o==='string'?o:o.label}</SelectItem>;})}</SelectContent></Select>; }

export function Segments({ items, value, onChange }: {
    items: string[];
    value: string;
    onChange: (v: string) => void;
}) { return <Tabs value={value} onValueChange={onChange}><TabsList className="p-segments">{items.map(item => <TabsTrigger key={item} value={item}>{item}</TabsTrigger>)}</TabsList></Tabs>; }
export function Checkline({ checked, onChange, children, disabled = false }: {
    checked: boolean;
    onChange: (v: boolean) => void;
    children: React.ReactNode;
    disabled?: boolean;
}) { return <label className="checkline"><Checkbox disabled={disabled} checked={checked} onCheckedChange={v => onChange(v === true)}/><span>{children}</span></label>; }
export function Filter({ value, onChange, placeholder = 'Zoeken…' }: {
    value: string;
    onChange: (v: string) => void;
    placeholder?: string;
}) { return <div className="p-search"><Search size={17}/><input aria-label={placeholder} placeholder={placeholder} value={value} onChange={e => onChange(e.target.value)}/></div>; }
export function Facts({ items }: {
    items: [
        string,
        React.ReactNode
    ][];
}) { return <dl className="facts">{items.map(([label, value]) => <div key={label}><dt>{label}</dt><dd>{value || '—'}</dd></div>)}</dl>; }
export function Table({ headers, rows, empty = 'Geen resultaten in deze selectie.' }: {
    headers: string[];
    rows: React.ReactNode[][];
    empty?: string;
}) { return <div className="p-table-wrap"><table className="p-table"><thead><tr>{headers.map((h, i) => <th key={i}>{h}</th>)}</tr></thead><tbody>{rows.map((row, i) => <tr key={i}>{row.map((cell, j) => <td key={j}>{cell}</td>)}</tr>)}</tbody></table>{!rows.length && <Blank title="Geen resultaten" text={empty}/>}</div>; }
export function Person({ name, subtitle }: {
    name: string;
    subtitle?: string;
}) { return <span className="p-person"><span className="p-avatar">{name.split(' ').map(p => p[0]).filter(Boolean).slice(0, 2).join('')}</span><span><b>{name}</b>{subtitle && <small>{subtitle}</small>}</span></span>; }
export function FileLink({ file, label, preview = true }: {
    file: FileAsset;
    label?: string;
    preview?: boolean;
}) { const { setModal,setPreviewFile } = usePortal(); return <span className="file-actions">{preview && <Action quiet onClick={() => setPreviewFile?setPreviewFile(file):setModal({ kind: 'file', file })}><Eye size={16}/>Bekijken</Action>}<a className="action download" href={file.url} download={file.name}><Download size={16}/>{label || 'Download'}</a></span>; }
export function Flow({ labels, current }: {
    labels: string[];
    current: number;
}) { return <ol className="flow-steps">{labels.map((label, i) => <li className={i < current ? 'done' : i === current ? 'current' : ''} key={label}><span>{i < current ? <Check size={13}/> : i + 1}</span><b>{label}</b>{i < labels.length - 1 && <ChevronRight size={15}/>}</li>)}</ol>; }
export function Brand({ small = false, customerId }: {
    small?: boolean;
    customerId?: string;
}) { const { state } = usePortal(); const logo = state.branding.find(b => b.id === 'infranexus')?.logo || '/brand/primary-logo-v2.png'; const c = state.customers.find(c => c.id === customerId); return <div className={`p-brand ${small ? 'mini' : ''}`}><img className="infra-logo" src={small ? '/brand/mark-v2.png' : logo} alt={small ? 'InfraNexus beeldmerk' : 'InfraNexus Veiligheid & Milieu'}/>{c?.logoUrl && <><span /><img className="client-logo" src={c.logoUrl} alt={c.name}/></>}</div>; }
export const textValue = (form: FormData, key: string) => String(form.get(key) || '').trim();
export async function readAsset(file: File): Promise<FileAsset> { if (file.size > 10 * 1024 * 1024)
    throw new Error('Kies een bestand tot 10 MB.'); const allowed = ['application/pdf', 'image/jpeg', 'image/png', 'image/webp', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','text/plain','text/csv']; if (!allowed.includes(file.type))
    throw new Error('Kies PDF, JPG, PNG, WebP, Word, Excel, CSV of tekst.'); const url = await new Promise<string>((resolve, reject) => { const r = new FileReader(); r.onload = () => resolve(String(r.result)); r.onerror = () => reject(new Error('Bestand kon niet worden gelezen.')); r.readAsDataURL(file); }); return { name: file.name, mime: file.type, size: file.size, url }; }
export function UploadField({ label = 'Bestand toevoegen', onChange, accept = 'application/pdf,image/jpeg,image/png,image/webp', required = true }: {
    label?: string;
    onChange: (file: File | null) => void;
    accept?: string;
    required?: boolean;
}) { return <Field label={label} wide help="Maximaal 10 MB per bestand."><input type="file" accept={accept} required={required} onChange={e => onChange(e.target.files?.[0] || null)}/></Field>; }

export function FilePreview({file}:{file:FileAsset}){
 return <div className="file-viewer">{file.mime.startsWith('image/')?<img src={file.url} alt={file.name}/>:file.mime==='application/pdf'?<object data={file.url} type="application/pdf" aria-label={file.name}><p>Download het bestand als de browser geen PDF-weergave ondersteunt.</p></object>:<Hint>Download dit bestand om het in de bijbehorende toepassing te openen.</Hint>}<a className="action download" href={file.url} download={file.name}><Download size={16}/>Download bestand</a></div>;
}
