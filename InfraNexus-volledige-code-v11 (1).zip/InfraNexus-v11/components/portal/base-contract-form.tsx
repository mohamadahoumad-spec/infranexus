'use client';
import React,{useState} from 'react';
import {usePortal} from './context';
import {Action,Choice,Field,Hint,Checkline,UploadField,readAsset,textValue,Facts} from './ui';
import {Footer,useSubmission} from './forms';
import {CompanyFields,readCompanyFields} from './company-fields';
import {issuerDetails,saveCompanyDetails,partyDetails,registerSignedBase} from '@/lib/contracts';
import {workflowDate} from '@/lib/workflows';
export function BaseContractForm(){
 const {state,account,modal,setModal}=usePortal(),submit=useSubmission(),party=modal?.kind==='cooperation'?'professional':'customer';
 const old=party==='customer'?state.agreements.find(g=>g.id===modal?.id):state.cooperations.find(c=>c.id===modal?.id),v=old?.versions.at(-1),oldId=old?('customerId'in old?old.customerId:old.professionalId):'';
 const [partyId,setPartyId]=useState(oldId||modal?.professionalId||modal?.customerId||(party==='customer'?state.customers[0]?.id:state.professionals[0]?.id)||''),[file,setFile]=useState<File|null>(null),[terms,setTerms]=useState<File|null>(null),[checked,setChecked]=useState(false);
 const recipient=partyDetails(state,party,partyId);
 return <form onSubmit={e=>{e.preventDefault();const f=new FormData(e.currentTarget);void submit.submit(async()=>{if(!file)throw Error('Upload de vooraf ondertekende raamovereenkomst.');const asset=await readAsset(file),conditions=terms?await readAsset(terms):undefined;return s=>{let next=saveCompanyDetails(s,account,party,partyId,readCompanyFields(f,'recipient'));next=saveCompanyDetails(next,account,'issuer','infranexus',readCompanyFields(f,'issuer'));return registerSignedBase(next,account,party,partyId,asset,textValue(f,'from'),textValue(f,'until'),textValue(f,'signedOn'),checked,conditions);};},'Ondertekende raamovereenkomst opgeslagen en zichtbaar bij Contracten');}}>
 <Hint>Deze overeenkomst is al vóór het openen van het account ondertekend. HR uploadt de PDF; de klant of professional hoeft hem niet opnieuw te tekenen. Tarieven en verwachte inzet worden per opdracht online geaccepteerd.</Hint>
 <Field label={party==='customer'?'Klant':'ZZP-professional'}><Choice disabled={!!old} value={partyId} onChange={setPartyId} options={party==='customer'?state.customers.map(c=>({value:c.id,label:c.name})):state.professionals.map(p=>({value:p.id,label:p.name}))} label="Contractpartij"/></Field>
 <h3>Bedrijfsgegevens contractpartij</h3><CompanyFields key={partyId} prefix="recipient" value={recipient}/><details className="company-edit-inline"><summary>Bedrijfsgegevens InfraNexus bekijken of wijzigen</summary><CompanyFields prefix="issuer" value={issuerDetails(state)}/></details>
 <div className="fields"><Field label="Looptijd vanaf *"><input name="from" type="date" required defaultValue={v?.from||`${new Date().getFullYear()}-01-01`}/></Field><Field label="Looptijd tot *"><input name="until" type="date" required defaultValue={v?.until||`${new Date().getFullYear()+3}-12-31`}/></Field><Field label="Ondertekend op *"><input name="signedOn" type="date" required max={workflowDate()} defaultValue={workflowDate()}/></Field></div>
 <UploadField label="Vooraf ondertekende raamovereenkomst (PDF) *" accept="application/pdf" onChange={setFile}/><UploadField label="Algemene voorwaarden (PDF, als aparte bijlage)" accept="application/pdf" required={false} onChange={setTerms}/>
 <Checkline checked={checked} onChange={setChecked}>Deze PDF is vooraf door de partijen ondertekend. Ik heb het document, de partijen en de looptijd gecontroleerd.</Checkline><Footer busy={submit.busy} error={submit.error} disabled={!checked||!file} label="Ondertekende overeenkomst opslaan"/>
 </form>;
}
