'use client';
import { createContext, useContext } from 'react';
import type { Account, DemoState } from '@/lib/demo';
import type { Page, PortalState } from '@/lib/portal';
import type { FileAsset } from '@/lib/operations-types';
export type PortalModal = {
    kind: string; requestId?: string; customerId?: string;
    templateScope?: 'company'|'project';
    section?:string;logId?:string;handoverId?:string;
    id?: string;
    projectId?: string;
    professionalId?: string;
    candidateId?: string;
    date?: string;
    dates?: string[];
    file?: FileAsset;
} | null;
export type PortalContextValue = {
    state: PortalState;
    account: Account;
    page: Page;
    record: string | null;
    go: (page: Page, id?: string) => void;
    modal: PortalModal;
    previewFile?:FileAsset|null;
    setPreviewFile?:(file:FileAsset|null)=>void;
    setModal: (modal: PortalModal) => void;
    run: (update: (s: PortalState) => DemoState, label: string) => boolean;
    runAsync?:(update:(s:PortalState)=>DemoState,label:string)=>Promise<boolean>;
    act?:(command:import('@/lib/project-ops').OpsCommand,label:string)=>Promise<boolean>;
    request?:(path:string,body?:unknown)=>Promise<any>;
    refresh?:()=>Promise<void>;
};
export const PortalContext = createContext<PortalContextValue | null>(null);
export function usePortal() { const value = useContext(PortalContext); if (!value)
    throw new Error('PortalContext ontbreekt'); return value; }
