'use client';
import {useState} from 'react';
import {Action} from './ui';
import {downloadEmail} from '@/lib/mail-download';
export function MailDownloadButton({build,name,label='E-mailconcept met bijlagen'}:{build:()=>Promise<string>;name:string;label?:string}){const [busy,setBusy]=useState(false),[error,setError]=useState('');return <div><Action disabled={busy} onClick={()=>{setBusy(true);setError('');void build().then(text=>downloadEmail(text,name)).catch(e=>setError(e.message)).finally(()=>setBusy(false));}}>{busy?'Bijlagen verzamelen…':label}</Action>{error&&<p className="form-error" role="alert">{error}</p>}</div>;}
