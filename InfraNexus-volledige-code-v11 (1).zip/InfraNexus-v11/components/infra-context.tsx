'use client';
import {createContext,useContext} from 'react';
import type {Account,DemoState,View} from '@/lib/demo';
export type Detail={type:'project'|'customer'|'professional'|'candidate'|'log';id:string}|null;
export type Modal={type:string;projectId?:string;professionalId?:string;date?:string;id?:string}|null;
export type Context={state:DemoState;account:Account;view:View;detail:Detail;go:(v:View,d?:Detail)=>void;modal:Modal;setModal:(m:Modal)=>void;change:(fn:(s:DemoState)=>DemoState,action:string,entity:string,id:string,before?:string,after?:string)=>void};
export const InfraContext=createContext<Context|null>(null);
export function useInfra(){const c=useContext(InfraContext);if(!c)throw new Error('InfraContext ontbreekt');return c;}
