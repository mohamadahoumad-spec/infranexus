'use client';
import React, { useState } from 'react';
import { Check, CheckCircle2, FileText, Download, Send, CalendarDays, MessageSquare, ShieldCheck } from 'lucide-react';
import { toast } from 'sonner';
import { useInfra } from './infra-context';
import { Badge, Btn, Empty, Field, KeyValues, Notice, Pick } from './infra-ui';
import { TODAY, canPlan, canReview, formatDate, isInternal, isProfessional, visibleDocs, visibleProjects } from '@/lib/demo';
import { acknowledgeDocument, addReport, availabilityConflicts, isoRange, professionalReports, respondToReport, setOwnAvailability, submitCertificate } from '@/lib/professional';
import { readLocalFile } from '@/lib/client-files';
export function ProfessionalForm({ type }: {
    type: string;
}) {
    if (type === 'pro-availability')
        return <AvailabilityRange />;
    if (type === 'pro-report')
        return <ReportForm />;
    if (type === 'pro-report-detail')
        return <ReportDetail />;
    if (type === 'pro-certificate')
        return <CertificateForm />;
    if (type === 'pro-profile')
        return <ProfileForm />;
    if (type === 'pro-document')
        return <ProfessionalDocument />;
    return null;
}
function Actions({ label = 'Opslaan', busy = false }: {
    label?: string;
    busy?: boolean;
}) {
    const { setModal } = useInfra();
    return <div className="form-footer"><Btn onClick={() => setModal(null)}>Annuleren</Btn><Btn type="submit" primary disabled={busy}><Check size={17}/>{busy ? 'Bezig…' : label}</Btn></div>;
}
function AvailabilityRange() {
    const { state, account, modal, setModal, change } = useInfra();
    const [from, setFrom] = useState(modal?.date || TODAY), [to, setTo] = useState(modal?.date || TODAY), [status, setStatus] = useState('Beschikbaar'), [error, setError] = useState('');
    let conflicts: ReturnType<typeof availabilityConflicts> = [];
    try {
        conflicts = availabilityConflicts(state, account, from, to, status);
    }
    catch { }
    function submit(e: React.FormEvent) { e.preventDefault(); try {
        setOwnAvailability(state, account, from, to, status);
        change(s => setOwnAvailability(s, account, from, to, status), 'Beschikbaarheid doorgegeven', 'Professional', account.professionalId!, '—', `${from} t/m ${to} · ${status}`);
        setModal(null);
        toast.success('Je beschikbaarheid staat nu ook in de centrale planning.');
    }
    catch (err) {
        setError((err as Error).message);
    } }
    return <form onSubmit={submit}><div className="form-grid"><Field label="Van"><input type="date" value={from} required onChange={e => { setFrom(e.target.value); if (to < e.target.value)
        setTo(e.target.value); }}/></Field><Field label="Tot en met"><input type="date" value={to} required min={from} onChange={e => setTo(e.target.value)}/></Field><Field label="Beschikbaarheid" wide><Pick value={status} onChange={setStatus} options={['Beschikbaar', 'Niet beschikbaar', 'Vakantie / afwezig']} label="Beschikbaarheid"/></Field></div>{conflicts.length > 0 ? <Notice kind="warning"><b>Er staat al inzet in deze periode.</b><p>{conflicts.map(c => formatDate(c.date)).join(', ')}. Stem deze wijziging eerst af met planning.</p></Notice> : <Notice>Deze beschikbaarheid wordt direct overgenomen in het overzicht van planning. Je bestaande projectinzet verandert niet.</Notice>}{error && <p className="form-error" role="alert">{error}</p>}<Actions label="Beschikbaarheid doorgeven" busy={conflicts.length > 0}/></form>;
}
function ReportForm() {
    const { state, account, modal, setModal, change } = useInfra();
    const projects = visibleProjects(state, account);
    const [project, setProject] = useState(modal?.projectId || projects[0]?.id || ''), [type, setType] = useState('Projectvraag'), [error, setError] = useState('');
    function submit(e: React.FormEvent<HTMLFormElement>) { e.preventDefault(); const f = new FormData(e.currentTarget); const data = { projectId: project, type, date: String(f.get('date')), title: String(f.get('title') || ''), description: String(f.get('description') || '') }; try {
        const next = addReport(state, account, data);
        const report = next.reports[0];
        change(s => ({ ...s, reports: [report, ...s.reports], notifications: [next.notifications[0], ...s.notifications] }), 'Projectmelding ingediend', 'Project', project, '—', data.title);
        setModal(null);
        toast.success('Je melding staat in het projectdossier bij de backoffice.');
    }
    catch (err) {
        setError((err as Error).message);
    } }
    return <form onSubmit={submit}><div className="form-grid"><Field label="Project *" wide><Pick value={project} onChange={setProject} options={projects.map(p => ({ value: p.id, label: p.name }))} label="Project"/></Field><Field label="Soort melding"><Pick value={type} onChange={setType} options={['Projectvraag', 'Afwijking', 'Overdracht', 'Planning', 'Overig']} label="Soort melding"/></Field><Field label="Datum"><input type="date" name="date" defaultValue={TODAY} required/></Field><Field label="Onderwerp *" wide><input name="title" maxLength={150} placeholder="Waar gaat je melding over?" required/></Field><Field label="Toelichting *" wide><textarea name="description" rows={5} maxLength={5000} required placeholder="Beschrijf wat je wilt doorgeven en welke afstemming je nodig hebt."/></Field></div><Notice>De backoffice ontvangt je melding in het projectdossier. Voor directe afstemming bel je de contactpersoon op je project.</Notice>{error && <p className="form-error" role="alert">{error}</p>}<Actions label="Melding indienen"/></form>;
}
function ReportDetail() {
    const { state, account, modal, setModal, change } = useInfra();
    const report = professionalReports(state, account).find(r => r.id === modal?.id);
    const [status, setStatus] = useState(report?.status || 'Nieuw'), [response, setResponse] = useState(report?.response || ''), [error, setError] = useState('');
    if (!report)
        return <Empty title="Melding niet beschikbaar" text="Deze melding hoort niet bij deze omgeving."/>;
    const canRespond = canPlan(account) || canReview(account);
    return <><Badge>{report.status}</Badge><h3>{report.title}</h3><KeyValues items={[["Project", state.projects.find(p => p.id === report.projectId)?.name], ['Datum', formatDate(report.date)], ['Soort', report.type]]}/><p className="pro-preserve-text">{report.description}</p>{report.response && <div className="pro-feedback"><b>Reactie van de backoffice</b><p>{report.response}</p></div>}{canRespond && <form onSubmit={e => { e.preventDefault(); try {
        respondToReport(state, account, report.id, status, response);
        change(s => respondToReport(s, account, report.id, status, response), 'Projectmelding beoordeeld', 'Project', report.projectId, report.status, status);
        setModal(null);
        toast.success('Reactie zichtbaar in het professionalportaal.');
    }
    catch (err) {
        setError((err as Error).message);
    } }}><div className="form-grid"><Field label="Status" wide><Pick value={status} onChange={v => setStatus(v as typeof status)} options={['Nieuw', 'In behandeling', 'Afgehandeld']} label="Meldingstatus"/></Field><Field label="Terugkoppeling aan professional" wide><textarea rows={4} value={response} maxLength={3000} onChange={e => setResponse(e.target.value)}/></Field></div>{error && <p className="form-error" role="alert">{error}</p>}<Actions label="Reactie vastleggen"/></form>}</>;
}
function CertificateForm() {
    const { state, account, setModal, change } = useInfra();
    const [type, setType] = useState('VCA-VOL'), [file, setFile] = useState<File | null>(null), [busy, setBusy] = useState(false), [error, setError] = useState('');
    async function submit(e: React.FormEvent<HTMLFormElement>) { e.preventDefault(); const f = new FormData(e.currentTarget); setError(''); if (!file || !['application/pdf', 'image/jpeg', 'image/png', 'image/webp'].includes(file.type) || file.size > 2 * 1024 * 1024) {
        setError('Voeg een PDF, JPG, PNG of WebP van maximaal 2 MB toe.');
        return;
    } setBusy(true); try {
        const data = { type, issuer: String(f.get('issuer') || ''), achieved: String(f.get('achieved') || ''), expiry: String(f.get('expiry') || ''), name: file.name, url: await readLocalFile(file), mime: file.type };
        const next = submitCertificate(state, account, data);
        const submission = next.certificateSubmissions[0];
        change(s => ({ ...s, certificateSubmissions: [submission, ...s.certificateSubmissions], notifications: [next.notifications[0], ...s.notifications] }), 'Kwalificatiebewijs aangeleverd', 'Professional', account.professionalId!, '—', `${type} · controle nodig`);
        setModal(null);
        toast.success('Bewijs aangeleverd. De backoffice voert de controle uit.');
    }
    catch (err) {
        setError((err as Error).message);
    }
    finally {
        setBusy(false);
    } }
    return <form onSubmit={submit}><div className="form-grid"><Field label="Kwalificatie *"><Pick value={type} onChange={setType} options={['VCA-VOL', 'DLP', 'R-DLP', 'KVP', 'Overig']} label="Kwalificatie"/></Field><Field label="Uitgever *"><input name="issuer" required maxLength={160}/></Field><Field label="Behaaldatum"><input type="date" name="achieved"/></Field><Field label="Vervaldatum *"><input type="date" name="expiry" required/></Field><Field label="Bewijsbestand *" wide><input type="file" required accept="application/pdf,image/jpeg,image/png,image/webp" onChange={e => setFile(e.target.files?.[0] || null)}/><small>Maximaal 2 MB. Gebruik alleen fictieve testbestanden in deze demo.</small></Field></div><Notice>Je huidige kwalificatie blijft leidend tot de backoffice het nieuwe bewijs heeft gecontroleerd. Uploaden geeft geen automatische goedkeuring of vrijgave.</Notice>{error && <p className="form-error" role="alert">{error}</p>}<Actions label="Ter controle aanbieden" busy={busy}/></form>;
}
function ProfileForm() {
    const { state, account, setModal, change } = useInfra();
    const person = state.professionals.find(p => p.id === account.professionalId);
    if (!person)
        return <Empty />;
    return <form onSubmit={e => { e.preventDefault(); const f = new FormData(e.currentTarget); const patch = { email: String(f.get('email') || '').trim(), phone: String(f.get('phone') || '').trim(), city: String(f.get('city') || '').trim(), company: String(f.get('company') || '').trim(), kvk: String(f.get('kvk') || '').trim() }; if (!isProfessional(account))
        return; change(s => ({ ...s, professionals: s.professionals.map(p => p.id === account.professionalId ? { ...p, ...patch } : p) }), 'Contactgegevens gewijzigd', 'Professional', person.id, JSON.stringify({ email: person.email, phone: person.phone, city: person.city, company: person.company, kvk: person.kvk }), JSON.stringify(patch)); setModal(null); toast.success('Je contactgegevens zijn ook in de backoffice bijgewerkt.'); }}><div className="form-grid"><Field label="Naam" wide><input value={person.name} disabled/></Field><Field label="Contact e-mail *"><input name="email" type="email" defaultValue={person.email} required maxLength={160}/></Field><Field label="Telefoon"><input name="phone" type="tel" defaultValue={person.phone} maxLength={40}/></Field><Field label="Woonregio *" wide><input name="city" defaultValue={person.city} required maxLength={120}/></Field><Field label="Bedrijfsnaam"><input name="company" defaultValue={person.company || ''} maxLength={160}/></Field><Field label="KvK-nummer"><input name="kvk" inputMode="numeric" pattern="[0-9]{8}" placeholder="8 cijfers" maxLength={8} defaultValue={person.kvk || ''}/></Field></div><Actions label="Gegevens bijwerken"/></form>;
}
function ProfessionalDocument() {
    const { state, account, modal, change } = useInfra();
    const doc = visibleDocs(state, account).find(d => d.id === modal?.id);
    if (!doc)
        return <Empty title="Document niet beschikbaar" text="Dit document is niet gedeeld met jouw projecten."/>;
    const viewed = state.documentReceipts.some(r => r.documentId === doc.id && r.version === doc.version && r.professionalId === account.professionalId);
    const p = state.projects.find(p => p.id === doc.projectId)!;
    return <><div className="pro-document-heading"><span className="file-icon"><FileText /></span><div><h3>{doc.name}</h3><small>{p.number} · versie {doc.version}</small></div></div>{doc.url ? <>{doc.mime?.startsWith('image/') && <img className="uploaded-image" src={doc.url} alt={doc.name}/>}<a className="btn" href={doc.url} download={doc.name}><Download size={17}/>Bestand downloaden</a></> : <div className="pro-sample-document"><span className="eyebrow">VOORBEELDREGISTRATIE</span><h3>{p.name}</h3><KeyValues items={[["Projectlocatie", p.address], ['Contactpersoon', p.contact], ['Telefoon', p.phone], ['Projectperiode', `${formatDate(p.start)} – ${formatDate(p.end)}`]]}/><p>{p.description}</p><small>Er is nog geen origineel bestand aan deze voorbeeldregistratie gekoppeld. De bovenstaande informatie komt uit het gedeelde projectdossier.</small></div>}<div className="form-footer">{viewed ? <span className="pro-success-label"><CheckCircle2 size={18}/>Deze versie heb je bekeken</span> : <Btn primary onClick={() => { change(s => acknowledgeDocument(s, account, doc.id), 'Documentversie bekeken', 'Document', doc.id, 'Niet bekeken', `v${doc.version} · ${account.name}`); toast.success('Bekeken versie geregistreerd.'); }}>Ik heb deze versie bekeken</Btn>}</div></>;
}
