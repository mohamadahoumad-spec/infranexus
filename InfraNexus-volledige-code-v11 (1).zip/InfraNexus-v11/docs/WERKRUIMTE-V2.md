# Werkruimte v2 — functionele herbouw

Deze versie vervangt de eerdere navigatie en schermstructuur. De bestaande bron en gegevens worden behouden, terwijl de actieve toepassing opnieuw is opgebouwd.

## Nieuwe samenhang

| Stap | Verantwoordelijke | Resultaat / voorwaarde |
|---|---|---|
| Aanvraag | Klant, HR of Planning | Eigen projectnaam, datums, werkinformatie, opgegeven klasse en bijlagen |
| Controle | HR / Planning | Accepteren, gerichte aanvulling vragen of gemotiveerd afwijzen |
| Contractdossier | HR / Admin | Nieuwe overeenkomst of koppeling met een geldige ondertekende raamovereenkomst |
| Overeenkomst delen | HR / Admin | Eigen gecontroleerde PDF en looptijd zichtbaar voor betrokken klant |
| Ondertekend retour | Klant of HR | Retour-PDF wordt aan de juiste overeenkomstversie toegevoegd |
| Ondertekening controleren | HR / Admin | Menselijke controle activeert de overeenkomst; correcties behouden eerdere bestanden |
| Inzet | Planning | Per datum contract, functie, bewijs, vrijgave, maandopgave en conflicten controleren |
| Werkdag vastleggen | Professional | Het juiste klantlogboek invullen en indienen voor een eigen projectdag |
| Logboekcontrole | HR | Akkoord of correctie; klant ziet alleen goedgekeurde versies |
| Zzp-factuur | Professional, HR, Finance | PDF per week / eigen projecten; HR eerst, betalingsregistratie daarna |
| Klantfactuur | Finance | Concept-PDF, daarna expliciet delen met alleen de eigen klant |

Een raamovereenkomst is een dossier met PDF-versies. Het systeem stelt geen juridische contracttekst op en verzamelt geen handtekening door een vinkje. Een ondertekend PDF-exemplaar wordt geüpload en door HR gecontroleerd. De voorbeeldbestanden zijn uitsluitend fictief.

## Toegang in het concept

- Klant ziet eigen aanvragen, gedeelde raamovereenkomsten, projecten, ingeplande professionals, gedeelde bewijsstukken, goedgekeurde logboeken, eigen facturen en eigen teamgesprekken.
- Professional ziet eigen inzet, beschikbaarheid, contact- en bedrijfsgegevens, bewijzen, toegewezen projectinformatie, eigen logboeken, eigen facturen en eigen gesprekken.
- Planning verwerkt aanvragen, ziet contractstatus en kwalificaties, plant meerdere dagen en kan werktijden aanpassen of gemotiveerd annuleren. Geen privé-CV’s of HR-documenten.
- HR beheert instroom, onboarding, vrijgave, privébestanden, bewijscontrole, contractcontrole, logboeken en zzp-factuurcontrole.
- Finance maakt klantfacturen, ziet contracten en verwerkt zzp-facturen na HR-akkoord. Geen privé HR-bestanden.
- Customer Support ziet klant-/projectcontext en behandelt berichten.
- Business Development beheert nieuwe klantrelaties en volgt aanvragen/samenwerkingen.
- Admin heeft de beheerrechten en de huisstijlinstellingen.

Het scherm **Organisatie & toegang** geeft een leesbare matrix. Dit zijn frontendvoorbeeldrollen. Serverautorisatie moet vóór gebruik met echte bedrijfsgegevens worden toegevoegd.

## Planning

Vrije dagen selecteren kan direct in de weekmatrix. De selectie blijft voor één professional; meerdere weken kunnen worden bekeken. Daarna kies je het project en legt Planning de batch vast. Er worden nooit enkele dagen uit een ongeldige batch opgeslagen.

Na volledige bezetting van de aangevraagde werkdagen verandert een voorbereid project naar Ingepland. Annulering wordt als status bewaard en kan een project terugzetten naar Planning nodig. De betrokken professional krijgt daarvan een interne portaalmelding.

Een maandopgave wordt volledig bevestigd: gekozen dagen zijn beschikbaar, overige dagen niet. Nog niet ingediende maanden zijn geblokkeerd. Geannuleerde inzet blokkeert de maandopgave niet.

## Logboeken

De standaardroute in de nieuwe schermen is het klantbestand:

1. HR uploadt het lege logboek op het project; nieuwe sjablonen krijgen een nieuw versienummer.
2. De professional downloadt het sjabloon bij Mijn werkdagen of Sjablonen.
3. Het ingevulde bestand wordt gekoppeld aan een eigen actieve inzetdag.
4. HR bekijkt het bestand en geeft akkoord of een concrete correctiereden.
5. Een correctie wordt als nieuwe ingevulde versie ingediend; de eerdere versies blijven terug te lezen.
6. De betrokken klant ziet uitsluitend goedgekeurde versies.

Digitale dagregistraties uit de eerdere omgeving blijven in dezelfde inzendingenlijst en kunnen nog worden beoordeeld of gecorrigeerd.

## Berichtencentrum

Een gesprekkenlijst toont naam, onderwerp, laatste bericht, afdeling en ongelezen markering. De geselecteerde conversatie opent direct daarnaast. Na een nieuw bericht blijft het juiste gesprek geopend. Er zijn geen automatische chatbotantwoorden.

Klant en professional hebben ieder een eigen lijn met InfraNexus. Ze kunnen geen gesprek met elkaar beginnen. Interne collega’s kunnen elkaar gericht benaderen. Een prioriteitsmarkering is geen automatische noodoproep of toezegging van responstijd. Berichten blijven in dit concept op hetzelfde apparaat.

## Ontwerp en merkmateriaal

De navigatiegroepen staan in een donkerblauwe zijbalk. Donkerblauw (#163A59) en oranje (#F47A20) vormen de huisstijl. Content staat op lichte vlakken met donkerblauwe tekst; op donkerblauwe vlakken wordt witte tekst gebruikt. Oranje knoppen hebben donkerblauwe tekst. De kleurcorrectie laat de indeling en werkstromen intact. Het primaire logo en kleine beeldmerk zijn met de ingebouwde beeldbewerking van de buitenste achtergrond ontdaan; de oorspronkelijke vorm, merkkleuren en witte binnenvorm zijn behouden. De originele bestanden zijn niet overschreven.

Nieuwe assets: `public/brand/primary-logo-v2.png` en `public/brand/mark-v2.png`. Beide bevatten echte alfa-transparantie. Klantlogo’s kunnen door Admin worden toegevoegd voor gezamenlijke branding.

## Verificatie

- TypeScript-controle.
- 33 domeintests: oorspronkelijke scope/finance/kwalificatieregels en nieuwe aanvraag–contract–planning-scenario’s.
- 8 rendercontroles: eerdere schermen plus de nieuwe shell, alle toegestane rolpagina’s, dossierdetails, bestandsrechten en de nieuwe formulieren.
- Productiebouw en publicatie via de bestaande Site.
- Geen visuele of interactieve browsertest in deze omgeving.

De rendercontroles bewijzen geen responsive of interactieve browseracceptatie. Echte authenticatie, centrale opslag, private uploads, gelijktijdige servertransacties en externe bezorging blijven werkzaamheden voor een productiefase.
