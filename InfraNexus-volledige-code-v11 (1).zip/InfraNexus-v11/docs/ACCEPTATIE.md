# Huidige verificatie: werkruimte v2

De actuele applicatie, rollen, scenario’s en grenzen staan in `WERKRUIMTE-V2.md`. De onderstaande eerste-revisiecontroles blijven historische referentie. Werkruimte v2 voegt 10 domeintests en 5 rendercontroles toe; de volledige suite telt 41 controles.

# Acceptatie en controle

## Uitgevoerde geautomatiseerde controles

TypeScript controle: zonder fouten.

23 domeintests in `tests/domain.test.mjs` en `tests/operations.test.mjs`, plus 3 rendercontroles in `tests/screens.test.mjs`, slagen voor deze revisie. De oorspronkelijke elf controles blijven aanwezig:

1. Klant A en B hebben gescheiden projectselecties.
2. Een professional ziet alleen toegewezen projecten, inzet en eigen logboeken.
3. Documentselectie vereist projectbereik, expliciete deling en controle.
4. Een klantselectie bevat uitsluitend goedgekeurde/definitieve logboeken.
5. Finance-capability ontbreekt voor planners en externe voorbeeldrollen.
6. Planning signaleert dubbele inzet, afwezigheid, ontbrekende en verlopen bewijzen.
7. V&G-plan kan niet als personeelsinzet worden gepland; datums buiten het project worden geblokkeerd.
8. Certificaatvervaldag en waarschuwingen worden consistent berekend.
9. Conceptlogboeken tellen niet als ingediende administratie.
10. Een correctie verandert eerdere snapshots, uren of foto-omschrijvingen niet.
11. Weeknavigatie werkt over maandgrenzen.

Dit zijn functionele tests van een frontendprototype, **geen bewijs van serverbeveiliging**. De fictieve demo-data is aanwezig in de browser.

De begeleide browserpreview was in deze omgeving niet beschikbaar. Daardoor zijn de volledige klikflows en responsive weergave niet met een browser geverifieerd. Onderstaande scenario’s blijven te beoordelen.

## Handmatige scenario’s voor de beoordeling

- Open het Command Center, klik een KPI, gebruik zoeken en open een project.
- Voeg een klant en een project toe. Controleer het nieuwe dossier en de auditregels.
- Plan Thomas Bakker op Kabeltracé Westpoort, 7 oktober 2026. Dit past binnen de voorbeeldregels. Controleer de weekplanning.
- Probeer Daan Vermeer nogmaals op 6 oktober in te plannen: de dubbele inzet moet geblokkeerd worden.
- Wissel naar Daan Vermeer. Controleer dat alleen Maasvlakte beschikbaar is.
- Maak voor Daan een logboek op 6 oktober. Sla een concept op, vul aan en dien in. Een tweede logboek voor dezelfde inzetdag moet worden geweigerd.
- Voeg een kleine fictieve afbeelding toe en geef een omschrijving op.
- Wissel terug naar Super Admin, keur het logboek goed en maak het definitief.
- Vraag een correctie met reden; wissel terug naar Daan, wijzig tekst/uren/foto-omschrijving en dien opnieuw in. Controleer dat de eerdere versie ongewijzigd terug te lezen is.
- Wissel naar Delta Infra: geen project van Noordlijn, geen interne notities, alleen de eigen gedeelde klantfacturen; geen interne financiële gegevens en geen interne documenten.
- Voeg een testdocument toe: standaard uitsluitend backoffice. Rond controle af en stel expliciete zichtbaarheid in. Controleer de externe voorbeeldrol.
- Verplaats een kandidaat via slepen of de statuskeuze. Vrijgeven is pas mogelijk met de volledige checklist; omzetting naar professional is expliciet en eenmalig.
- Dien vanuit Delta Infra een nieuwe aanvraag in en controleer deze in de backoffice.
- Herlaad de browser: demo-wijzigingen blijven op hetzelfde apparaat bewaard. Gebruik Beheer → Blauwdruk → herstellen om opnieuw te beginnen.
- Controleer op telefoonbreedte: mobiel menu, eigen werkdag, logboekinvoer, toetsenbordfocus, labels en overzichtelijke horizontale planning-/tabelscroll.

## Vereiste gates vóór productie

- Echte login, reset, verificatie, MFA en sessie-/accountintrekking.
- Servertests voor horizontale én verticale privilege-escalatie, directe record-URL’s, downloads, exports en aggregate endpoints.
- Servertransacties en gelijktijdige planningsconflicten.
- Append-only logboek- en documentversies, inclusief immutable bestanden.
- Veilige uploadketen, private objectopslag en verlopen downloadlinks.
- Toegestane velden per rol; alleen de eigen facturen naar externe clients, nooit interne marges of andere dossiers.
- Goedgekeurde kwalificatie-, retentie-, escalatie- en tariefregels.
- Geïsoleerde restoretest van database en bestanden.
- Browseracceptatie van de volledige mobiele logboekflow en desktopplanning.

## Revisie 1

De aanvullende tests controleren maandindiening, atomaire meerdaagse planning, omzetting van kandidaten met contact- en bedrijfsgegevens, behoud van CV en bewijsstukken, certificaatcontrole/deling, nieuwe klantaanvragen, sjabloon- en logboekversies, gescheiden chatkanalen, HR-voor-Finance, factuurcorrecties en klantfacturen per organisatie. Rendercontroles openen alle professionalbestemmingen, de nieuwe afdelingsschermen en formulieren zonder browser. Dit controleert componentfouten en aanwezige velden; het vervangt geen visuele browseracceptatie.
