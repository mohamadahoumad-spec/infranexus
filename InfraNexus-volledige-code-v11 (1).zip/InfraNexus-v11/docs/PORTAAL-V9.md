# Portaal versie 9 — opdrachtbevestigingen en dagelijkse bestanden

## Opdrachtbevestiging conform de raamovereenkomst

Meldingen, directe acties, schermkoppen, formulieren en nieuw gegenereerde PDF’s gebruiken **opdrachtbevestiging**. De klant opent de bevestiging vanuit de melding en geeft zelf akkoord op de exacte versie conform de gekoppelde hoofdraamovereenkomst en toepasselijke algemene voorwaarden. De verklaring benoemt bevoegdheid, vooraf kunnen lezen en opslaan, verwachte inzet, tarieven, kosten en registratie van afwijkingen. De toelichting over uren is verkort.

De externe mailteksten noemen InfraNexus. Handmatige verzending blijft buiten het portaal plaatsvinden. Een gedownload e-mailconcept registreert geen verzending. Bestaande acceptatieverklaringen, geaccepteerde bestanden en verzendregistraties worden niet herschreven. Oude notificatietitels met “offerte / opdracht” krijgen bij het laden de nieuwe weergaveterm.

Deze benaming wijzigt de onderliggende contractroute niet. De eigen hoofdraamovereenkomst en voorwaarden blijven bepalend; de software is geen juridische certificering. De uitgangspunten en juridische productiegrens uit [versie 8](PORTAAL-V8.md#juridisch-uitgangspunt-en-productiegrens) blijven gelden.

## Meerdere mailbijlagen voor klant en zzp’er

De bestandskiezer voegt opeenvolgende selecties samen. Gebruikers zien de geselecteerde bestanden en kunnen elk bestand uit de selectie verwijderen. PDF, JPG, PNG, WebP, Word, Excel, CSV en tekst worden ondersteund, met maximaal 10 MB per bestand en 50 MB per dossierselectie. Het e-mailconcept combineert de vaste opdrachtstukken, bestaande aanvullende bijlagen en de nieuw geselecteerde bestanden.

Nieuwe opdrachtversies bewaren het beschikbare V&G-plan uit het juiste project als aparte documentkopie. De bevestigingsmail voor de professional neemt die kopie automatisch mee. Een latere wijziging van het projectplan verandert een eerder aangeboden of geaccepteerd exemplaar niet. Interne HR-stukken en verkoopprijzen uit de klantopdracht worden niet toegevoegd aan de professionele opdrachtmail. Zonder beschikbaar V&G-plan wordt geen fictief plan gegenereerd.

Bij het registreren van de werkelijke mailverzending worden de extra bestanden en tekst opgeslagen. Latere aanvullingen bewaren eerdere teksten en het oorspronkelijke verzendmoment. Bestanden met verschillende namen blijven afzonderlijke referenties, ook als hun inhoud gelijk is. Er is nog steeds geen automatische mailverzending aangesloten.

## Medische keuring en btw-nummer

De certificaatkeuze bevat **Medische keuring bodemsanering A/B** en **Medische keuring bodemsanering C**, beschikbaar voor de professional en HR. Uploads gaan naar de bestaande controlewachtrij. Goedkeuring registreert de categorie en geldigheidsdatum zonder automatisch een veiligheidsfunctie of geschiktheid voor elk project toe te kennen.

De uploadinstructie vraagt om de verklaring van inzetbaarheid, zonder medische onderzoeksresultaten. Het document blijft bij de eigen professional en HR; planning en klanten krijgen geen toegang tot het originele medische document via het certificaatscherm. Het wordt niet als klantbewijs of mailprojectbijlage geëxporteerd. De juiste keuringseis blijft onderwerp van het V&G-plan en de bevoegde beoordeling.

Het btw-nummer is bewerkbaar in de gewone contact-/zzp-gegevens. Het blijft ook behouden bij doorstroom van kandidaat naar professional. Bedrijfsgegevens blijven beschikbaar voor nieuwe opdrachtbevestigingen; historische geaccepteerde partijgegevens blijven ongewijzigd.

## Logboeken als dagelijks bestandsdossier

**Logboeken & bestanden → Bestanden & foto’s** toont dagmappen per project en professional. Er is een filter op project, werkdag en zoekterm. Een dagversie bevat meerdere documenten en foto’s met soort en bijschrift. Foto’s hebben een voorbeeldweergave; alle bestanden kunnen afzonderlijk worden bekeken en gedownload.

Een bestaande dagversie opent met de bestaande bestanden geselecteerd. De professional, HR of planning kan bestanden toevoegen, vervangen of uit de volgende versie verwijderen. De eerdere versie blijft bestaan. Nieuwe wijzigingen vragen opnieuw inhoudelijke controle. De klant kan bestanden niet aanpassen of verwijderen.

De aanvullende dagregistratie bevat werkvak, werkzaamheden, waarnemingen/omstandigheden, meet- en monsterreferenties, grondstromen/transportreferenties en afwijkingen/maatregelen. Die gegevens worden bij het gecontroleerde dagdossier opgeslagen en komen als leesbare PDF mee in het weekpakket. Dit ondersteunt verslaglegging, maar is geen automatische verklaring dat aan een BRL- of projectprotocol is voldaan.

Een weekcontrole verwijst naar de exacte goedgekeurde dagversies met alle bijlagen. Een latere dagwijziging maakt de eerdere weekversie niet actueel; HR deelt na controle een nieuwe weekversie. De bestaande 48-uurscontrole vanaf vrijdag of projectafsluiting blijft bestaan. Verwijderen na aflevering blijft geblokkeerd zonder geverifieerde aflevering en klantcontrole; wanneer die voorwaarden zijn vervuld worden alle bestanden en foto’s in het betreffende dagdossier gewist, met behoud van metadata.

## Bedrijfs- en projectsjablonen

Een nieuw sjabloon is standaard gekoppeld aan het **klantbedrijf** en geldt daardoor ook voor latere projecten van dezelfde klant. HR en de klant kunnen een eigen bedrijfssjabloon aanleveren. Een expliciet projectsjabloon krijgt voorrang voor dat project. Professionals kunnen alleen de passende sjablonen van hun eigen projectomgevingen downloaden. Oude projectsjablonen behouden hun bestaande koppeling.

## Geraadpleegde bronnen

- [SIKB Protocol 6005, versie 6.0](https://www.sikb.nl/doc/BRL6000/Protocol%206005%20vs%206.0.pdf), eis 6.26: dagelijkse actualisering, relevante waarnemingen, metingen, afwijkingen en ondersteunende vastlegging. De extra registratievelden zijn hierop geïnspireerd; zij vervangen de toepasselijke project- en rolvereisten niet.
- [ArboNed — Bodemsaneringskeuring CROW A, B, C](https://www.arboned.nl/diensten/keuringen/bodemsaneringskeuring): categorieën en onderscheid naar gebruik van adembescherming.
- [Autoriteit Persoonsgegevens — Gegevens over gezondheid bij sollicitaties](https://autoriteitpersoonsgegevens.nl/themas/werk-en-uitkering/sollicitaties/gegevens-over-gezondheid-bij-sollicitaties): beperking van medische gegevens in werkgeversprocessen. De implementatie vraagt om de verklaring, geen onderzoeksdossier.

## Verificatie en grenzen

- 85 domeintests en 22 rendercontroles geslaagd. Nieuwe controles omvatten bedrijfssjablonen, dagbundels, hercontrole na wijziging, alle bestanden in weekmail, medische afscherming, btw-doorgifte, het V&G-plan in de zzp-mail en behoud van oude akkoordbewijzen.
- TypeScriptcontrole en `git diff --check` geslaagd. Nieuwe opdracht-PDF’s met logo visueel gerenderd en gecontroleerd.
- De begeleide browserpreview was niet beschikbaar. Opeenvolgende bestandsselecties, daadwerkelijke downloads, mobiel gebruik en de volledige klikflow zijn niet interactief met een browser geverifieerd.
- Dit blijft de bestaande conceptomgeving met lokale IndexedDB-opslag en voorbeeldrollen. Er zijn geen echte beveiligde login, centrale autorisatie of beveiligde bestandsopslag toegevoegd. Gebruik voor beoordeling fictieve bestanden, zeker bij keuringsverklaringen. De lokale UI-afscherming is geen serverbeveiliging.

Migratie behoudt de bestaande enkele logboekbestanden. Nieuwe dagversies gebruiken `files[]` en `details`; het oorspronkelijke `file`-veld blijft als eerste bestandsreferentie beschikbaar voor compatibiliteit. De nieuwe sjabloonvelden zijn `scope` en `customerId`. Het SQL-ontwerp uit eerdere versies is niet toegepast op een database.
