# Versie 7 — zichtbare akkoordacties en HR-mailbevestiging

## De route voor klant en HR

1. HR uploadt de **vooraf ondertekende raamovereenkomst** bij Contracten. Er zijn afzonderlijke knoppen voor klant- en ZZP-contracten. HR registreert ondertekeningsdatum en looptijd, controleert de PDF en kan de algemene voorwaarden als aparte PDF toevoegen. Deze registratie is direct zichtbaar in het juiste externe dossier. De partijen hoeven het basiscontract niet opnieuw online te tekenen.
2. HR beoordeelt een aanvraag en verstuurt met **Offerte versturen naar klant** de verwachte inzet, werkdagen, locatie, tarieven en kosten. De offerte verwijst naar de exacte raamovereenkomst en bijbehorende voorwaarden.
3. De klant krijgt een portaalmelding en een blijvende oranje actie op het startscherm, bij de aanvraag en bij het project. **Offerte bekijken en accepteren** opent direct het offerteblad met bedragen en de akkoordknop. Een gelezen melding is niet hetzelfde als een afgeronde actie.
4. De klantbeheerder accepteert de actuele offerte conform de gekoppelde raamovereenkomst en algemene voorwaarden. De exacte offerteversie en akkoordverklaring blijven bewaard. Een gewijzigde versie vereist opnieuw akkoord. Terwijl HR een vervangende versie voorbereidt, wordt de oude gedeelde versie niet meer als te accepteren actie aangeboden.
5. Na akkoord staat er: **Akkoord ontvangen — definitieve bevestiging volgt per mail**. HR downloadt het e-mailconcept met de opdrachtbevestiging, offerte, raamovereenkomst, voorwaarden en acceptatiebewijs en verstuurt deze vanuit de eigen mailbox. HR registreert de daadwerkelijke ontvanger, datum en eventuele referentie en bevestigt expliciet de verzending. Pas dan verschijnt **Definitieve opdrachtbevestiging per mail verstuurd** met ontvanger en verzendmoment en wordt de opdracht definitief.
6. Planning kan vervolgens de ZZP-opdracht aanbieden. Ook deze professional ontvangt eigen tarieven en een eigen online akkoordactie. De eigen raamovereenkomst moet geldig zijn. Definitieve planning blijft onder de bestaande kwalificatie- en beschikbaarheidscontroles vallen; de definitieve mailbevestiging wordt ook voor de ZZP-opdracht geregistreerd.

Dit portaal verstuurt zelf geen e-mails. De status beschrijft de door HR geregistreerde handmatige verzending, niet een verzonnen provider- of afleverbericht. Eerdere demo-registraties worden niet met terugwerkende kracht als verzonden gemarkeerd.

## Bedrijfsgegevens en documentopmaak

HR kan via **Gegevens InfraNexus**, **Bedrijfsgegevens wijzigen** bij een contract of het klantdossier de onderneming, KvK, btw-nummer, adres, contactpersoon, e-mailadres en telefoonnummer beheren. Nieuwe offertes nemen deze gegevens automatisch over. Ontbrekende gegevens worden als later aan te vullen weergegeven. Bestaande geaccepteerde documenten behouden hun eigen gegevenskopie.

Het offerteblad in het portaal heeft het InfraNexus-logo, een indeling voor beide partijen, projectgegevens, werktijden, verwachte kosten en voorwaarden. De downloadbare PDF gebruikt donkerblauw en oranje, bedragen in Nederlandse notatie, pagina-opmaak en paginanummers. Het document bevat verwachte bedragen; het is geen factuur. De voorbeeld-PDF is visueel gerenderd en gecontroleerd. Er zijn geen echte juridische of bedrijfsgegevens ingevuld namens InfraNexus.

## Verlengingen

Een klant kan vanuit het project **Project verlengen** kiezen. Het bestaande project is dan al geselecteerd. Een nieuw V&G-plan is niet vereist: het bestaande document, de URL en de koppeling aan het project blijven behouden. Alleen een gewijzigde versie hoeft te worden geüpload. De aanvraag gaat opnieuw langs HR. De planner kan de dagen uit eerder geaccepteerde aanvragen én de geaccepteerde verlenging blijven gebruiken.

## Vragen en meldingen

Een vraag van HR op een aanvraag of verlenging geeft een blijvende oranje actie, ook bij het bestaande project. De klant kan de vraag openen en beantwoorden. Na beantwoording vervalt de klantactie en krijgt HR de nieuwe aanvraagreactie te zien. Offerteacties en mailacties volgen de actuele status, los van de gelezen-status van losse meldingen. Externe partijen zien alleen de eigen acties en tarieven.

## Logboekcontrole en 48 uur

- De reguliere controle begint vrijdag op de vastgelegde eindtijd van de werkdag, of om 16:00 als die tijd ontbreekt.
- Een kort project dat eerder in de werkweek eindigt, krijgt de controle op de projecteinddatum en eindtijd.
- De klant heeft vanaf het beschikbaar komen 48 werkelijke uren voor ontvangstbevestiging of opmerkingen. Als HR het dossier later deelt, start de termijn pas bij dat delen. De berekening gebruikt Europe/Amsterdam en houdt rekening met zomer- en wintertijd.
- De termijn wordt zichtbaar in de logboekenlijst en het detaildossier. Na 48 uur verschijnt een herinneringsactie; het systeem verzint geen klantakkoord.
- Na controle kan HR het projectpakket handmatig mailen en de verzending registreren. Na het verstrijken van de termijn kan HR dit pakket eveneens versturen, terwijl ontbrekende klantcontrole herkenbaar blijft.
- Het pakket bevat projectinformatie, exacte goedgekeurde logboeken, definitieve klantstukken en klanttoegankelijke projectdocumenten. Interne HR-bestanden en ZZP-inkooptarieven worden niet meegestuurd.
- Een handmatige verzendregistratie bewijst geen aflevering. De bestaande bescherming tegen gegevensverwijdering blijft gelden: zonder bevestigde aflevering en klantcontrole worden bestanden niet verwijderd.

## Verificatie en resterende productiestap

Domeintests dekken onder meer de contractregistratie door HR, juiste partij en documentversie, blijvende acties na lezen, mailregistratie vóór definitieve planning, historische versies, hergebruik van V&G bij verlenging en de 48-uursberekening inclusief wintertijd. Schermtests controleren de zichtbare knoppen, offerte-indeling, HR-uploadformulieren en meldingsteksten. TypeScript en de productiebuild worden gecontroleerd.

De toepassing blijft een demo met browseropslag en voorbeeldrollen. De sessie bevat geen ondersteunde browserbediening voor visuele browser-QA. Geauthenticeerde serverrechten en duurzame serveropslag zijn nog een aparte productiestap. De bestaande grens rond juridische beoordeling van contractteksten blijft van toepassing; deze aanpassing doet geen toezegging over juridische certificering.
