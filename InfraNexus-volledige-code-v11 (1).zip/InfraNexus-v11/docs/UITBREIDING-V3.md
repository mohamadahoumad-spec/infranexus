# InfraNexus — aanvragen, opdrachten, uren en weeklogboeken

## Wat in deze publicatie werkt

Dit is de uitbreiding op de bestaande conceptomgeving, in de huisstijl marineblauw `#163A59`, oranje `#F47A20`, lichtgrijs en wit. De bestaande klant-, project-, professional- en HR-dossiers worden hergebruikt.

| Onderdeel | Uitwerking |
|---|---|
| Aanvraag | Nieuw of bestaand project, optioneel uniek projectnummer, zes veiligheidsklassen inclusief rood vluchtig en rood niet-vluchtig, straat/huisnummer/postcode/stad, contactpersoon, meerdere werkdagen, begin- en eindtijd, pauze en verwachte uren |
| V&G | Meteen geïndexeerd bij Documenten en na acceptatie aan het project gekoppeld; de klant ziet de eigen upload, professionals pas na HR-controle en gerichte deling |
| HR-aanvraagacties | Accepteren, eigen venster voor vragen of afwijzen, gemotiveerd heropenen en corrigeren na acceptatie; historie en gerichte portaalmelding |
| Klantraamovereenkomst | Eigen PDF, looptijd, versies, ondertekend retourbestand en HR-controle; geen automatisch bedachte juridische contracttekst |
| ZZP-overeenkomst | Eigen PDF zonder vaste tarieven of gegarandeerde uren, delen, ondertekend retourbestand, eventueel providerbewijs en HR-controle |
| Opdrachtbevestiging | Afzonderlijk voor klant en ZZP, eigen tarief en tariefeenheid, werktijden, verwachte uren, toeslagen, reizen, facturatie, annulering en contractverwijzing; downloadbare PDF-snapshot |
| Acceptatie | Bevoegde klantbeheerder of eigen professional accepteert exact de aangeboden versie met verklaring, rol en tijdstip. InfraNexus bevestigt daarna definitief. Dubbele of verouderde acceptaties worden geweigerd |
| Wijziging | Nieuwe versie behoudt het vorige akkoord en vraagt een nieuw akkoord. Gewijzigde werktijden worden in de gereserveerde inzet bijgewerkt. Andere werkdagen worden via annuleren en een nieuw voorstel afgehandeld |
| Planning | Meerdaags voorstel; kwalificaties en VCA gecontroleerd per datum. Alleen ontbrekende maandopgave kan na expliciete, gemotiveerde bevestiging van persoonlijk contact worden overbrugd. Bewijzen, expliciete afwezigheid en dubbele inzet blijven blokkeren |
| HR-pipeline | Fase Gewonnen zet het bestaande kandidaatdossier meteen om naar één actief professionalaccount. Dossier en goedgekeurde bewijzen worden meegenomen. Ontbrekende bewijzen blijven nodig vóór inzet |
| Daglogboek | Professional en HR/Planning uploaden, vervangen of trekken een inzending in. Nieuwe versie gaat opnieuw naar HR. Historie blijft beschikbaar; klant kan niets verwijderen |
| Sjabloon | HR én de betrokken klant kunnen een projectsjabloon toevoegen; eerdere versies en download blijven beschikbaar |
| Weeklogboeken | HR/Planning deelt een snapshot van actuele goedgekeurde bestanden. Klant kan vanaf vrijdag ontvangst en controle bevestigen, of een opmerking plaatsen. Vervangen of ingetrokken dagbestand maakt de weekcontrole verouderd |
| Mail en bewaarbeleid | E-mailconcept met echte bijlagen downloaden, verzendwachtrij en opslagafspraak. Geen automatische mail of verwijdering zonder geverifieerde aflevering. De client biedt geen knop om een aflevering te verzinnen |
| Uren | Verwacht, werkelijk, goedgekeurd, factureerbaar en aan ZZP verschuldigd zijn aparte waarden. Zowel meer als minder uren, redenen, correctieversies, HR-beoordeling en klantcontrole |
| Financiële urenbasis | Finance legt afzonderlijke klant- en ZZP-bedragen vast op basis van beoordeelde uren en expliciete tariefafspraken. Geen automatische omrekening van een dagtarief of automatische extra vergoeding door een afwijking |
| Klantfinanciën | Alleen openstaande eigen facturen, bedrag, eerstvolgende vervaldatum, verlopen facturen en PDF; interne HR-stappen zijn uit het klantoverzicht gehaald |
| Meldingen | Eigen meldingenpagina met gerichte dossierlinks en leesstatus per account; klant en professional krijgen geen meldingen van andere externe partijen |

## Beoordelingsroute

1. Kies een klantrol en maak een aanvraag met rood als klasse, projectnummer, adres, tijden en V&G-plan. Bekijk Documenten vóór de behandeling.
2. Kies HR. Open de aanvraag. Gebruik Vraag stellen of Afwijzen; vul in het eigen venster de toelichting in. Bekijk de melding als klant. Heropen of accepteer en corrigeer de aanvraag.
3. Open het gekoppelde contractdossier. Upload uw eigen fictieve test-PDF, deel, lever als klant het ondertekende testbestand aan en controleer als HR.
4. Maak een klantopdrachtbevestiging met verkooptarief. Deel, accepteer als klantbeheerder en bevestig als Planning.
5. Voeg bij Contracten een ZZP-samenwerkingsovereenkomst voor een professional toe. Deel, lever een ondertekend testbestand aan en controleer als HR.
6. Maak via Planning een meerdaags inzetvoorstel met inkooptarief. Zonder maandopgave kan de planner het persoonlijk contact vastleggen. Laat de professional de eigen opdracht en voorwaarden accepteren. Bevestig daarna als Planning.
7. Upload een daglogboek voor een verstreken werkdag. Vervang of trek het in, dien opnieuw in en keur als HR de laatste versie goed.
8. Deel bij Weekcontrole de werkweek. Bekijk die als klant en bevestig vanaf vrijdag. Een vervanging vraagt een nieuwe weekversie.
9. Registreer als professional meer of minder uren, beoordeel als HR, vraag eventueel klantcontrole en leg als Finance de afzonderlijke financiële bedragen vast.

De basisdata zijn fictief en dateren van 6 oktober 2026. Nieuwe dagregistraties en de vrijdaggrens gebruiken de actuele datum in Europe/Amsterdam. Er worden geen fictieve contracten als echte juridische documenten gepresenteerd: alle gegenereerde voorbeeld-PDF’s zijn als demo gemarkeerd.

## Data en autorisaties

`lib/workflow-types.ts` beschrijft de nieuwe contracten, opdrachtversies, acceptaties, urenversies, weekdossiers, afleveringen, leesstatus en bewaarbeleid. Ze zijn onderdeel van hetzelfde `PortalState` als de bestaande dossiers. Migratie initialiseert lege nieuwe registers en behoudt bestaande invoer. Bestaande V&G-bijlagen worden geïndexeerd zonder een kopie per acceptatie te maken.

`lib/workflows.ts` bevat de centrale validatie, scope-selectors en statusovergangen. Klanten krijgen geen ZZP-orders, ZZP-tarieven of marges; professionals krijgen geen klantorders of klanttarieven. Klantgebruikers kunnen uren administratief bevestigen; opdrachtacceptatie is voor Klant Admin. Support en Business Development hebben geen toegang tot uren- en tariefbeheer.

IndexedDB voorkomt dat een tweede tabblad stilzwijgend de laatst opgeslagen wijzigingen overschrijft. Bij een conflict wordt opslaan geblokkeerd en om verversen gevraagd. Dit is een bescherming voor de lokale conceptomgeving, geen vervanging voor servertransacties of centrale samenwerking.

`docs/SCHEMA-V3.sql` legt het relationele ontwerp voor de volgende serverfase vast. Het wordt niet op een live database toegepast. De bestaande klant-, professional-, project-, account- en inzet-ID’s worden als verwijzingen gebruikt.

## Nog nodig voor bedrijfsgebruik

De publicatie is een **werkende frontenddemonstratie**, geen productieplatform. De rolwisselaar is geen authenticatie. De daadwerkelijke server, accounttoewijzing, API-autorisatie, centrale database, beveiligde bestandsopslag en back-ups zijn nog niet aangesloten. Ook een ondertekenprovider, uitnodigingen en e-mailbezorging vereisen nog een gekozen provider en configuratie. Geen klantmail wordt vanuit deze demonstratie verzonden.

Voor productie moeten alle acties uit `lib/workflows.ts` achter serverautorisatie draaien, met transacties, versiecontrole en idempotentiesleutels. De mailadapter mag `acknowledgeDelivery` uitsluitend na verificatie van een providerwebhook aanroepen. Die functie wordt niet door de client gebruikt. Verwijdering vereist daarnaast de passende opslagafspraak, een actuele weekversie én klantcontrole. De productieadapter moet ook oude blobs en back-ups volgens het overeengekomen beleid afhandelen; lokaal verwijderd bestandmateriaal garandeert geen fysieke vernietiging uit browseropslag of back-ups.

De uiteindelijke contractteksten en de feitelijke bevoegdheden moeten door InfraNexus worden aangeleverd. Er is nog geen koppeling met `portal.infranexusvm.nl`, een bank of boekhoudpakket.

## Verificatie

Automatische controles omvatten de bestaande domeinscenario’s, nieuwe volledige contract- en opdrachttrajecten, beschikbaarheidsuitzonderingen, logboekvervanging, verouderde weekakkoorden, bescherming tegen verwijderen vóór aflevering en de scheiding van financiële informatie. Serverrendercontroles openen alle toegestane rolpagina’s en formulieren. TypeScript en de productiebuild worden gecontroleerd.

Een interactieve browsercontrole was in deze uitvoeromgeving niet beschikbaar. De zichtbare bediening en responsieve weergave moeten daarom nog in een browser worden beoordeeld.
