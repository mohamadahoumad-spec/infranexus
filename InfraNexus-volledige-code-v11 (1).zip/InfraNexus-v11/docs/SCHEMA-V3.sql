-- Relational design for the production adapter; NOT a migration applied to the demo.
-- Existing customers, professionals, projects, users and project_assignments retain their IDs.
PRAGMA foreign_keys = ON;
CREATE TABLE contracts (
 id TEXT PRIMARY KEY, number TEXT NOT NULL UNIQUE,
 customer_id TEXT REFERENCES customers(id), professional_id TEXT REFERENCES professionals(id),
 kind TEXT NOT NULL CHECK(kind IN ('CUSTOMER_FRAMEWORK','ZZP_COOPERATION')),
 status TEXT NOT NULL, revision INTEGER NOT NULL DEFAULT 0,
 CHECK((customer_id IS NOT NULL) != (professional_id IS NOT NULL))
);
CREATE TABLE contract_versions (
 id TEXT PRIMARY KEY, contract_id TEXT NOT NULL REFERENCES contracts(id), version INTEGER NOT NULL,
 file_key TEXT NOT NULL, sha256 TEXT NOT NULL, valid_from TEXT NOT NULL, valid_until TEXT NOT NULL,
 created_by TEXT NOT NULL REFERENCES users(id), created_at TEXT NOT NULL,
 shared_at TEXT, finalized_at TEXT, UNIQUE(contract_id,version), CHECK(valid_until>=valid_from)
);
CREATE TABLE signature_requests (
 id TEXT PRIMARY KEY, contract_version_id TEXT NOT NULL REFERENCES contract_versions(id),
 provider TEXT NOT NULL, provider_request_id TEXT UNIQUE, signer_user_id TEXT REFERENCES users(id),
 signer_name TEXT NOT NULL, signer_email TEXT NOT NULL, status TEXT NOT NULL,
 final_file_key TEXT, proof_file_key TEXT, signed_at TEXT, verified_at TEXT
);
CREATE TABLE signature_events (
 provider_event_id TEXT PRIMARY KEY, request_id TEXT NOT NULL REFERENCES signature_requests(id),
 verified_at TEXT NOT NULL, event_kind TEXT NOT NULL, payload_hash TEXT NOT NULL
);
CREATE TABLE work_orders (
 id TEXT PRIMARY KEY, number TEXT NOT NULL UNIQUE, project_id TEXT NOT NULL REFERENCES projects(id),
 customer_id TEXT NOT NULL REFERENCES customers(id), professional_id TEXT REFERENCES professionals(id),
 party TEXT NOT NULL CHECK(party IN ('CUSTOMER','PROFESSIONAL')), revision INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE work_order_versions (
 id TEXT PRIMARY KEY, order_id TEXT NOT NULL REFERENCES work_orders(id), version INTEGER NOT NULL,
 contract_version_id TEXT NOT NULL REFERENCES contract_versions(id),
 terms_json TEXT NOT NULL, pdf_key TEXT NOT NULL, sha256 TEXT NOT NULL, status TEXT NOT NULL,
 created_by TEXT NOT NULL REFERENCES users(id), created_at TEXT NOT NULL, shared_at TEXT,
 confirmed_by TEXT REFERENCES users(id), confirmed_at TEXT, UNIQUE(order_id,version)
);
CREATE TABLE order_acceptances (
 id TEXT PRIMARY KEY, order_version_id TEXT NOT NULL UNIQUE REFERENCES work_order_versions(id),
 user_id TEXT NOT NULL REFERENCES users(id), party_id TEXT NOT NULL, role TEXT NOT NULL,
 declaration TEXT NOT NULL, document_hash TEXT NOT NULL, accepted_at TEXT NOT NULL,
 idempotency_key TEXT NOT NULL UNIQUE
);
CREATE TABLE rate_agreements (
 order_version_id TEXT PRIMARY KEY REFERENCES work_order_versions(id),
 currency TEXT NOT NULL DEFAULT 'EUR', unit TEXT NOT NULL CHECK(unit IN ('HOUR','DAY','PROJECT')),
 amount_cents INTEGER NOT NULL CHECK(amount_cents>=0), supplements_json TEXT NOT NULL,
 travel_json TEXT NOT NULL,
 vat_code TEXT NOT NULL CHECK(vat_code IN ('21','9','0','REVERSED','EXEMPT')), vat_note TEXT,
 supplement_cents INTEGER NOT NULL DEFAULT 0 CHECK(supplement_cents>=0),
 travel_cents INTEGER NOT NULL DEFAULT 0 CHECK(travel_cents>=0),
 expected_ex_cents INTEGER NOT NULL CHECK(expected_ex_cents>=0),
 expected_vat_cents INTEGER NOT NULL CHECK(expected_vat_cents>=0),
 expected_total_cents INTEGER NOT NULL CHECK(expected_total_cents=expected_ex_cents+expected_vat_cents)
);
CREATE TABLE expected_work_hours (
 assignment_id TEXT PRIMARY KEY REFERENCES project_assignments(id),
 order_version_id TEXT NOT NULL REFERENCES work_order_versions(id),
 work_date TEXT NOT NULL, starts_at TEXT NOT NULL, ends_at TEXT NOT NULL,
 break_minutes INTEGER NOT NULL CHECK(break_minutes>=0), expected_minutes INTEGER NOT NULL CHECK(expected_minutes>0),
 availability_confirmed_by TEXT REFERENCES users(id), availability_confirmed_at TEXT, availability_note TEXT
);
CREATE TABLE actual_work_hours (
 id TEXT PRIMARY KEY, assignment_id TEXT NOT NULL REFERENCES project_assignments(id), version INTEGER NOT NULL,
 actual_minutes INTEGER NOT NULL CHECK(actual_minutes>=0), starts_at TEXT NOT NULL, ends_at TEXT NOT NULL,
 break_minutes INTEGER NOT NULL, deviation_reason TEXT, internal_note TEXT, customer_note TEXT,
 submitted_by TEXT NOT NULL REFERENCES users(id), submitted_at TEXT NOT NULL, UNIQUE(assignment_id,version)
);
CREATE TABLE hour_reviews (
 id TEXT PRIMARY KEY, actual_id TEXT NOT NULL REFERENCES actual_work_hours(id), status TEXT NOT NULL,
 approved_minutes INTEGER CHECK(approved_minutes>=0), billable_minutes INTEGER CHECK(billable_minutes>=0),
 payable_minutes INTEGER CHECK(payable_minutes>=0), reason TEXT NOT NULL,
 actor_id TEXT NOT NULL REFERENCES users(id), reviewed_at TEXT NOT NULL
);
CREATE TABLE customer_hour_confirmations (
 id TEXT PRIMARY KEY, actual_id TEXT NOT NULL REFERENCES actual_work_hours(id), customer_id TEXT NOT NULL REFERENCES customers(id),
 action TEXT NOT NULL, note TEXT, user_id TEXT NOT NULL REFERENCES users(id), created_at TEXT NOT NULL
);
CREATE TABLE financial_entries (
 id TEXT PRIMARY KEY, review_id TEXT NOT NULL UNIQUE REFERENCES hour_reviews(id),
 customer_amount_cents INTEGER NOT NULL CHECK(customer_amount_cents>=0),
 professional_amount_cents INTEGER NOT NULL CHECK(professional_amount_cents>=0),
 rule_note TEXT NOT NULL, customer_invoice_id TEXT, supplier_invoice_id TEXT,
 actor_id TEXT NOT NULL REFERENCES users(id), created_at TEXT NOT NULL
);
CREATE TABLE daily_log_versions (
 id TEXT PRIMARY KEY, assignment_id TEXT NOT NULL REFERENCES project_assignments(id), version INTEGER NOT NULL,
 file_key TEXT, sha256 TEXT NOT NULL, template_version_id TEXT, status TEXT NOT NULL,
 created_by TEXT NOT NULL REFERENCES users(id), created_at TEXT NOT NULL,
 withdrawn_at TEXT, purged_at TEXT, UNIQUE(assignment_id,version)
);
CREATE TABLE weekly_log_versions (
 id TEXT PRIMARY KEY, project_id TEXT NOT NULL REFERENCES projects(id), iso_week TEXT NOT NULL,
 version INTEGER NOT NULL, shared_by TEXT NOT NULL REFERENCES users(id), shared_at TEXT NOT NULL,
 response TEXT, response_note TEXT, response_by TEXT REFERENCES users(id), response_at TEXT,
 UNIQUE(project_id,iso_week,version)
);
CREATE TABLE weekly_log_files (
 weekly_version_id TEXT NOT NULL REFERENCES weekly_log_versions(id),
 daily_version_id TEXT NOT NULL REFERENCES daily_log_versions(id), PRIMARY KEY(weekly_version_id,daily_version_id)
);
CREATE TABLE delivery_outbox (
 id TEXT PRIMARY KEY, weekly_version_id TEXT REFERENCES weekly_log_versions(id), recipient TEXT NOT NULL,
 status TEXT NOT NULL, idempotency_key TEXT NOT NULL UNIQUE, created_at TEXT NOT NULL,
 provider_event_id TEXT UNIQUE, delivered_at TEXT, purged_at TEXT
);
CREATE TABLE workflow_audit (
 id TEXT PRIMARY KEY, actor_id TEXT NOT NULL REFERENCES users(id), entity_type TEXT NOT NULL, entity_id TEXT NOT NULL,
 entity_version INTEGER, action TEXT NOT NULL, reason TEXT, created_at TEXT NOT NULL
);
CREATE INDEX audit_entity ON workflow_audit(entity_type,entity_id,created_at);
CREATE INDEX order_project ON work_orders(project_id,party);
CREATE INDEX pending_orders ON work_order_versions(status);
CREATE INDEX pending_delivery ON delivery_outbox(status,created_at);
CREATE TRIGGER immutable_acceptance BEFORE UPDATE ON order_acceptances BEGIN SELECT RAISE(ABORT,'acceptance is immutable'); END;
CREATE TRIGGER preserve_acceptance BEFORE DELETE ON order_acceptances BEGIN SELECT RAISE(ABORT,'acceptance history must be retained'); END;
CREATE TRIGGER immutable_audit BEFORE UPDATE ON workflow_audit BEGIN SELECT RAISE(ABORT,'audit is append-only'); END;
CREATE TRIGGER preserve_audit BEFORE DELETE ON workflow_audit BEGIN SELECT RAISE(ABORT,'audit is append-only'); END;
-- Production queries MUST scope every read by authenticated user/organization on the server.
-- Version transitions use revision compare-and-swap and a transaction; role fields in requests are never trusted.

-- v6 online base acceptance: independent of optional legacy signature-provider records.
CREATE TABLE base_contract_acceptances (
 id TEXT PRIMARY KEY, contract_version_id TEXT NOT NULL UNIQUE REFERENCES contract_versions(id),
 user_id TEXT NOT NULL REFERENCES users(id), party_id TEXT NOT NULL, authority_basis TEXT NOT NULL,
 declaration TEXT NOT NULL, document_hash TEXT NOT NULL, receipt_key TEXT NOT NULL,
 accepted_at TEXT NOT NULL, idempotency_key TEXT NOT NULL UNIQUE
);
CREATE TABLE contract_confirmation_outbox (
 id TEXT PRIMARY KEY, base_acceptance_id TEXT REFERENCES base_contract_acceptances(id),
 order_acceptance_id TEXT REFERENCES order_acceptances(id), recipient TEXT NOT NULL,
 attachments_json TEXT NOT NULL, status TEXT NOT NULL, created_at TEXT NOT NULL,
 provider_event_id TEXT UNIQUE, delivered_at TEXT, idempotency_key TEXT NOT NULL UNIQUE,
 CHECK((base_acceptance_id IS NOT NULL) != (order_acceptance_id IS NOT NULL))
);
CREATE TRIGGER immutable_base_acceptance BEFORE UPDATE ON base_contract_acceptances BEGIN SELECT RAISE(ABORT,'base acceptance is immutable'); END;
CREATE TRIGGER preserve_base_acceptance BEFORE DELETE ON base_contract_acceptances BEGIN SELECT RAISE(ABORT,'base acceptance history must be retained'); END;
-- Snapshot party details, scope, pricing, VAT and base version in the immutable published document.
-- Hash and time must come from the authenticated server, not the browser.
-- Never reprice a historical accepted version using newly introduced VAT defaults.

-- v7: HR archives a base PDF signed before the account was opened.
CREATE TABLE signed_contract_registrations (
 contract_version_id TEXT PRIMARY KEY REFERENCES contract_versions(id),
 signed_on TEXT NOT NULL, registered_by TEXT NOT NULL REFERENCES users(id), registered_at TEXT NOT NULL,
 declaration TEXT NOT NULL, terms_file_key TEXT, terms_sha256 TEXT
);
CREATE TABLE manual_mail_registrations (
 id TEXT PRIMARY KEY, order_version_id TEXT REFERENCES work_order_versions(id),
 weekly_version_id TEXT REFERENCES weekly_log_versions(id), recipient TEXT NOT NULL, sent_at TEXT NOT NULL,
 recorded_by TEXT NOT NULL REFERENCES users(id), recorded_at TEXT NOT NULL, declaration TEXT NOT NULL,
 reference_note TEXT, attachment_manifest_json TEXT NOT NULL,
 CHECK((order_version_id IS NOT NULL) != (weekly_version_id IS NOT NULL))
);
CREATE TABLE log_review_deadlines (
 weekly_version_id TEXT PRIMARY KEY REFERENCES weekly_log_versions(id), closing_reason TEXT NOT NULL,
 closing_at TEXT NOT NULL, available_at TEXT NOT NULL, due_at TEXT NOT NULL,
 timezone TEXT NOT NULL DEFAULT 'Europe/Amsterdam', CHECK(due_at>available_at)
);
-- A manual send registration is not delivery proof and must never authorize automatic file deletion.
-- Pending action badges are derived from authoritative current workflow states, not notification read flags.
