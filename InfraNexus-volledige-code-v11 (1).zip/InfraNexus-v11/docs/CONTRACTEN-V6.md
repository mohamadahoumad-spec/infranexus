# Contracten en online akkoord — versie 6

## Gebouwde werkwijze

1. HR maakt één langdurige basisovereenkomst per klant of ZZP-professional. De partijgegevens worden vooraf ingevuld waar ze beschikbaar zijn. Ontbrekende KvK-, adres- en vertegenwoordigingsgegevens worden niet verzonnen. HR kan een concept-PDF laten genereren of een eigen volledige contract-PDF toevoegen. Voor delen zijn complete gegevens en een expliciete vrijgave vereist.
2. De bevoegde klantbeheerder of de betrokken professional kan de gedeelde basisversie bekijken, downloaden en met een akkoordknop accepteren. Een nieuwe aanvraag hergebruikt hetzelfde basisdossier; er komt geen nieuw raamcontract per aanvraag.
3. Na HR-controle van een aanvraag wordt de afzonderlijke opdrachtbevestiging opgesteld. Deze bevat de projectgegevens, werkzaamheden, opgegeven veiligheidsklasse, benodigde werkdagen, verwachte start/eindtijd, pauze en uren, tarief, toeslagen, reiskosten, facturatie, annulering en de exacte basisversie.
4. Voor de klant zijn uur-, dag- en projectprijzen mogelijk. Voor ZZP zijn uur- en dagprijzen mogelijk. Het totaal exclusief btw, btw-bedrag en totaal inclusief toepasselijke btw worden in gehele centen berekend. Bij een afwijkende btw-behandeling is een toelichting vereist; het portaal bepaalt niet of een btw-regime juridisch van toepassing is.
5. Na klantacceptatie kan Planning de ZZP-inzet aanbieden voor meerdere dagen. Voor definitieve inzet zijn de eigen ZZP-acceptatie en de bestaande kwalificatie-/beschikbaarheidscontroles nodig. Alleen een ontbrekende maandbeschikbaarheid kan met de bestaande gespreksregistratie worden overbrugd.
6. Een gecorrigeerde opdracht krijgt een nieuwe versie en vereist nieuw akkoord. Oude documentversies, partij-/projectgegevens en acceptaties worden behouden. Per aanvraag wordt één klantopdrachtdossier gebruikt.

De aanvraag bevat nu ook **Zwart niet-vluchtig** en **Zwart vluchtig**. De kop heet **Benodigde werkdagen en werktijden**.

## Bewijs en bevestiging

Bij online akkoord worden naam, accountrol, partij-ID, documentnummer, documentversie, tijdstip, e-mailadres en de exacte akkoordverklaring vastgelegd. Een acceptatiebewijs is als PDF beschikbaar. De originele opdracht, gekoppelde basisvoorwaarden en bewijs worden als exacte bijlagen in een bevestigingswachtrij opgeslagen. HR kan een `.eml`-concept met bijlagen downloaden.

**Er wordt nog geen mail verstuurd.** De zichtbare status is `Wacht op mailkoppeling`; akkoordstatus en verzendstatus blijven apart. De outbox heeft één item per documentversie. De interface noemt een conceptmail nooit afgeleverd.

Eerdere gecontroleerde ondertekende PDF's blijven geldig als historische registratie binnen de demo. Ze worden niet stilzwijgend vervangen door een verzonnen online akkoord. Oude geaccepteerde opdrachten krijgen evenmin achteraf een nieuw btw-tarief.

## Juridische en technische grens

Dit blijft een functioneel prototype met voorbeeldrollen en browseropslag. Er is geen geverifieerde aanmelding, serverautorisatie, betrouwbare serverklok, onveranderlijk extern bewijsarchief of mailprovider. Het vastleggen van een rol in de browser bewijst niet de identiteit of vertegenwoordigingsbevoegdheid van de gebruiker. Gegenereerde documenten dragen de DEMO-markering en de basiscontracttekst is een concept voor juridische beoordeling. De akkoordknop is geen claim van een gekwalificeerde elektronische handtekening.

De modeltekst moet voor zakelijk gebruik worden uitgewerkt en beoordeeld voor de feitelijke onderneming, aansprakelijkheid, verzekering, betaling, opzegging, geschillen en ZZP-werkwijze. Het feit dat partijen het contract ZZP noemen, bepaalt niet zelfstandig de juridische kwalificatie van de arbeidsrelatie.

Voor productie: afgeschermde accounts per organisatie; servercontrole van bevoegdheid en exacte actuele documentversie; transacties en idempotency; vastlegging van een documenthash en serverdatum; downloadbare contracten en bijlagen vóór akkoord; een afzonderlijke mail-outbox met geverifieerde afleverberichten; bewaarbeleid en toegangscontrole voor dossiers. `SCHEMA-V3.sql` bevat hiervoor een uitgebreid relationeel ontwerp, geen uitgevoerde migratie.

Geraadpleegd op 18 oktober 2026:

- [Gerechtshof Arnhem-Leeuwarden, ECLI:NL:GHARL:2023:687, r.o. 4.18–4.20](https://uitspraken.rechtspraak.nl/details?id=ECLI:NL:GHARL:2023:687): artikel 6:227a BW (raadpleegbaarheid, authenticiteit, moment en identiteit) en de contextafhankelijke betrouwbaarheid uit artikel 3:15a BW. Deze uitspraak betreft borgtocht; zij certificeert deze portaalworkflow niet.
- [eIDAS, artikel 25, geconsolideerde tekst](https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX:02014R0910-20241018): elektronische vorm op zichzelf is geen grond om rechtsgevolgen of toelaatbaarheid als bewijs te ontzeggen; een gekwalificeerde elektronische handtekening heeft de rechtsgevolgen van een handgeschreven handtekening. Een gewone akkoordknop is daarmee niet automatisch gekwalificeerd of in iedere situatie toereikend.
- [Kamerstuk 36536, nr. 3](https://zoek.officielebekendmakingen.nl/kst-36536-3.html): toelichting op de cumulatieve vereisten van artikel 6:227a BW.

## Inhoudelijk bekijken

Kies **HR** → **Aanvragen** → **Sanering Merwehaven** → accepteer de inhoudelijke controle → **Verwachte inzet en kosten opstellen**. Bewaar het concept, open **Opdrachtbevestigingen** en deel het ter acceptatie. Wissel naar **Klantbeheerder Delta Infra**, open de melding, lees de raming en accepteer. Keer terug naar Planning om de ZZP-opdracht aan te bieden. Voor die professional moet eerst een basisovereenkomst actief zijn; die is in **Contracten** te maken en te accepteren.

De datum van de voorbeeldprojecten is oktober 2026. Kies voor nieuwe testgegevens contractlooptijden en certificaat-/beschikbaarheidsdatums die daarbij aansluiten. Gebruik uitsluitend fictieve gegevens in deze openbare conceptomgeving.

## Verificatie

Domeintests controleren prijsafronding, btw, tariefeenheden, hergebruik van de basis, exacte versie/rol/partij bij akkoord, documentkopieën, e-mailwachtrij, klantakkoord vóór ZZP-aanbod, correcties en historische migratie. Server-renderingtests dekken formulieren en rollen. TypeScript en de Sites-productiebuild worden gecontroleerd. Er is in deze sessie geen ondersteunde browser-QA beschikbaar; er is geen visuele browsertest uitgevoerd.
