# InfraNexus v10 — projectdossiers en persoonlijke uitnodigingen

## Bestaande onderdelen en behoud

V9 bevatte aanvragen, contracten, opdrachtbevestigingen, meerdaagse planning, beschikbaarheid, certificaten, dagelijks bestandsbeheer, weekcontrole, berichten en facturen. De bestaande werkruimte op `/` bewaart dossiers op het eigen apparaat in IndexedDB. Deze gegevens blijven behouden in dezelfde database en krijgen lege nieuwe verzamelingen voor overdrachten, acties, projectregels en voortgang. Oude akkoordregistraties en geaccepteerde documentversies worden niet opnieuw geschreven.

De nieuwe centrale route `/werkruimte` is afzonderlijk ingericht. Hij start leeg; voorbeeldklanten, professionals, projecten, contracten en prijzen worden nooit naar productie gekopieerd. Echte bestaande browsergegevens worden niet automatisch overgezet: eerst een gecontroleerde selectie en migratie voorbereiden, met controle op voorbeeldrecords, dossierkoppelingen, bewijsstukken en rechten. De lokale bron blijft beschikbaar. De actuele versie voegt geen achtergrondimport toe.

## Schermen

| Onderdeel | Uitbreiding |
| --- | --- |
| Projectdossier | Overzicht, planning, professionals, daglogboeken, overdrachten, acties, veiligheid, foto’s, documenten, uren, voortgang, historie en afronding |
| Logboekcontrole | Verwachte, ontbrekende, ingediende, goedgekeurde en te corrigeren registraties; tabel/tijdlijn en filters per klant, project, persoon, functie, dag/week/maand |
| Daglogboek | Projectgegevens, tijden en urenafwijking, werkzaamheden, veiligheid/milieu, foto’s, bijlagen, overdracht, concept en controle vóór indienen |
| Overdracht | Versies, bekende/onbekende ontvanger, mondelinge registratie, projectacties, bijlagen en leesbevestiging per exacte versie |
| Acties | Categorie, prioriteit, expliciete eigenaar, streefdatum, status, historie, relatie met logboek/overdracht en afzonderlijke klantpublicatie |
| Voortgang | Handmatige inhoudelijke updates en mijlpalen naast administratieve compleetheid |
| Afronding | Controle op ontbrekende rapportages, overdrachten, acties, uren en documentcontrole; bevoegde gemotiveerde uitzondering |
| Export | Selecteerbare dossierinhoud, volledige of weekrapportage als PDF, ZIP met toegestane bijlagen |
| Accounts | Inrichten, dossier/bedrijfsgegevens, rol, projectbeperking voor interne accounts, blokkeren en uitnodigingsbeheer |

De huisstijl blijft marineblauw `#163A59`, oranje `#F47A20`, wit en lichte contentvlakken. Mobiele formulieren hebben afzonderlijke secties en een camera-optie.

## Accountactivering

1. De eigenaar opent de eenmalige hoofdadmin-link en meldt zich aan. Alleen een correcte geheime setupcode kan een eerste beheerder maken. De eerste bezoeker wordt nooit automatisch beheerder. Het unieke werkruimterecord voorkomt herhaalde inrichting.
2. Beheer richt het account in met e-mailadres, vooraf bepaalde rol en klant- of professionaldossier. Interne medewerkers kunnen tot geselecteerde projecten worden beperkt. HR kan externe dossiers voorbereiden, beheer verstrekt de uitnodiging.
3. **Uitnodigen** maakt een persoonlijke link en downloadbare uitnodigingsmail. Versturen gebeurt vanuit de eigen mailbox; het systeem beweert geen mail te hebben verzonden.
4. De ontvanger meldt zich aan via de platformlogin met hetzelfde e-mailadres. De eenmalige link is zeven dagen geldig. Alleen de hash wordt centraal bewaard.
5. Een nieuwe uitnodiging trekt eerdere openstaande links in. Beheer kan een link intrekken of het account blokkeren. Bij elke volgende API- en bestandsaanvraag worden accountstatus en rechten opnieuw gecontroleerd.

De setupcode staat uitsluitend als hosted secret `INFRANEXUS_SETUP_TOKEN`. Geen codewaarde, uitnodigingstoken of platformcredential staat in Git, browserbundels of auditregels. De activeringslink hoort alleen bij de eigenaar. Na eerste inrichting kan hij geen tweede hoofdadmin claimen.

## Centrale opslag en autorisatie

- De bestaande domeinfuncties blijven de werkstromen uitvoeren. De browser verstuurt wijzigingen; de server valideert de ingelogde accountrol en voert de bijbehorende functie opnieuw uit. Een door de browser opgegeven rol, akkoordstatus of prijs vormt geen autorisatie.
- D1 bewaart één centrale werkruimte, afzonderlijke dossierrecords, lidmaatschappen, gehashte uitnodigingen, bestandsmetadata en een auditregister. R2 bewaart de uploads en gegenereerde bestanden.
- Records wijzigen binnen een D1-batch met revisiecontrole. Een verouderde sessie krijgt HTTP 409; het formulier blijft geopend. Geen stille vervanging door oude invoer.
- D1-migraties `0000` en `0001` bevatten alleen schema, indexen en auditbescherming; geen bedrijfs- of voorbeelddata. Bestaande lokale gegevens worden niet door SQL-migraties aangeraakt.
- Auditregels kunnen in de database niet worden gewijzigd of verwijderd. Projectgebeurtenissen, logboekversies, overdrachtsversies, leesregistraties en actieversies blijven via de werkstromen traceerbaar.
- Bestanden hebben uitsluitend beschermde `/api/portal/file/:id`-routes. Iedere download controleert de actuele rol, klant/projecttoegang en classificatie. Responses zijn `private, no-store`. Er zijn geen openbare R2-urls.
- HTTP POST vereist dezelfde herkomst. Uploads zijn beperkt tot de toegestane bestandstypen en 10 MB per bestand; wijzigingsberichten tot 2 MB. Losse externe bestandslinks worden geweigerd.

### Rollen

| Rol | Basisrechten |
| --- | --- |
| Hoofdadmin / Admin | Beheer en uitnodigingen binnen de bestaande rolhiërarchie; dossier- en bedrijfsbeheer |
| HR / Supervisor / Backoffice | Aanvragen, contracten, controles, bewijsstukken en externe accountinrichting |
| Planning | Inzet, projectcontinuïteit, toegang verlengen/intrekken met reden; geen ruwe medische bewijsstukken |
| Finance | Facturen en financiële afhandeling binnen de bestaande HR-vrijgavewerkstroom |
| Customer Support / Development | De bestaande toegestane pagina’s; geen nieuwe bevoegdheid om opdrachten of logboeken goed te keuren |
| Klantbeheerder | Eigen dossiers, eigen opdrachtacceptatie en expliciet vrijgegeven documenten, rapportages, acties en overdrachten |
| Klantmedewerker | Eigen klantinzage zonder vertegenwoordigingsbevoegdheid voor opdrachtacceptatie |
| Professional | Eigen opdrachten en bewijsstukken; projectdossier pas na definitieve toewijzing en binnen de toegangsperiode |

Een conceptinzet geeft geen volledig projectdossier. De opdrachtbevestiging en bijbehorende contractstukken blijven apart toegankelijk om te kunnen accepteren. Voorbereiding geeft leesrecht; actieve en beperkte afrondingsfasen geven passende schrijfrechten. Standaard is de afrondingsperiode zeven dagen, instelbaar van nul tot negentig. Intrekken en verlengen vereisen een reden. Eigen archiefregistraties kunnen na afloop beschikbaar blijven; dit heropent geen volledig projectdossier.

Klanten ontvangen geen HR-notities, medische documenten, inkoopprijzen of marges. Een nieuwe centrale daglogversie blijft na goedkeuring intern totdat HR hem expliciet publiceert of de goedgekeurde weekversie deelt. Een gewijzigde dagversie vraagt opnieuw controle. Documentrechten ondersteunen interne, professionele, klant-, gezamenlijke en specifieke gebruikersinzage. Een nieuwe documentversie bewaart de vorige; het delen van de nieuwe versie publiceert geen eerdere interne bijlage.

## Operationele regels

- Verwachtingen komen uitsluitend uit definitieve unieke project/persoon/dag-combinaties. Geannuleerde en conceptinzet tellen niet mee. Ziekte, niet-toepasselijkheid en gedeelde registratie vragen een vastgelegde uitzondering.
- Een daglogboek en zijn uren worden gezamenlijk gevalideerd. Gelijke reeds ingediende uren worden niet nogmaals ingestuurd bij een dagelijkse bestandswijziging. Gewijzigde reeds behandelde uren volgen de bestaande correctiewerkstroom.
- Wisseling, uitval, onderbreking, belangrijke acties, gewijzigde omstandigheden en een expliciete daglogmelding kunnen een overdracht voorstellen; situaties zijn per project instelbaar.
- Een leesbevestiging geldt voor één versie, sluit geen actie, draagt geen verantwoordelijkheid over en is geen veiligheidsvrijgave. Een latere definitieve opvolger krijgt een melding bij een relevante overdracht zonder bekende ontvanger.
- Acties blijven aan het project gekoppeld. Planning wijst expliciet een professional of bevoegd teamlid toe; een professional kan niet zelfstandig een actie definitief sluiten of aan iemand anders toewijzen.
- Urgente veiligheids- of milieupunten geven een interne melding en verwijzen naar de directe communicatie volgens het werkplekprotocol. Er wordt geen externe noodmelding gesimuleerd.
- Inhoudelijke projectvoortgang wordt handmatig vastgelegd en niet uit de logboekscore berekend.
- Bulkacties ondersteunen herinneren, beoordelaar toewijzen en exporteren. Goedkeuring blijft een individuele controle.
- Definitieve opdrachtmails worden handmatig verstuurd en geregistreerd. E-mailconcepten halen beschermde bestanden op voordat zij meerdere bijlagen als MIME opnemen. Alleen downloaden registreert geen verzending of aflevering.
- Bewaar- en verwijderafspraken uit de bestaande versie blijven gelden; onbevestigde mailaflevering wordt geen grond voor automatische verwijdering.

## Validatie en grenzen

De testset omvat domeinregels, behoud van bestaande workflows, serverroutes met echte SQLite-transacties en geïsoleerde objectopslag, uitnodigingen, revisieconflicten, ongeautoriseerde bestandsaanvragen, een volledige cyclus vanuit een lege centrale omgeving en server-rendering van rollen/schermen/formulieren. Export-PDF’s worden gerenderd en visueel beoordeeld; ZIP-controle verifieert inhoud en CRC.

De beheerde browserpreview was tijdens deze uitvoering niet beschikbaar: de preview-supervisor meldde een ontbrekende mailbox. Daarom is klikken in de daadwerkelijke browser en een volledige gehoste login met echte accounts nog niet afgevinkt. De eigenaar moet na publicatie de hoofdadmin activeren en de eerste echte uitnodiging controleren. De productieopslag krijgt geen testaccounts.

De functievelden zijn configureerbare registratierubrieken, geen automatische verklaring van BRL-, protocol-, medische of juridische conformiteit. InfraNexus laat de inhoud voor het toepasselijke project en de feitelijke rol beoordelen. Zie ook de bronverwijzing en afbakening in versie 9. Automatische uitgaande mail, betalingsverkeer, boekhoudintegratie, externe escalatie en achtergrondopruiming van ongekoppelde uploads zijn niet toegevoegd.
