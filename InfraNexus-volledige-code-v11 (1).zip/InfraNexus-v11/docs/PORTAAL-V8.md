# Portaal versie 8 — accountinrichting en contractdossiers

Deze versie verwerkt de twaalf aangeleverde verbeterpunten en het toevoegen van certificaten door HR. De bestaande Site en lokale dossiers blijven behouden.

## Accountinrichting

**Accounts beheren → Account inrichten** is de vaste ingang. Beheer kiest de rol, gebruiker, e-mailadres en het gekoppelde dossier. Een nieuw extern account kan meteen een klantonderneming of professionaldossier aanmaken. De bedrijfsvelden bevatten naam, KvK, btw-nummer, adres, contactpersoon, e-mail en telefoon. Dezelfde velden zijn bewerkbaar tijdens het uploaden van een ondertekende raamovereenkomst.

- HR, supervisor en backoffice richten externe accounts in; beheerders kunnen ook teamrollen inrichten.
- Alleen superbeheer kan een superbeheerrol toewijzen. Het eigen actieve account en het laatste superbeheeraccount kunnen niet worden geblokkeerd.
- Bestaande accounts houden hun rol en dossier. Een andere rol krijgt een afzonderlijk account.
- Dubbele e-mailadressen en dubbele professionalaccounts worden geweigerd. Een klantmedewerker krijgt niet impliciet een extra klantbeheeraccount.
- Een professional is vrijgegeven voor de omgeving en levert vervolgens de bewijsstukken aan. Dit verleent geen kwalificaties voor inzet.

Dit is **accountconfiguratie in de conceptomgeving**, geen echte gebruikersuitnodiging of beveiligde login. Aanmelding, serverrechten, accountverificatie en centrale opslag zijn nog niet aangesloten. De voorbeeldrolwisselaar blijft voor beoordeling beschikbaar.

## Ondertekende hoofdraamovereenkomsten

De klantpagina beschrijft het eigen ondertekende contractdossier. De klant kan een ondertekende PDF met looptijd en eventuele voorwaarden uploaden. Deze komt als **Ter controle** bij InfraNexus en vervangt de actieve overeenkomst nog niet. HR of supervisor controleert partijen, inhoud, ondertekening en looptijd en kiest **Goedkeuren & activeren** of motiveert de afwijzing. De klant ontvangt een gerichte melding. Een goedgekeurde upload wordt een nieuwe geregistreerde basisversie; eerdere versies blijven bewaard.

Een HR-upload van een reeds ondertekende klant- of ZZP-overeenkomst blijft direct door HR geregistreerd, na de expliciete controleverklaring. Er wordt daarbij geen online klantakkoord verzonnen.

## Aanvragen en terugkoppeling

De klant kan een eigen aanvraag intrekken of uit het eigen overzicht verwijderen zolang InfraNexus die niet heeft geaccepteerd. De aanvraag blijft intern als ingetrokken of verwijderd traceerbaar, inclusief bestanden en gebeurtenissen. Zij kan vervolgens niet alsnog via de normale beoordelingsactie worden geaccepteerd. Na acceptatie door InfraNexus zijn intrekken en verwijderen niet beschikbaar.

Afwijzen maakt een klantmelding met de reden en een zichtbare actie op de aanvraag. De melding is afgeschermd op klantorganisatie; leesmarkeringen worden per ingericht gebruikersaccount bijgehouden. Een afwijzingsactie verdwijnt voor die gebruiker na openen/gelezen markeren.

## Digitale opdrachtafspraak en documentvoorbeeld

HR stelt een **digitale opdrachtafspraak** op met verwachte inzet, tarieven, bedragen en btw. Het PDF-voorbeeld opent in een afzonderlijke dialoog boven het bestaande formulier. De oorspronkelijke formuliercomponent blijft gemonteerd. De knop **Terug naar het formulier**, sluiten en de browserterugactie verlaten de voorvertoning zonder het offerteformulier te vervangen.

Nieuwe PDF’s gebruiken het bestaande InfraNexus-logo, donkerblauw en oranje, gegevens van beide partijen, KvK- en btw-nummers, contactpersonen, projectlocatie, werkdagen, uren, bedragen en de concrete hoofdraamovereenkomst met versienummer. De rollen opdrachtgever en opdrachtnemer volgen het type klant- of ZZP-opdracht. De korte bevestiging verwijst naar de hoofdraamovereenkomst; de volledige akkoordverklaring staat bij de akkoordknop en in het aparte acceptatiebewijs.

**Geen automatische instemming:** alleen de bevoegde ontvanger kan door een expliciete akkoordactie de actuele gedeelde versie accepteren. De gekoppelde hoofdraamovereenkomst en eventuele voorwaarden kunnen vooraf worden ingezien en opgeslagen. De registratie bewaart gebruiker, rol, partij, tijd, versie, verklaring en de bijbehorende documentkopie. Gewijzigde afspraken krijgen een nieuwe versie met nieuw akkoord; eerder geaccepteerde kopieën blijven ongewijzigd.

## Handmatige mail en bewijsstukken

Na online akkoord staat bij de klant: **Akkoord ontvangen — definitieve bevestiging volgt per mail**. InfraNexus verstuurt de mail vanuit de eigen mailbox en registreert daarna ontvanger, werkelijke verzendtijd en bevestiging van verzending. Pas dan staat de opdracht definitief en wordt de inzet vrijgegeven. Er is geen automatische mailverzending aangesloten.

Bij opdrachtbevestigingen en logboekpakketten kunnen teams de verzonden mailtekst plakken en aanvullende PDF’s bewaren. Zij kiezen expliciet of de ontvanger deze tekst en bestanden in het dossier kan terugzien. Aanvullen achteraf bewaart het oorspronkelijke verzendmoment, de registrerende medewerker, eerdere teksten en bestanden. Een handmatige verzendregistratie is geen geverifieerd afleveringsbewijs en maakt automatische verwijdering van logboeken niet mogelijk.

## Planning en certificaten

Een ontbrekende maandopgave is uitsluitend een waarschuwing. Planning kan meerdere dagen aanbieden en definitief verwerken zonder verplichte telefonische bevestiging. De waarschuwing wordt op de inzet vastgelegd; een optionele aantekening van mondeling overleg blijft beschikbaar. Er wordt geen fictieve maandopgave voor de professional opgeslagen.

Expliciete onbeschikbaarheid, dubbele inzet, kwalificaties, contractlooptijd, aangevraagde dagen en gesloten projecten blijven gecontroleerd.

HR en supervisor kunnen via **Certificaten → Certificaat toevoegen** de juiste professional selecteren en een PDF of foto toevoegen, ook met herkomst **Per e-mail aan HR**. Het bewijs blijft **Controle nodig**, vermeldt de medewerker en wordt pas na beoordeling actief. Klantdeling blijft een afzonderlijke keuze.

## Juridisch uitgangspunt en productiegrens

De uitwerking volgt de route aanbod en expliciete aanvaarding, met een afzonderlijke opdracht onder de eerder overeengekomen hoofdraamovereenkomst. De daadwerkelijke contracttekst, vertegenwoordigingsbevoegdheid en overeengekomen vormvereisten blijven bepalend. Een akkoordknop is geen garantie op geldigheid en is geen gekwalificeerde elektronische handtekening.

Geraadpleegde primaire bronnen:

- [Rechtbank Gelderland, ECLI:NL:RBGEL:2024:1835](https://uitspraken.rechtspraak.nl/details?id=ECLI:NL:RBGEL:2024:1835): aanbod, aanvaarding, wil en gerechtvaardigd vertrouwen.
- [Gerechtshof Arnhem-Leeuwarden, ECLI:NL:GHARL:2022:3531](https://uitspraken.rechtspraak.nl/details?id=ECLI:NL:GHARL:2022:3531): het ontbreken van ondertekening sluit totstandkoming niet op zichzelf uit; de bedoelingen en afspraken zijn relevant.
- [Gerechtshof ’s-Hertogenbosch, ECLI:NL:GHSHE:2022:1024](https://uitspraken.rechtspraak.nl/details?id=ECLI:NL:GHSHE:2022:1024): elektronische beschikbaarstelling van algemene voorwaarden vóór of bij het sluiten, zodat deze kunnen worden opgeslagen en later geraadpleegd.

Vóór echt zakelijk gebruik zijn een beoordeling van de eigen contracten, geverifieerde accounts, centrale serverautorisatie en een betrouwbare registratie van versies en tijdstippen nodig. Lokale IndexedDB en een demo-rol zijn geen juridische bewijsdienst of beveiligingsgrens. Deze beperking is intern bij Accountbeheer en bij de algemene conceptinformatie zichtbaar; de klantpagina Contracten gebruikt de gevraagde zakelijke uitleg.

## Verificatie

- 76 domeintests geslaagd, waaronder klantupload met expliciete HR-vrijgave, accountrechten, intrekken, afwijzingsmeldingen, akkoord met ingericht account, volledige planning zonder maandopgave en maildossierhistorie.
- 18 rendercontroles geslaagd, inclusief supervisorpagina’s, account- en contractvelden, klantteksten, uploadwachtrij, afwijzing en mailbijlagen.
- TypeScriptcontrole en `git diff --check` geslaagd.
- Offerte en definitieve bevestiging met logo gerenderd en visueel gecontroleerd op tekst, paginering en plaatsing.
- De begeleide browserpreview was niet beschikbaar. Het behoud van offerte-invoer is structureel opgelost, maar de volledige browserterug- en klikflow is niet interactief geverifieerd. Dit blijft een expliciet acceptatiescenario.

Nieuwe records zijn `portalAccounts`, `contractSubmissions`, aanvullende mailbewijzen met revisies en een beschikbaarheidswaarschuwing op inzet. Migratie initialiseert deze zonder bestaande dossiers of akkoordregistraties te verwijderen. Het SQL-ontwerp uit eerdere versies is niet op een database toegepast.
