# Functionele en technische blauwdruk

Status: ter beoordeling. Geen productiedatabase of migraties uitgevoerd.

## De 17 gevraagde onderdelen

| Onderdeel | Waar te beoordelen |
|---|---|
| Datamodel | Beheer → Datamodel en de entiteiten hieronder |
| Rollen & rechtenmatrix | Beheer → Rollen & rechten |
| Backofficenavigatie | Linker navigatie met operationele en beheergroepen |
| Backofficedashboard | Dashboard → Command Center |
| Klant 360° | Klanten → Delta Infra |
| Project 360° | Projecten → Bodemsanering Maasvlakte |
| Professional 360° | Professionals → Daan Vermeer |
| Kandidatenpipeline | Kandidaten; kaart openen voor onboarding |
| Weekplanning | Planning; klik op een vrije plek voor nieuwe inzet |
| Professional mobiel dashboard | Voorbeeldrol → Daan Vermeer |
| Professional projectscherm | Daan → Mijn projecten → Maasvlakte |
| Daglogboek | Daan → Daglogboek maken; terug via Logboeken |
| Klantdashboard | Voorbeeldrol → Delta Infra |
| Klantprojectscherm | Delta Infra → Mijn projecten |
| Documentrechten | Documenten en Beheer → Documentrechten |
| Notificatie-logica | Beheer → Notificatieregels |
| Audit trail | Beheer → Audit trail; dossiers → Activiteit |

## Architectuurvoorstel

Een frontend met drie omgevingen, één centrale API en een relationele database. Projecten zijn de verbindende entiteit. Documentbinaries leven in private objectopslag; de database bevat metadata, versies en toegangsregels. WordPress krijgt alleen toegang tot expliciete, geauthenticeerde endpoints. De publieke website krijgt nooit databasecredentials.

De productiestack wordt bij fase 1 vastgesteld. De huidige React/TypeScript-frontend en Worker-publicatie leggen die keuze niet vast. PostgreSQL is een mogelijke relationele implementatie; bij een andere database blijven dezelfde integriteits- en transactieregels gelden.

Elke API-handler moet deze volgorde toepassen:

1. Authenticeer de sessie en controleer accountstatus, verificatie en indien nodig MFA.
2. Controleer de expliciete permissie voor de handeling (default deny).
3. Bepaal de toegestane organisaties, projecten en professionals uit serverdata.
4. Voer de databasequery uit met die scope, inclusief directe ID-requests.
5. Serialiseer alleen velden die voor die rol zijn toegestaan.
6. Schrijf de wijziging en het audit-event in dezelfde transactie.

Een verborgen tab, gefilterde frontend of moeilijk te raden ID is geen toegangscontrole. Toegang tot een project verleent nooit automatisch toegang tot tarieven, interne notities of kandidaatbeoordelingen.

## Relationeel datamodel

Alle bedrijfstabellen hebben een stabiele UUID als primaire sleutel, timestamps en relevante foreign keys. `customer_id` is de organisatiegrens; professionals zijn organisatie-overstijgend inzetbaar maar alleen zichtbaar via de toegestane projectrelatie. Business sleutels krijgen aparte unique constraints.

| Entiteit | Belangrijkste velden | Relaties / constraints |
|---|---|---|
| users | id, email, auth_subject, verified_at, active, blocked_at | Unieke genormaliseerde e-mail; geen plaintext wachtwoorden |
| roles | id, key, name, system_managed | Unieke rolkey |
| permissions | id, resource, action | Uniek resource + action |
| user_roles | user_id, role_id, granted_by, granted_at | Samengestelde PK; uitsluitend bevoegde toekenning |
| role_permissions | role_id, permission_id | Samengestelde PK |
| customer_memberships | user_id, customer_id, membership_role, active | Unieke user + customer |
| project_memberships | user_id, project_id, project_role | Extra projectbeperking voor klantgebruikers |
| sessions | id, user_id, expires_at, revoked_at, token_hash | Rotatie, intrekken, HttpOnly cookies |
| login_history | id, user_id, occurred_at, result, correlation_id | Bewaartermijn vast te stellen; geen tokens loggen |
| customers | id, legal_name, trading_name, kvk, vat, address, billing_address, status | CRM-entiteit, meerdere contacten |
| customer_contacts | id, customer_id, name, function, phone, email, user_id? | Optionele koppeling aan portaalgebruiker |
| professionals | id, user_id?, candidate_id?, name, company, kvk, region, release_status, quality_status | kandidaat_id uniek; kwaliteit uitsluitend intern |
| candidates | id, name, email, phone, region, role_preference, experience, availability, motivation, source, status, retention_review_at | Optionele CV-documentrelatie; geen dubbele actieve professional |
| onboarding_steps | id, candidate_id, step_key, status, reviewed_by, reviewed_at, evidence_id? | Expliciete menselijke vrijgave |
| qualifications | id, code, name, active | Configureerbare definitie |
| role_qualification_rules | id, role_type, qualification_id, valid_from, valid_until, approved_by | Geen ongeautoriseerde vaktechnische regels |
| certificates | id, professional_id, qualification_id, document_id, issuer, achieved_at, expires_at, verified_by, verified_at, status | Verificatie en geldigheid los van upload |
| availability | id, professional_id, date_from, date_to, status | Datuminterval geldig; conflicten signaleren |
| projects | id, number, customer_id, name, address, location, contact_id, start_date, end_date, status, description | Uniek projectnummer; start ≤ einde |
| project_assignments | id, project_id, professional_id, role, date_from, date_to, released_by, released_at | Project- en professionalbereik expliciet |
| planning | id, assignment_id, work_date, starts_at, ends_at, status, confirmed_at | Overlappende inzet detecteren; wijzigingsversie |
| work_days | id, assignment_id, work_date, administrative_status | Uniek assignment + datum |
| timesheets | id, work_day_id, actual_start, actual_end, regular_minutes, allowance_minutes, status | Eigen bron; niet automatisch overnemen uit logboek |
| logbooks | id, work_day_id, professional_id, current_version_id, workflow_status | Uniek professional + project + dag volgens nog te bevestigen beleid |
| logbook_versions | id, logbook_id, sequence, payload, submitted_by, submitted_at, supersedes_id?, reason? | Append-only; uniek logbook + sequence; volledige snapshot |
| photos | id, project_id, logbook_version_id, uploader_id, object_key, captured_at, description | Bind bewijs aan concrete versie, geen stille vervanging |
| documents | id, project_id?, customer_id?, professional_id?, type, title, current_version_id, review_status | Eén geldige eigenaar/context, standaard intern |
| document_versions | id, document_id, sequence, object_key, sha256, mime, size_bytes, uploaded_by, uploaded_at | Object immutable; hash en controles vastleggen |
| document_permissions | id, document_id, audience, grantee_id?, approved_by, approved_at | Audience plus organisatie-/projectbereik |
| notifications | id, event_type, recipient_id, entity_type, entity_id, read_at | Ontvangerrechten ook bij openen toetsen |
| notification_deliveries | id, notification_id, channel, status, attempts, last_error_code, idempotency_key | Unieke idempotency key; geen e-mailinhoud in fouten |
| jobs | id, role, region, description, start, duration, hours, requirements, publication_status | Publicatie alleen na bevoegde actie |
| applications | id, candidate_id, job_id?, source, submitted_at | Kandidateninstroom via gecontroleerde interface |
| requests | id, customer_id?, project_id?, request_type, role, location, start_date, duration, urgent, description, status | Intake kan voorafgaan aan klant/project |
| quotes | id, request_id, customer_id, project_id?, version, status, validity, conditions | Versies bewaren; voorwaarden nog vast te stellen |
| rates | id, project_id?, customer_id?, professional_id?, rate_type, currency, unit, amount, valid_from, valid_to | Alleen finance/admin; bedragen exact als decimal/minor units |
| costs | id, project_id, work_day_id?, category, amount, currency, status | Alleen financiële scope |
| invoice_status | id, project_id, period, status, external_reference, updated_by | Geen volledige boekhouding dupliceren |
| academy_courses | id, code, name, description, active | MKB niet actief tonen |
| academy_sessions | id, course_id, dates, location, capacity, instructor_id, status | Capaciteit in transactie bewaken |
| academy_participants | id, session_id, candidate_id?, professional_id?, enrollment_status | Een deelnemeridentiteit; geen automatische vrijgave |
| academy_progress | id, participant_id, component, status, assessed_by, assessed_at, evidence_id? | Externe onderdelen expliciet |
| audit_logs | id, actor_id, action, entity_type, entity_id, before, after, occurred_at, correlation_id | Append-only; secrets en onnodige PII uitsluiten |
| retention_policies | id, entity_type, basis, retention_period, approved_by, effective_from | Geen termijnen verzinnen; verwijderprocedure en holds |

Indexeer foreign keys, projectnummer, organisatie + status, professional + inzetdatum, certificaatvervaldatum, notificatieontvanger + leesstatus, en audit entity + timestamp. Productie vereist transacties, optimistic locking en integriteit bij gelijktijdige planning. De prototypecheck vóór opslaan is hiervoor niet voldoende.

## Rechtenmatrix — voorstel

B = beheren, L = lezen, E = eigen, O = eigen organisatie en toegestane projecten.

| Rol | Operationeel | Instroom | Financieel | Academy | Beheer |
|---|---|---|---|---|---|
| Super Admin | B | B | B | B | Volledig |
| Admin | B | B | B | B | Beperkt, geen ongeautoriseerde privilege-escalatie |
| Planning | Projecten, professionals, planning | — | — | — | — |
| Backoffice | Dossiers en logboekcontrole | B | — | — | — |
| Financieel | Relevante projectgegevens L | — | B | — | — |
| Academy beheer | — | Alleen noodzakelijke deelnemersgegevens | — | B | — |
| Professional | E planning/projecten/documenten; E logboeken | — | — | E | E profiel |
| Klant admin | O L; aanvragen | — | — | — | Eigen portaalgebruikers, nader te besluiten |
| Klant gebruiker | O + projecttoewijzing L | — | — | — | — |

Beschikbare rollen moeten configureerbaar worden. Financiële velden, kwaliteitsstatus, kandidaatnotities en interne opmerkingen zijn aparte permissies en worden niet naar externe portalen geserialiseerd.

## Werkstromen

### Planning

Planner kiest project, datum en professional. Controles geven beschikbaarheid, andere inzet, vrijgave en geldigheid op de inzetdatum weer. Een menselijke planner maakt de keuze. In het prototype gelden conservatieve voorbeeldcontroles; exacte kwalificatieregels zijn nog niet geautoriseerd. V&G-inzet wordt daarom niet automatisch als passend bestempeld. Er is geen override zonder vastgesteld beleid.

Weekbevestiging registreert dat een professional de planning heeft gezien. De definitie van beschikbaarheid, zelfstandigheid en bevestiging moet operationeel worden vastgesteld. Nacht-/over-middernachtinzet is nog niet ingericht; de demo accepteert alleen eindtijd na starttijd op dezelfde dag.

### Logboeken

Concept → Ingediend → Controle nodig / Goedgekeurd → Definitief. Een bevoegde reviewer kan een correctie vragen met reden. De professional vult vervolgens aan en dient een nieuwe versie in. Oude snapshots bewaren tekst, werktijden en foto’s. Een klant ziet alleen goedgekeurde of definitieve versies in het eigen projectbereik.

De demo bewaart volledige snapshots in de browser. Productie moet versies op de server append-only opslaan, gekoppelde bestanden immutable bewaren en gelijktijdige updates afvangen. Een ontbrekend logboek markeert administratieve onvolledigheid en blokkeert geen betaling.

### Kandidaten

Nieuw → Te beoordelen → Contact opnemen → Screening → Documentencontrole → Onboarding → Praktijkcheck → Voorwaardelijk vrijgegeven → Vrijgegeven. Niet passend is een afzonderlijke eindstatus. Een vrijgave is een expliciete beslissing. Omzetting is slechts eenmaal toegestaan en houdt de herkomst bij; kwalificatiebewijzen moeten gecontroleerd gekoppeld worden. Een afgeronde opleiding veroorzaakt nooit automatisch vrijgave.

### Documenten

Upload → Alleen backoffice + Controle nodig → Controle afgerond → Expliciete deling. De vier audiences zijn Backoffice, Professional, Klant en Beide. Deze zijn altijd aanvullend op het project-/organisatiescope. Nieuwe uploads zijn niet vanzelf openbaar. Production uploadflow: type/inhoud/omvang verifiëren, malwarecontrole, willekeurige objectnaam, private opslag, gecontroleerde download en versiebeheer.

De demo accepteert PDF, JPG, PNG en WebP tot 2 MB per document. Logboekfoto’s zijn beperkt tot vier afbeeldingen van 750 kB. Dit zijn prototypegrenzen, geen definitieve productafspraken.

## API-contracten voor fase 1–4

Dit is een ontwerplijst; deze routes zijn nog niet geïmplementeerd.

| Methode / pad | Gedrag | Beveiliging |
|---|---|---|
| GET /api/me | Huidige identiteit, toegewezen rollen en scope | Geldige sessie |
| GET /api/projects | Alleen toegestane projecten | Rol + organisatie + projectlidmaatschap |
| POST /api/projects | Nieuw project en audit-event | projects.create, geldige klant |
| GET /api/projects/:id | Geserialiseerd projectdossier | Directe objectautorisatie, veldfilter |
| POST /api/assignments | Inzet in transactie, conflictcontrole | planning.create + menselijke keuze |
| POST /api/planning/confirm | Eigen weekbevestiging | Professional-id uit sessie |
| POST /api/logbooks | Eigen concept aan toegewezen inzet | Professional + planningcontrole |
| POST /api/logbooks/:id/submit | Nieuwe onveranderbare ingediende versie | Eigen logboek + workflowcontrole |
| POST /api/logbooks/:id/review | Goedkeuring/correctieverzoek met audit | logbooks.review; versiecontrole |
| POST /api/documents/uploads | Tijdelijke uploadmachtiging | Documentcontext en typepolicy |
| PATCH /api/documents/:id/permissions | Expliciet delen, audit en notificatie | documents.share + scope |
| GET /api/documents/:id/download | Korte downloadmachtiging | Opnieuw autoriseren op huidige rechten |
| POST /api/requests | Klantaanvraag | Klant-id uit sessie, eigen project |
| POST /api/candidates/:id/convert | Idempotente omzetting | Kandidatenbeheer + menselijke vrijgave |
| POST /api/public/intake | Website-instroom | Beveiligde interface, validatie, anti-abuse |

Pagination, rate limiting, CSRF-bescherming bij cookies, validatie, tijdzonebeleid en uniforme foutcodes zijn onderdeel van fase 1. Onbevoegde objecten mogen geen bevestiging van hun bestaan lekken.

## Notificaties en audit

Certificaatwaarschuwingen op 90/60/30/7 dagen; planningwijzigingen naar betrokken professionals; documentmeldingen uitsluitend naar actuele ontvangers; goedgekeurde logboeken alleen naar de juiste klant. Gebruik een transactionele outbox en unieke idempotency keys. Meldingen mogen geen gevoelige inhoud kopiëren naar onveilige kanalen. Escalatiemomenten, e-mailsjablonen en bezorgkanalen worden eerst vastgesteld.

De audit registreert actor, handeling, object, tijdstip, oude waarde en nieuwe waarde. In productie is dit append-only, met gecontroleerde leesrechten en een vastgesteld bewaarbeleid. Geen wachtwoorden, tokens of volledige onnodige persoonsgegevens in de audit.

## Privacy, bestanden en herstel

Minimaliseer opgeslagen kandidaat- en professionalgegevens. Stel retentie per soort gegeven en grondslag vast; geen willekeurige termijnen. Verwijder-/exportverzoeken omvatten database, objecten, afgeleide exports en back-upbeleid. Beperk bestandsdownloadtijd en registreer waar nodig gevoelige toegang. Scheid development, staging en productie. Back-up van database en objectmetadata moet op een geïsoleerde omgeving worden hersteld en getest voordat operationele gegevens worden toegelaten.

## Open besluiten

Officieel logo; definitieve rollenmatrix; kwalificatievereisten; functiespecifieke logboekvelden; documentdeling; retentie en privacyprocedures; betaalvoorwaarden; tarieven; Academy-certificering; overrides; escalaties; nachtwerk; kalenderweergaven dag/maand/project; publicatie- en integratiecontracten.

Eerst deze blauwdruk beoordelen. Daarna fase 1 implementeren en de serverbeveiligingscriteria aantoonbaar testen vóór gebruik met echte gegevens.
