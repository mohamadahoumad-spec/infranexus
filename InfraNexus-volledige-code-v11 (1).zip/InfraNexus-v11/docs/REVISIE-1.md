# Eerste gezamenlijke revisie — InfraNexus Veiligheid & Milieu

Deze revisie breidt het frontendprototype uit. Waar het eerdere ontwerp financiële functies of documentuploads als later werk beschrijft, is dit document leidend voor de huidige demonstratie.

## Werkstromen

| Onderdeel | Nieuwe werking |
|---|---|
| Kandidaat | Telefoon, bedrijfsnaam, KvK en optioneel privé-CV. V&G is verwijderd als functie. |
| Vrijgave | HR rondt de onboarding af en zet de kandidaat eenmaal om. Contact-, bedrijfs-, CV- en goedgekeurde bewijsgegevens gaan mee. |
| Planning | Eén professional en project, meerdere losse dagen in één keer. Alle dagen worden vooraf gecontroleerd; bij één conflict wordt niets toegevoegd. |
| Maandopgave | Professional kiest per maand alle beschikbare dagen en bevestigt de hele maand. Niet gekozen dagen zijn niet beschikbaar. Een niet-ingediende maand blokkeert nieuwe inzet. Toekomstige maanden kunnen vooruit worden opgegeven. |
| Certificaten | PDF/foto voor VCA, DLP, R-DLP, KVP, MVK, HVK, BHV of overig. Zowel HR als professional levert aan; beoordeling blijft een aparte menselijke stap. |
| Klantinzage bewijs | Alleen goedgekeurde en expliciet gedeelde bewijsbestanden van professionals met inzet op eigen projecten. CV en HR-documenten blijven apart. |
| Nieuwe klus | Nieuwe projectnaam, opgegeven veiligheidsklasse, losse datums, locatie, tijden en optioneel V&G-plan. Aanvraag verschijnt bij HR/Planning. Acceptatie maakt een project en houdt het V&G-plan eerst ter controle. |
| V&G-plan | Een klantdienst, geen kandidaatfunctie of personeelsinzet. Projectdocumenten worden na controle gericht gedeeld. |
| Logboekbestand | HR uploadt een leeg klantsjabloon. Professional downloadt, vult buiten het portaal in en dient voor de eigen ingeplande dag een bestand in. HR keurt goed of vraagt correctie. Alleen goedgekeurde versies verschijnen bij de juiste klant. |
| Centrale chat | Klant → InfraNexus; professional → InfraNexus; intern → geselecteerde collega. Afdelingen HR, Planning, Customer Support en Finance. Prioriteitsmarkering is geen automatische noodoproep. |
| Zzp-factuur | Professional kiest werkweek en eigen projecten met inzet en uploadt de factuur-PDF. HR controleert. Finance kan daarna de betalingsverwerking en betalingsreferentie vastleggen. |
| Klantfactuur | Finance kiest klant, werkweek en projecten met inzet, registreert het bedrag en voegt de definitieve PDF toe. Concept blijft intern; expliciet delen maakt de factuur zichtbaar in het eigen klantportaal. |
| Branding | Aangeleverde logo’s, marineblauw/oranje, eigen logo uploadbaar en klantlogo naast InfraNexus in het klantportaal. |

De veiligheidsklassen zijn de door InfraNexus aangeleverde keuzen: Basishygiëne, Oranje vluchtig, Oranje niet-vluchtig en Zwart CM-stoffen. Dit is projectinformatie die een mens beoordeelt; geen automatische veiligheidstechnische classificatie.

## Afdelingen

- Admin beheert alle demonstratiestappen.
- HR/Backoffice beheert kandidaten, privébestanden, bewijscontrole, logboekcontrole en zzp-factuurcontrole.
- Planning verwerkt aanvragen en plant inzet; maandindiening, vrijgave, projectperiode, dubbele inzet en geldige functiegebonden bewijzen worden getoetst.
- Finance maakt/deelt klantfacturen en verwerkt zzp-facturen na HR-akkoord.
- Customer Support heeft de centrale communicatie en klant-/projectoverzichten.
- Business Development kan klantleads aanmaken. Bodemdesk valt buiten deze revisie.

Deze rollen zijn schermvoorbeelden. De rolwisselaar is geen login of beveiligingsgrens.

## Aanbevolen beoordelingsroute

1. Kies rechtsboven **Delta Infra**. Maak een nieuwe klus met meerdere datums en een fictief V&G-bestand.
2. Kies **Planner** of **HR-team**. Open Aanvragen, accepteer de aanvraag en open het nieuwe project.
3. Voeg onder Kandidaten een kandidaat toe met telefoon, bedrijf, KvK en een fictief CV. Voeg een DLP-bewijs toe, controleer het en rond de onboarding en vrijgave af.
4. Zet de kandidaat om naar professional. Kies deze nieuwe professional in de rolwisselaar. Geef via **Maandbeschikbaarheid** de maand van het project door.
5. Kies Planning, plan dezelfde professional op meerdere dagen en controleer de eigen planning van de professional. Een conflict op één gekozen dag moet de volledige batch blokkeren.
6. Upload als HR op het project onder Logboeken een leeg klantlogboek. Dien als professional een ingevuld bestand in voor een geplande dag. Controleer als HR en bekijk het resultaat als klant.
7. Upload een certificaat als professional. Bekijk de HR-wachtlijst bij Professionals. Keur het bewijs goed en zet expliciete klantdeling aan. Bekijk het op het klantproject onder Professionals.
8. Start als klant een gesprek met Planning. Antwoord als Planner. Controleer dat de professional dat klantgesprek niet ziet, en wel een eigen gesprek kan starten.
9. Dien als Daan Vermeer een fictieve zzp-factuur in voor week 41 van 2026, project Maasvlakte. Controleer als HR, zet als Finance in betaling en registreer een referentie. Zonder HR-akkoord blijft betalen geblokkeerd.
10. Maak als Finance een klantfactuur met een fictieve PDF en deel deze. Delta Infra ziet alleen de eigen klantfactuur; de zzp-factuur blijft daarvan gescheiden.
11. Upload bij Huisstijl & logo’s een klantlogo en open het betreffende klantportaal.

## Grenzen van de demonstratie

Alle gegevens en berichten blijven in dezelfde browser. Er is geen echte verzending, bankbetaling, boekhoudkoppeling of centrale opslag. Bestanden zijn beperkt tot 2 MB per upload om de lokale opslag te beperken. Logboekfoto’s tot 12 MB worden lokaal verkleind. Het opslagquotum van de browser blijft gelden; bij overschrijding toont het portaal een foutmelding en blijft de wijziging alleen in de huidige sessie aanwezig.

Bestaande demo-opslag migreert zonder het hele dossier te resetten. De oorspronkelijke voorbeeldprofessionals hebben voor oktober 2026 een als voorbeeld gemarkeerde maandopgave. Nieuwe professionals hebben geen ingevulde maand totdat zij die zelf indienen. Een oude V&G-functie wordt als ‘Functie afstemmen’ gemarkeerd; oude V&G-projecten worden naar de V&G-plandienst omgezet.

Voor gebruik met echte mensen en bedrijfsgegevens zijn serverauthenticatie, autorisatie per dossier, private bestandsopslag, gelijktijdigheidscontroles en centrale transacties nodig. De bestaande productiegates in ACCEPTATIE.md blijven van toepassing.
