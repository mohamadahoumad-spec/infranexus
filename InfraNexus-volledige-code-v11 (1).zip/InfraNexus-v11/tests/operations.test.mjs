import test from 'node:test';
import assert from 'node:assert/strict';
import {seed,accounts,checklistItems,planningIssues,missingLogs} from '../lib/demo.ts';
import {hydrateDemoState,reviewCertificate,acknowledgeWeek} from '../lib/professional.ts';
import {monthDates,submitMonth,scheduleMany,createRequest,acceptRequest,convertCandidate,staffFilesFor,uploadCertificate,customerCertificates,publishTemplate,submitFilledLog,reviewFilledLog,visibleFilledLogs,openConversation,sendChat,visibleConversations,createInvoice,reviewInvoice,financeTransition,reviseInvoice,visibleInvoices} from '../lib/operations.ts';
const admin=accounts[0],planner=accounts[2],finance=accounts[4],pro=accounts[6],customer=accounts[8],other=accounts[9],hr=accounts[10];
const file={name:'voorbeeld.pdf',url:'data:application/pdf;base64,JVBERg==',mime:'application/pdf',size:4};
const stamp='2026-10-06T12:00:00Z';
test('existing user data survives extension migration; V&G becomes a service',()=>{
 const s=seed();s.projects[0].name='Eigen wijziging';s.projects[1].role='V&G';delete s.monthlyAvailability;delete s.branding;const next=hydrateDemoState(s);
 assert.equal(next.projects[0].name,'Eigen wijziging');assert.equal(next.projects[1].role,'Geen personeelsinzet');assert.equal(next.projects[1].service,'V&G-plan');assert.ok(next.monthlyAvailability.length);assert.equal(next.branding[0].logo,'/brand/infranexus-primary.png');
});
test('monthly availability is complete, explicit, own scoped, and protects existing assignments',()=>{
 const s=seed();assert.throws(()=>submitMonth(s,customer,'2026-11',[]),/professional/);assert.throws(()=>submitMonth(s,pro,'2026-10',[]),/ingepland/);assert.throws(()=>submitMonth(s,pro,'2026-13',[]),/geldige/);
 const next=submitMonth(s,pro,'2026-11',['2026-11-02','2026-11-03']);const m=next.monthlyAvailability.find(m=>m.month==='2026-11');assert.equal(Object.keys(m.days).length,30);assert.equal(m.days['2026-11-03'],'Beschikbaar');assert.equal(m.days['2026-11-04'],'Niet beschikbaar');assert.equal(s.monthlyAvailability.some(m=>m.month==='2026-11'),false);
});
test('multi-day planning succeeds atomically and rejects entire batch when one date fails',()=>{
 let s=seed();s.assignments=s.assignments.filter(a=>a.professionalId!=='pro3');const count=s.assignments.length;const next=scheduleMany(s,planner,'p3','pro3',['2026-10-07','2026-10-09','2026-10-09'],'07:00','16:00');assert.equal(next.assignments.length,count+2);assert.equal(next.notifications[0].professionalId,'pro3');assert.equal(s.assignments.length,count);
 assert.throws(()=>scheduleMany(next,planner,'p3','pro3',['2026-10-09','2026-10-12'],'07:00','16:00'),/al ingepland/);assert.equal(next.assignments.length,count+2);
 const noMonth={...s,monthlyAvailability:s.monthlyAvailability.filter(m=>m.professionalId!=='pro3')};assert.throws(()=>scheduleMany(noMonth,planner,'p3','pro3',['2026-10-07'],'07:00','16:00'),/Maandbeschikbaarheid/);
 assert.throws(()=>scheduleMany(s,customer,'p3','pro3',['2026-10-07'],'07:00','16:00'),/HR en Planning/);
});
test('customer request creates an independent project, dates and controlled V&G attachment',()=>{
 const s=seed(),data={customerId:'c1',projectName:'Nieuw saneringsproject',dates:['2026-10-09','2026-10-07'],safetyClass:'Oranje niet-vluchtig',service:'Personeelsinzet',role:'DLP',location:'Nieuwe locatie',description:'Nieuwe werkzaamheden',hours:'07:00–16:00',urgent:false,vgPlan:file};
 assert.throws(()=>createRequest(s,other,data),/Klant/);const requested=createRequest(s,customer,data),r=requested.requests[0];assert.equal(r.projectId,'');assert.deepEqual(r.dates,['2026-10-07','2026-10-09']);assert.equal(requested.notifications[0].target,'aanvragen');
 assert.throws(()=>acceptRequest(requested,customer,r.id),/HR/);const accepted=acceptRequest(requested,hr,r.id),p=accepted.projects[0];assert.equal(p.name,data.projectName);assert.equal(p.customerId,customer.customerId);assert.equal(p.end,'2026-10-09');assert.equal(accepted.documents[0].audience,'Backoffice');assert.equal(accepted.documents[0].status,'Controle nodig');assert.throws(()=>acceptRequest(accepted,planner,r.id),/verwerkt/);
});
test('candidate conversion retains phone, company, KvK, CV and approved certificates without duplicate accounts',()=>{
 const s=seed(),id='candidate-test';s.candidates.push({id,name:'Test Persoon',city:'Breda',role:'DLP',email:'test@example.invalid',phone:'0612345678',company:'Testbedrijf',kvk:'12345678',vatNumber:'NL123456789B01',status:'Vrijgegeven',experience:'5 jaar',date:'2026-10-06',checklist:[...checklistItems]});s.staffFiles.push({id:'private',ownerType:'candidate',ownerId:id,kind:'CV',file,uploadedAt:stamp});
 const uploaded=uploadCertificate(s,hr,{candidateId:id},{type:'DLP',issuer:'Voorbeeld uitgever',achieved:'2026-01-01',expiry:'2028-01-01',file});const reviewed=reviewCertificate(uploaded,hr,uploaded.certificateSubmissions[0].id,true,'Bewijs gecontroleerd');const converted=convertCandidate(reviewed,hr,id),p=converted.professionals[0];assert.equal(p.phone,'0612345678');assert.equal(p.company,'Testbedrijf');assert.equal(p.kvk,'12345678');assert.equal(p.vatNumber,'NL123456789B01');assert.equal(p.certificates[0].type,'DLP');assert.equal(converted.staffFiles[0].ownerId,p.id);assert.equal(staffFilesFor(converted,customer,p.id).length,0);assert.equal(staffFilesFor(converted,hr,p.id).length,1);assert.throws(()=>convertCandidate(converted,hr,id),/vrijgave/);assert.ok(planningIssues(converted,p.id,'p1','2026-10-07').some(i=>i.includes('Maand')));
});
test('self uploaded certificates need HR and explicit customer sharing; old evidence is superseded',()=>{
 const s=seed();const uploaded=uploadCertificate(s,pro,{professionalId:pro.professionalId},{type:'DLP',issuer:'Opleider',achieved:'2026-01-01',expiry:'2028-01-01',file});const id=uploaded.certificateSubmissions[0].id;assert.equal(uploaded.certificateSubmissions[0].status,'Controle nodig');assert.equal(customerCertificates(uploaded,customer,'p1').length,0);assert.throws(()=>reviewCertificate(uploaded,pro,id,true,'Zelf'),/backoffice/);
 const reviewed=reviewCertificate(uploaded,hr,id,true,'HR heeft bewijs gecontroleerd');assert.equal(customerCertificates(reviewed,customer,'p1').length,0);reviewed.certificateSubmissions[0].sharedWithCustomer=true;assert.equal(customerCertificates(reviewed,customer,'p1').length,1);assert.equal(customerCertificates(reviewed,other,'p1').length,0);const p=reviewed.professionals.find(p=>p.id==='pro1');assert.equal(p.certificates.filter(c=>c.type==='DLP'&&!c.supersededAt).length,1);
});
test('file log workflow isolates client scopes and preserves corrections and template versions',()=>{
 let s=publishTemplate(seed(),hr,'p1',file);const template=s.logTemplates[0];s=submitFilledLog(s,pro,template.id,'2026-10-05',file);const id=s.filledLogs[0].id;assert.equal(visibleFilledLogs(s,customer).length,0);assert.throws(()=>submitFilledLog(s,pro,template.id,'2026-10-05',file),/al ingediend/);assert.throws(()=>submitFilledLog(s,pro,template.id,'2026-11-30',file),/ingeplande/);
 s=reviewFilledLog(s,hr,id,false,'Ontbrekende handtekening');assert.equal(s.filledLogs[0].versions[0].note,'Ontbrekende handtekening');s=submitFilledLog(s,pro,template.id,'2026-10-05',{...file,name:'correctie.pdf'});s=reviewFilledLog(s,hr,id,true,'In orde');assert.equal(s.filledLogs[0].versions.length,2);assert.equal(s.filledLogs[0].versions[0].status,'Correctie gevraagd');assert.equal(visibleFilledLogs(s,customer)[0].versions.length,1);assert.equal(visibleFilledLogs(s,other).length,0);
 s=publishTemplate(s,hr,'p1',{...file,name:'nieuw-sjabloon.pdf'});assert.equal(s.logTemplates[0].version,2);assert.equal(s.filledLogs[0].versions[1].templateVersion,1);
});
test('central conversations prevent client-professional contact and isolate tenants',()=>{
 let s=openConversation(seed(),customer,{title:'Planning volgende week',department:'Planning',urgent:true},'Kan de start om 08:00?',{kind:'professional',id:'pro1'});const id=s.conversations[0].id;assert.equal(s.conversations[0].kind,'customer');assert.equal(s.conversations[0].customerId,'c1');assert.equal(visibleConversations(s,pro).length,0);assert.equal(visibleConversations(s,other).length,0);assert.throws(()=>sendChat(s,pro,id,'Onbevoegd'),/omgeving/);s=sendChat(s,planner,id,'We stemmen dit voor je af.');assert.equal(s.chatMessages.at(-1).side,'internal');assert.equal(visibleConversations(s,customer).length,1);
 s=openConversation(s,planner,{title:'Interne overdracht',department:'HR',urgent:false},'Graag dossiercontrole.',{kind:'internal',id:hr.name});assert.equal(visibleConversations(s,hr).length,2);assert.equal(visibleConversations(s,finance).length,1);assert.equal(visibleConversations(s,customer).length,1);
});
function supplier(s=seed()){return createInvoice(s,pro,{kind:'supplier',number:'ZZP-26-001',projectIds:['p1'],week:'2026-W41',issued:'2026-10-06',due:'2026-11-05',description:'DLP inzet',amountCents:125000},file);}
test('supplier invoice requires HR approval before Finance and scopes to own projects',()=>{
 const initial=supplier(),id=initial.invoices[0].id;assert.equal(visibleInvoices(initial,customer).length,0);assert.equal(visibleInvoices(initial,hr).length,1);assert.throws(()=>financeTransition(initial,finance,id,'In betaling'),/HR/);assert.throws(()=>reviewInvoice(initial,finance,id,true,''),/HR/);assert.throws(()=>financeTransition(initial,pro,id,'Betaald','123'),/Finance/);
 let s=reviewInvoice(initial,hr,id,true,'Uren en project gecontroleerd');s=financeTransition(s,finance,id,'In betaling');assert.throws(()=>financeTransition(s,finance,id,'Betaald',''),/referentie/);s=financeTransition(s,finance,id,'Betaald','BANK-DEMO-001');assert.equal(s.invoices[0].status,'Betaald');assert.equal(s.invoices[0].paymentReference,'BANK-DEMO-001');assert.ok(s.invoices[0].hrAt);
 assert.throws(()=>createInvoice(seed(),pro,{kind:'supplier',number:'Fout',projectIds:['p3'],week:'2026-W41',issued:'2026-10-06',due:'2026-11-05',description:'Onjuist',amountCents:100},file),/projecten/);
});
test('supplier correction appends a version and must go through HR again',()=>{
 let s=supplier(),id=s.invoices[0].id;s=reviewInvoice(s,hr,id,false,'Corrigeer het bedrag');s=reviseInvoice(s,pro,id,{...file,name:'herzien.pdf'},100000);assert.equal(s.invoices[0].status,'Ingediend');assert.equal(s.invoices[0].versions.length,2);assert.equal(s.invoices[0].versions[0].amountCents,125000);assert.equal(s.invoices[0].hrBy,undefined);assert.throws(()=>financeTransition(s,finance,id,'In betaling'),/HR/);
});
test('customer invoices are private drafts until Finance shares the PDF',()=>{
 let s=createInvoice(seed(),finance,{kind:'customer',customerId:'c1',number:'INX-2026-100',projectIds:['p1'],week:'2026-W41',issued:'2026-10-06',due:'2026-11-05',description:'Weekinzet',amountCents:200000},file);const id=s.invoices[0].id;assert.equal(visibleInvoices(s,customer).length,0);s=financeTransition(s,finance,id,'Gedeeld');assert.equal(visibleInvoices(s,customer).length,1);assert.equal(visibleInvoices(s,other).length,0);assert.equal(visibleInvoices(s,pro).length,0);assert.equal(visibleInvoices(s,hr).length,0);
});
test('acknowledging a week never upgrades tentative assignments',()=>{
 const s=seed();s.assignments[0].status='Voorlopig';const owner={...pro,professionalId:s.assignments[0].professionalId};const next=acknowledgeWeek(s,owner,[s.assignments[0].date]);assert.equal(next.assignments[0].status,'Voorlopig');assert.ok(next.assignments[0].acknowledgedAt);
});
