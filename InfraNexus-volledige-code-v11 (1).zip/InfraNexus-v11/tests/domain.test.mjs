import test from 'node:test';
import assert from 'node:assert/strict';
import {seed,accounts,visibleProjects,visibleAssignments,visibleDocs,visibleLogs,canFinance,planningIssues,certStatus,missingLogs,logSnapshot,weekDates} from '../lib/demo.ts';
const state=seed();
const admin=accounts[0], professional=accounts[6], customerA=accounts[8], customerB=accounts[9];
test('customer A and B have disjoint project scopes in the demo',()=>{
 const a=visibleProjects(state,customerA),b=visibleProjects(state,customerB);
 assert.ok(a.length&&b.length);assert.ok(a.every(p=>p.customerId==='c1'));
 assert.ok(!a.some(p=>b.some(other=>other.id===p.id)));
 assert.ok(visibleAssignments(state,customerA).every(x=>a.some(p=>p.id===x.projectId)));
});
test('professional scope follows their assignment and does not include colleagues projects',()=>{
 assert.deepEqual(visibleProjects(state,professional).map(p=>p.id),['p1']);
 assert.ok(visibleAssignments(state,professional).every(x=>x.professionalId==='pro1'));
 assert.ok(visibleLogs(state,professional).every(x=>x.professionalId==='pro1'));
});
test('documents require project scope, explicit audience and review',()=>{
 assert.deepEqual(visibleDocs(state,customerA).map(d=>d.id),['d1']);
 assert.deepEqual(visibleDocs(state,professional).map(d=>d.id),['d1','d2']);
 assert.ok(visibleDocs(state,admin).some(d=>d.id==='d3'));
 const unreviewed={...state,documents:state.documents.map(d=>({...d,status:'Controle nodig'}))};
 assert.equal(visibleDocs(unreviewed,customerA).length,0);
});
test('customer logs only include approved and definitive content',()=>{
 assert.equal(visibleLogs(state,customerA).length,0);
 assert.deepEqual(visibleLogs(state,customerB).map(l=>l.id),['l2']);
});
test('finance capability is absent for planners, professionals and customers',()=>{
 assert.ok(canFinance(admin));assert.ok(canFinance(accounts[4]));
 for(const a of [accounts[2],professional,customerA,customerB])assert.equal(canFinance(a),false);
});
test('planning rejects conflicting, unavailable, expired and unqualified assignments',()=>{
 assert.ok(planningIssues(state,'pro1','p1','2026-10-06').some(x=>x.includes('al ingepland')));
 assert.ok(planningIssues(state,'pro5','p2','2026-10-06').some(x=>x.includes('niet beschikbaar')));
 assert.ok(planningIssues(state,'pro2','p3','2026-10-07').some(x=>x.includes('KVP')));
 const expired={...state,professionals:state.professionals.map(p=>p.id==='pro3'?{...p,certificates:p.certificates.map(c=>({...c,expiry:'2026-10-01'}))}:p)};
 assert.ok(planningIssues(expired,'pro3','p3','2026-10-07').some(x=>x.includes('geldig')));
 assert.deepEqual(planningIssues(state,'pro3','p3','2026-10-07'),[]);
});
test('V&G service cannot become staff planning and project bounds are enforced',()=>{
 assert.ok(planningIssues(state,'pro6','p6','2026-10-20').some(x=>x.includes('geen personeelsinzet')));
 assert.ok(planningIssues(state,'pro3','p3','2026-10-01').some(x=>x.includes('projectperiode')));
});
test('certificate expiry includes expiry day and warning window',()=>{
 const cert={id:'test',type:'DLP',expiry:'2026-10-06',verified:true};
 assert.equal(certStatus(cert,'2026-10-06'),'Verloopt binnenkort');
 assert.equal(certStatus(cert,'2026-10-07'),'Verlopen');
 assert.equal(certStatus({...cert,verified:false}),'Controle nodig');
});
test('missing log report does not treat drafts as submitted',()=>{
 assert.deepEqual(missingLogs(state).map(x=>x.professionalId),['pro4']);
 const drafts={...state,logbooks:state.logbooks.map(l=>({...l,status:'Concept'}))};
 assert.equal(missingLogs(drafts).length,3);
});
test('full log versions preserve hours, text and photos independently of corrections',()=>{
 const log={...state.logbooks[0],photos:[{name:'foto.jpg',url:'data:image/jpeg;base64,AA',caption:'Voor correctie'}]};
 const v1=logSnapshot(log,'Definitief',1,'Admin','2026-10-06T10:00:00Z');
 const corrected={...log,start:'08:00',work:'Gecorrigeerde werkzaamheden',photos:log.photos.map(p=>({...p,caption:'Na correctie'}))};
 const v2=logSnapshot(corrected,'Ingediend',2,'Daan','2026-10-06T11:00:00Z');
 assert.equal(v1.start,'07:00');assert.equal(v1.work,state.logbooks[0].work);assert.equal(v1.photos[0].caption,'Voor correctie');
 assert.equal(v2.start,'08:00');assert.equal(v2.photos[0].caption,'Na correctie');assert.notEqual(v1.photos[0],v2.photos[0]);
});
test('week navigation handles month boundaries',()=>{
 assert.deepEqual(weekDates(0),['2026-10-05','2026-10-06','2026-10-07','2026-10-08','2026-10-09']);
 assert.equal(weekDates(4)[0],'2026-11-02');
});
