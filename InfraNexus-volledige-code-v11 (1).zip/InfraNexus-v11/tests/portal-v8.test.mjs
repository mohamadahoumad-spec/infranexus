import test from 'node:test';
import assert from 'node:assert/strict';
import {accounts} from '../lib/demo.ts';
import {portalSeed,hydratePortal,reviewRequest,demoPdf} from '../lib/portal.ts';
import {assignableRoles,provisionAccount,changeAccountStatus,demoPortalAccounts,ensurePortalAccounts} from '../lib/account-setup.ts';
import {submitCustomerContract,reviewCustomerContract,registerSignedBase} from '../lib/contracts.ts';
import {requiredActions} from '../lib/project-actions.ts';
import {uploadCertificate,customerCertificates,reviewFilledLog} from '../lib/operations.ts';
import {reviewCertificate} from '../lib/professional.ts';
import * as w from '../lib/workflows.ts';

const admin=accounts[0],hr=accounts[10],planner=accounts[2],customer=accounts[8],other=accounts[9],pro=accounts[7];
const supervisor={role:'SUPERVISOR',name:'Supervisor Test',initials:'ST'};
const company={name:'Testbedrijf BV',kvk:'12345678',vatNumber:'NL123456789B01',address:'Teststraat 1, 1234 AB Rotterdam',contact:'Klant Test',email:'bedrijf@example.test',phone:'0100000000'};
const file=demoPdf('Fictief getekend testdocument',['Uitsluitend voor tests.']);
const upload={file,termsFile:file,from:'2026-01-01',until:'2029-12-31',signedOn:'2026-01-01'};
function ready(){let s=reviewRequest(portalSeed(),hr,'rq-new','accept','Gecontroleerd');return registerSignedBase(s,hr,'professional','pro2',file,'2026-01-01','2029-12-31','2026-01-01',true);}
function terms(s,party='customer'){const p=s.projects[0],g=party==='customer'?s.agreements.find(g=>g.customerId===p.customerId):s.cooperations[0];return {requestId:'rq-new',projectId:p.id,party,customerId:p.customerId,professionalId:party==='professional'?'pro2':undefined,dates:['2026-10-12','2026-10-13'],start:'07:00',end:'16:00',breakMinutes:60,expectedHoursPerDay:8,rateCents:party==='customer'?12500:6800,unit:'uur',vat:'21',supplements:'Geen',travel:'Geen',billing:'Wekelijks volgens de opdracht',cancellation:'Volgens de hoofdraamovereenkomst',notes:'Test',agreementId:g.id,agreementVersion:g.versions.at(-1).version,assignmentIds:[]};}
function shared(){let s=ready();s=w.createOrder(s,hr,terms(s));return w.shareOrder(s,hr,s.orders[0].id);}
function accepted(){let s=shared();return w.respondOrder(s,customer,s.orders[0].id,1,'accept','',true);}
function mailed(s){return w.completeOrderByMail(s,hr,s.orders[0].id,1,'projecten@example.test',new Date().toISOString(),true,'Handmatig verstuurd in test');}

test('HR and supervisor set up linked accounts with KvK and VAT; duplicate email and unauthorized internal roles are rejected',()=>{
 let s=provisionAccount(portalSeed(),supervisor,{role:'KLANT ADMIN',name:'Klant Test',email:'gebruiker@example.test',company,city:'Rotterdam'});
 const account=s.portalAccounts[0],c=s.customers.find(c=>c.id===account.customerId);
 assert.equal(account.userId,account.id);assert.equal(c.kvk,company.kvk);assert.equal(c.vatNumber,company.vatNumber);assert.equal(c.contact,company.contact);
 assert.throws(()=>provisionAccount(s,hr,{role:'KLANT GEBRUIKER',name:'Dubbel',email:'GEBRUIKER@example.test',customerId:c.id}),/bestaat al/);
 assert.throws(()=>provisionAccount(s,supervisor,{role:'ADMIN',name:'Beheer',email:'beheer@example.test'}),/accountrol/);
 assert.throws(()=>provisionAccount(s,customer,{role:'PROFESSIONAL',name:'Onbevoegd',email:'nee@example.test'}),/Alleen/);
 s=provisionAccount(s,hr,{id:account.id,role:account.role,name:'Nieuwe naam',email:account.email,customerId:c.id,company:{...company,vatNumber:'NL987654321B01'}});
 assert.equal(s.customers.find(x=>x.id===c.id).vatNumber,'NL987654321B01');
 assert.throws(()=>provisionAccount(s,hr,{id:account.id,role:account.role,name:account.name,email:account.email,customerId:'c1'}),/zelfde dossier/);
});

test('account administration preserves the last superadmin and does not silently grant extra customer administrators',()=>{
 let s=portalSeed();assert.ok(s.portalAccounts.some(a=>a.role==='SUPER ADMIN'));assert.ok(!assignableRoles(accounts[1]).includes('SUPER ADMIN'));
 s=provisionAccount(s,admin,{role:'SUPERVISOR',name:'Toezicht',email:'toezicht@example.test'});const supervisorId=s.portalAccounts[0].id;
 s=changeAccountStatus(s,admin,supervisorId,'Geblokkeerd');assert.ok(!demoPortalAccounts(s).some(a=>a.userId===supervisorId));
 assert.throws(()=>changeAccountStatus(s,admin,'account-SUPER ADMIN','Geblokkeerd'),/eigen|laatste/);
 s=provisionAccount(s,hr,{role:'KLANT GEBRUIKER',name:'Klantmedewerker',email:'medewerker@example.test',company});const id=s.portalAccounts[0].customerId;
 s=ensurePortalAccounts(s);assert.equal(s.portalAccounts.filter(a=>a.customerId===id).length,1);assert.equal(s.portalAccounts.find(a=>a.customerId===id).role,'KLANT GEBRUIKER');
 s=provisionAccount(s,hr,{role:'PROFESSIONAL',name:'ZZP Test',email:'zzp@example.test',company:{...company,email:'zzp@example.test'}});const p=s.professionals.find(p=>p.id===s.portalAccounts[0].professionalId);
 assert.equal(p.status,'Vrijgegeven');assert.deepEqual(p.certificates,[]);assert.throws(()=>provisionAccount(s,hr,{role:'PROFESSIONAL',name:p.name,email:'extra@example.test',professionalId:p.id}),/al een account/);
});

test('migration retains existing dossiers and bootstraps account configuration without creating acceptance records',()=>{
 const previous=portalSeed();previous.projects[0].name='Bestaande wijziging';delete previous.portalAccounts;delete previous.contractSubmissions;
 const s=hydratePortal(previous);assert.equal(s.projects[0].name,'Bestaande wijziging');assert.ok(s.portalAccounts.some(a=>a.professionalId==='pro2'));assert.deepEqual(s.contractSubmissions,[]);assert.equal(s.agreements[0].versions[0].acceptance,undefined);
});

test('customer-supplied agreement remains pending without changing the active framework until HR approves it',()=>{
 let s=portalSeed(),before=s.agreements.find(g=>g.customerId==='c1'),count=before.versions.length;
 s=submitCustomerContract(s,customer,upload);const id=s.contractSubmissions[0].id;
 assert.equal(s.contractSubmissions[0].status,'Ter controle');assert.equal(s.agreements.find(g=>g.id===before.id).versions.length,count);
 assert.ok(requiredActions(s,hr).some(a=>a.id===id));assert.ok(!requiredActions(s,other).some(a=>a.id===id));
 assert.throws(()=>reviewCustomerContract(s,customer,id,true,true,''),/beoordeling/);assert.throws(()=>reviewCustomerContract(s,hr,id,true,false,''),/Controleer/);
 s=reviewCustomerContract(s,supervisor,id,true,true,'Partijen en ondertekening gecontroleerd');const approved=s.contractSubmissions[0],version=s.agreements.find(g=>g.id===approved.agreementId).versions.at(-1);
 assert.equal(approved.status,'Goedgekeurd');assert.equal(version.version,count+1);assert.ok(version.registered);assert.equal(version.acceptance,undefined);
 assert.throws(()=>reviewCustomerContract(s,hr,id,true,true,''),/beoordeling/);
 let rejected=submitCustomerContract(s,customer,upload);rejected=reviewCustomerContract(rejected,hr,rejected.contractSubmissions[0].id,false,false,'Verkeerde contractpartij');
 assert.equal(rejected.agreements.find(g=>g.id===before.id).versions.length,count+1);assert.ok(w.visibleNotifications(rejected,customer).some(n=>n.title==='Contractupload afgewezen'));
 assert.throws(()=>submitCustomerContract(s,pro,upload),/Alleen de klant/);assert.throws(()=>submitCustomerContract(s,customer,{...upload,file:{...file,size:11*1024*1024}}),/10 MB/);
});

test('own requests can be withdrawn or removed before HR acceptance and cannot be processed afterward',()=>{
 const original=portalSeed();assert.throws(()=>w.withdrawCustomerRequest(original,other,'rq-new',false,''),/eigen aanvraag/);
 let s=w.withdrawCustomerRequest(original,customer,'rq-new',false,'Andere uitvoeringsdatum');assert.equal(s.requests[0].status,'Ingetrokken');assert.ok(s.requestEvents.some(e=>e.kind==='Aanvraag ingetrokken door klant'));
 assert.throws(()=>reviewRequest(s,hr,'rq-new','accept',''),/afgehandeld/);
 s=w.withdrawCustomerRequest(s,customer,'rq-new',true,'Verwijderen uit mijn overzicht');assert.ok(s.requests[0].deletedAt);assert.equal(s.requests[0].status,'Verwijderd');assert.equal(s.requests[0].vgPlan.url,original.requests[0].vgPlan.url);
 const accepted=reviewRequest(original,hr,'rq-new','accept','');assert.throws(()=>w.withdrawCustomerRequest(accepted,customer,'rq-new',true,''),/Na acceptatie/);
});

test('rejection remains a visible, correctly scoped customer action until that user reads it',()=>{
 let s=reviewRequest(portalSeed(),hr,'rq-new','reject','Geen capaciteit op deze dagen');const n=w.visibleNotifications(s,customer).find(n=>n.title==='Aanvraag afgewezen');
 const user={...customer,userId:'first-contact'},second={...customer,userId:'second-contact'};
 assert.ok(n);assert.match(n.body,/Geen capaciteit/);assert.ok(requiredActions(s,user).some(a=>a.kind==='notice'&&a.requestId==='rq-new'));assert.ok(!requiredActions(s,other).some(a=>a.requestId==='rq-new'));
 s=w.markNotification(s,user,n.id);assert.ok(!requiredActions(s,user).some(a=>a.key==='notice-'+n.id));assert.ok(requiredActions(s,second).some(a=>a.key==='notice-'+n.id));
});

test('account-based order acceptance retains the customer party ID, exact version and linked main framework without auto consent',()=>{
 let s=shared(),id=s.orders[0].id;const account={...customer,userId:'custom-customer-user'};
 assert.equal(s.orders[0].versions[0].acceptance,undefined);assert.throws(()=>w.respondOrder(s,account,id,1,'accept','',false),/voorwaarden/);
 s=w.respondOrder(s,account,id,1,'accept','',true);const v=s.orders[0].versions[0],mail=s.contractMails[0];
 assert.equal(v.acceptance.partyId,'c1');assert.equal(v.acceptance.actorId,account.userId);assert.equal(mail.partyId,'c1');assert.equal(v.acceptance.version,1);
 const pdf=Buffer.from(v.file.url.split(',')[1],'base64').toString('latin1');assert.match(pdf,/\/Im1 Do/);assert.match(pdf,/Hoofdraamovereenkomst:/);assert.match(pdf,/RAAM-2026-001/);
 assert.equal(v.status,'Geaccepteerd');assert.equal(mail.status,'Te versturen door HR');
});

test('missing monthly availability never blocks the complete professional offer and finalization flow',()=>{
 let s=mailed(accepted());s.monthlyAvailability=s.monthlyAvailability.filter(m=>m.professionalId!=='pro2');const before=JSON.stringify(s.monthlyAvailability);
 s=w.offerWork(s,planner,terms(s,'professional'));const id=s.orders[0].id,assignments=s.assignments.filter(x=>x.orderId===id);
 assert.equal(assignments.length,2);assert.ok(assignments.every(x=>x.availabilityWarning&&!x.availabilityConfirmation));assert.equal(JSON.stringify(s.monthlyAvailability),before);
 s=w.respondOrder(s,{...pro,userId:'zzp-user'},id,1,'accept','',true);s=w.completeOrderByMail(s,hr,id,1,'zzp@example.test',new Date().toISOString(),true,'Test');
 assert.ok(s.assignments.filter(x=>x.orderId===id).every(x=>x.status==='Bevestigd'));assert.equal(JSON.stringify(s.monthlyAvailability),before);
});

test('HR can attach an emailed certificate to a professional, with review and customer sharing kept explicit',()=>{
 let s=portalSeed();const original=s.professionals.find(p=>p.id==='pro1').certificates;
 s=uploadCertificate(s,supervisor,{professionalId:'pro1'},{source:'Per e-mail aan HR',type:'VCA-VOL',issuer:'Fictieve opleider',achieved:'2026-01-01',expiry:'2031-01-01',file});const c=s.certificateSubmissions[0];
 assert.equal(c.status,'Controle nodig');assert.equal(c.source,'Per e-mail aan HR');assert.equal(c.submittedBy,supervisor.name);assert.equal(c.sharedWithCustomer,false);assert.deepEqual(s.professionals.find(p=>p.id==='pro1').certificates,original);
 assert.ok(!customerCertificates(s,customer,'p1').some(x=>x.id===c.id));s=reviewCertificate(s,hr,c.id,true,'Origineel gecontroleerd');assert.ok(s.professionals.find(p=>p.id==='pro1').certificates.some(x=>x.submissionId===c.id));
 assert.ok(!customerCertificates(s,customer,'p1').some(x=>x.id===c.id));assert.throws(()=>uploadCertificate(s,other,{professionalId:'pro1'},{type:'VCA',issuer:'Nee',achieved:'',expiry:'2031-01-01',file}),/toegang/);
});

test('manual mail text and PDFs can be preserved and amended without changing original sending or acceptance evidence',()=>{
 let s=accepted(),id=s.orders[0].id,acceptedFile=s.orders[0].versions[0].file.url;
 const first=demoPdf('Bijlage voor de mail',['Test 1']),second=demoPdf('Aanvullende PDF',['Test 2']);
 s=w.completeOrderByMail(s,hr,id,1,'projecten@example.test',new Date().toISOString(),true,'Eerste verzending',{body:'Beste klant, hierbij de bevestiging.',attachments:[first],visibleToRecipient:true});const original=s.contractMails[0].manual;
 assert.equal(original.body,'Beste klant, hierbij de bevestiging.');assert.equal(original.attachments.length,1);
 assert.throws(()=>w.appendManualMailEvidence(s,customer,'opdracht',id,1,{body:'Onbevoegd'}),/Alleen/);
 s=w.appendManualMailEvidence(s,planner,'opdracht',id,1,{body:'Aanvullende mailtekst',attachments:[first,second],visibleToRecipient:false});const manual=s.contractMails[0].manual;
 assert.equal(manual.sentAt,original.sentAt);assert.equal(manual.by,original.by);assert.equal(manual.to,original.to);assert.equal(manual.attachments.length,2);assert.equal(manual.revisions[0].body,original.body);assert.equal(s.orders[0].versions[0].file.url,acceptedFile);
 assert.throws(()=>w.appendManualMailEvidence(s,hr,'opdracht',id,1,{attachments:[{...second,mime:'text/html'}]}),/PDF/);
});

test('weekly project mail retains pasted text and supplementary PDFs while manual registration never enables automatic purge',()=>{
 let s=portalSeed();s.projects=s.projects.map(p=>p.id==='p1'?{...p,start:'2026-09-28',end:'2026-10-02',endTime:'16:00'}:p);s.assignments.push({id:'v8-log-day',projectId:'p1',professionalId:'pro2',date:'2026-10-02',role:'DLP',start:'07:00',end:'16:00',status:'Bevestigd'});
 s=w.saveDayLog(s,pro,'p1','pro2','2026-10-02',file);s=reviewFilledLog(s,hr,s.filledLogs[0].id,true,'Compleet');s=w.shareWeek(s,hr,'p1','2026-W40');const id=s.weeklyLogs[0].id;s=w.respondWeek(s,customer,id,true,'Ontvangen');
 s=w.markProjectMailSent(s,hr,id,'projecten@example.test',new Date().toISOString(),true,'Test',{body:'Hierbij het projectdossier',attachments:[file],visibleToRecipient:true});
 const original=s.deliveries[0].manual;s=w.appendManualMailEvidence(s,planner,'log',id,0,{body:'Aanvulling op projectdossier'});
 assert.equal(s.deliveries[0].manual.sentAt,original.sentAt);assert.equal(s.deliveries[0].manual.revisions[0].body,original.body);assert.throws(()=>w.purgeDeliveredWeek(s,hr,s.deliveries[0].id),/mailaflevering/);
});
