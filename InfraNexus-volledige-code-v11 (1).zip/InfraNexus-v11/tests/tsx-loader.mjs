import ts from 'typescript';
import {readFile,stat} from 'node:fs/promises';
import {fileURLToPath,pathToFileURL} from 'node:url';
import path from 'node:path';
const root=path.resolve(fileURLToPath(new URL('..',import.meta.url)));
export async function resolve(specifier,context,next){
 if(specifier.startsWith('@/')||((specifier.startsWith('./')||specifier.startsWith('../'))&&context.parentURL?.startsWith(pathToFileURL(root).href)&&!context.parentURL.includes('/node_modules/'))){
  const stem=specifier.startsWith('@/')?path.join(root,specifier.slice(2)):fileURLToPath(new URL(specifier,context.parentURL));
  for(const ext of ['', '.ts','.tsx','.mjs','.js']){try{if((await stat(stem+ext)).isFile())return {url:pathToFileURL(stem+ext).href,shortCircuit:true};}catch{}}
 }
 return next(specifier,context);
}
export async function load(url,context,next){if(/\.tsx?$/.test(url)&&!url.includes('/node_modules/')){const source=await readFile(fileURLToPath(url),'utf8');return {format:'module',source:ts.transpileModule(source,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext,jsx:ts.JsxEmit.ReactJSX,esModuleInterop:true},fileName:fileURLToPath(url)}).outputText,shortCircuit:true};}return next(url,context);}
