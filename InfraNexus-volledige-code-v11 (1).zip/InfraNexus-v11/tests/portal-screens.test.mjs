import test from 'node:test';
import assert from 'node:assert/strict';
import React from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {accounts} from '../lib/demo.ts';
import {portalSeed,allowedPages} from '../lib/portal.ts';
import {PortalContext} from '../components/portal/context.tsx';
import {PortalApp} from '../components/portal/app.tsx';
import {HomeOverview,RequestWorkspace,AgreementWorkspace,ProjectWorkspace} from '../components/portal/overview.tsx';
import {PlanningWorkspace,LogbookWorkspace,DocumentWorkspace,AvailabilityWorkspace} from '../components/portal/work.tsx';
import {PeopleWorkspace,CandidateWorkspace,CertificateWorkspace} from '../components/portal/people.tsx';
import {MessageWorkspace} from '../components/portal/messages.tsx';
import {CustomerWorkspace,FinanceWorkspace,ProfileWorkspace,SettingsWorkspace} from '../components/portal/administration.tsx';
import {ContractsWorkspace,OrdersWorkspace,HoursWorkspace,NotificationWorkspace} from '../components/portal/workflow-pages.tsx';
import {AccountsWorkspace} from '../components/portal/accounts.tsx';
import {PortalFormContent} from '../components/portal/forms.tsx';
const components={accounts:AccountsWorkspace,orders:OrdersWorkspace,hours:HoursWorkspace,notifications:NotificationWorkspace,customers:CustomerWorkspace,home:HomeOverview,requests:RequestWorkspace,agreements:ContractsWorkspace,projects:ProjectWorkspace,planning:PlanningWorkspace,logs:LogbookWorkspace,documents:DocumentWorkspace,availability:AvailabilityWorkspace,people:PeopleWorkspace,candidates:CandidateWorkspace,checks:CertificateWorkspace,chat:MessageWorkspace,finance:FinanceWorkspace,profile:ProfileWorkspace,settings:SettingsWorkspace};
const noop=()=>{};
function render(Component,{account=accounts[0],page='home',record=null,modal=null,state=portalSeed()}={}){return renderToStaticMarkup(React.createElement(PortalContext.Provider,{value:{state,account,page,record,modal,go:noop,setModal:noop,run:()=>true}},React.createElement(Component)));}
test('new workspace shell renders its navigation, role selector and concept label',()=>{const html=renderToStaticMarkup(React.createElement(PortalApp));assert.match(html,/portal-sidebar/);assert.match(html,/Contracten/);assert.match(html,/Berichtencentrum/);assert.match(html,/Conceptomgeving/);assert.match(html,/primary-logo-v2/);assert.match(html,/mark-v2/);});
test('each allowed page renders for Admin, Supervisor, Planning, HR, Finance, Support, customer and professional',()=>{for(const account of [accounts[0],{role:'SUPERVISOR',name:'Toezicht',initials:'TZ'},accounts[2],accounts[10],accounts[4],accounts[11],accounts[8],accounts[6],accounts[12]])for(const page of allowedPages(account)){const html=render(components[page],{account,page});assert.ok(html.length>150,`${account.role}: ${page}`);assert.ok(!html.includes('href="tel:'),`${account.role}: ${page}`);}});
test('new project, contract, request, log and certificate detail pages render with real scoped data',()=>{for(const [page,record] of [['projects','p1'],['agreements','agc1'],['requests','rq-new'],['logs','digital:l1'],['checks','evidence-vca'],['candidates','k1'],['people','pro1'],['documents','d1']]){assert.ok(render(components[page],{page,record}).length>300,page);}assert.ok(render(components.projects,{account:accounts[8],page:'projects',record:'p1'}).length>300);assert.match(render(components.projects,{account:accounts[9],page:'projects',record:'p1'}),/niet beschikbaar/);});
test('private HR files, customer contracts and central messages respect external roles in rendered pages',()=>{const state=portalSeed();state.staffFiles.push({id:'secret',ownerType:'professional',ownerId:'pro1',kind:'CV',file:{name:'GEHEIM-CV.pdf',url:'data:application/pdf;base64,AA',mime:'application/pdf',size:1},uploadedAt:'2026-10-06'});const customer=render(ProjectWorkspace,{state,account:accounts[8],page:'projects',record:'p1'});assert.ok(!customer.includes('GEHEIM-CV'));assert.ok(!customer.includes('daan@voorbeeld'));assert.ok(!render(AgreementWorkspace,{state,account:accounts[6],page:'agreements'}).includes('RAAM-2026'));assert.ok(!render(MessageWorkspace,{state,account:accounts[6],page:'chat'}).includes('start voor morgen'));assert.ok(render(MessageWorkspace,{state,account:accounts[8],page:'chat'}).includes('start voor morgen'));});
test('candidate, request, contract, certificate and planner forms have their required fields',()=>{for(const kind of ['candidate','request','plan','agreement-new','agreement-upload','agreement-sign','certificate','template','filled-log','invoice','professional']){const html=render(PortalFormContent,{modal:{kind,id:kind==='filled-log'?'tpl0':'agc1',projectId:'p1',professionalId:kind==='professional'?'pro1':undefined}});assert.ok(html.length>100,kind);if(kind==='candidate'){assert.match(html,/Telefoonnummer/);assert.match(html,/KvK-nummer/);assert.match(html,/CV toevoegen/);}if(kind==='request')assert.match(html,/Projectnaam/);if(kind==='plan')assert.match(html,/dagen geselecteerd/);}});

test('new workflow forms render all stages without hidden missing fields or unavailable components',()=>{
 const state=portalSeed();
 for(const kind of ['request-edit','request-question','request-reject','request-reopen','order','cooperation','day-log','log-withdraw','hours-entry','template']){
  const account=['hours-entry'].includes(kind)?accounts[7]:accounts[10];
  const html=render(PortalFormContent,{state,account,modal:{kind,id:kind.startsWith('request')?'rq-new':undefined,projectId:'p1',professionalId:'pro2'}});
  assert.ok(html.length>200,kind);
  if(kind==='request-edit')for(const label of ['Vanaf','Tot','Postcode','Huisnummer','Projectnummer','Reden van correctie'])assert.ok(html.includes(label),label);
  if(kind==='request-question')assert.match(html,/Je vraag aan de klant/);
  if(kind==='cooperation')assert.match(html,/Tarieven|tarieven/);
 }
});

test('order details show the recipient’s exact accepted terms and never the other party’s price',async()=>{
 const w=await import('../lib/workflows.ts');
 const {reviewRequest,demoPdf}=await import('../lib/portal.ts');
 const file=demoPdf('Fictief testbestand',['Geen juridisch contract.']);
 let state=reviewRequest(portalSeed(),accounts[10],'rq-new','accept','Beoordeeld');
 const project=state.projects[0],agreement=state.agreements.find(g=>g.projectIds.includes(project.id));
 const terms={projectId:project.id,party:'customer',customerId:project.customerId,dates:['2026-10-12'],start:'07:00',end:'16:00',breakMinutes:60,expectedHoursPerDay:8,rateCents:13337,unit:'uur',supplements:'Geen',travel:'Volgens afspraak',billing:'Wekelijks',cancellation:'Volgens contract',notes:'Test',agreementId:agreement.id,agreementVersion:1,assignmentIds:[]};
 state=w.createOrder(state,accounts[10],terms);const customerId=state.orders[0].id;state=w.shareOrder(state,accounts[10],customerId);
 state=w.uploadCooperation(state,accounts[10],'pro2',file,'2026-01-01','2026-12-31',true);const cooperation=state.cooperations[0].id;state=w.shareCooperation(state,accounts[10],cooperation);state=w.returnCooperation(state,accounts[7],cooperation,file);state=w.verifyCooperation(state,accounts[10],cooperation,true,'Fictieve test');
 state=w.respondOrder(state,accounts[8],customerId,1,'accept','',true);state=w.completeOrderByMail(state,accounts[2],customerId,1,'klant@example.test',new Date().toISOString(),true,'Testregistratie');state=w.offerWork(state,accounts[2],{...terms,party:'professional',professionalId:'pro2',rateCents:7123,agreementId:cooperation});const professionalId=state.orders[0].id;
 const customer=render(OrdersWorkspace,{state,account:accounts[8],record:customerId,page:'orders'}),professional=render(OrdersWorkspace,{state,account:accounts[7],record:professionalId,page:'orders'});
 assert.match(customer,/133,37/);assert.ok(!customer.includes('71,23'));assert.ok(!customer.includes('Brutomarge'));
 assert.match(professional,/71,23/);assert.ok(!professional.includes('133,37'));assert.match(professional,/Ik accepteer de opdracht/);assert.match(professional,/raamovereenkomst en algemene voorwaarden/);
 assert.match(render(ContractsWorkspace,{state,account:accounts[7],record:cooperation,page:'agreements'}),/opdrachtbevestiging per opdracht/);
});

test('online base contract shows one acceptance button to the authorized customer, with no repeated PDF signing step',async()=>{
 const c=await import('../lib/contracts.ts');
 let state=portalSeed();const party={name:'Fictieve contractpartij',kvk:'12345678',address:'Teststraat 1',contact:'Test',email:'test@example.test'};
 state=c.createBaseContract(state,accounts[10],'customer','c1','2026-01-01','2029-12-31',{issuer:party,recipient:party,clauses:'Fictieve voorwaarden voor de test',source:'Gegenereerd concept'});const id=state.agreements[0].id,version=state.agreements[0].versions.at(-1).version;
 state=c.shareBaseContract(state,accounts[10],'customer',id,true);
 const html=render(ContractsWorkspace,{state,account:accounts[8],record:id,page:'agreements'});
 assert.match(html,/Basisovereenkomst accepteren/);assert.match(html,/online akkoord/);assert.ok(!html.includes('Ondertekende PDF aanleveren'));
 assert.ok(!render(ContractsWorkspace,{state,account:{...accounts[8],role:'KLANT GEBRUIKER'},record:id,page:'agreements'}).includes('Basisovereenkomst accepteren'));
 state=c.acceptBaseContract(state,accounts[8],'customer',id,version,true);
 const accepted=render(ContractsWorkspace,{state,account:accounts[8],record:id,page:'agreements'});
 assert.match(accepted,/Acceptatiebewijs/);assert.match(accepted,/oudere contractversie is vastgelegd/);assert.ok(!accepted.includes('Basisovereenkomst accepteren'));
});

test('request and commercial forms expose needed working days and all expected cost inputs',()=>{
 const request=render(PortalFormContent,{account:accounts[8],modal:{kind:'request'}});
 assert.match(request,/Benodigde werkdagen en werktijden/);assert.ok(!request.includes('Gewenste werkdagen en tijden'));
 const order=render(PortalFormContent,{account:accounts[10],modal:{kind:'order',projectId:'p1'}});
 for(const label of ['Verwacht totaal excl. btw','Verwacht totaal incl. toepasselijke btw','Btw-behandeling','Verwachte reiskosten','Verwachte toeslagen']) assert.ok(order.includes(label),label);
});

test('offer and question actions are directly visible on the customer’s project and request with orange badges',async()=>{
 const w=await import('../lib/workflows.ts'),{reviewRequest}=await import('../lib/portal.ts'),{ActionCenter}=await import('../components/portal/action-center.tsx');
 let state=reviewRequest(portalSeed(),accounts[10],'rq-new','accept','');const p=state.projects[0],g=state.agreements.find(g=>g.customerId===p.customerId);
 state=w.createOrder(state,accounts[10],{requestId:'rq-new',projectId:p.id,party:'customer',customerId:p.customerId,dates:['2026-10-12'],start:'07:00',end:'16:00',breakMinutes:60,expectedHoursPerDay:8,rateCents:12500,unit:'uur',vat:'21',supplements:'Geen',travel:'Geen',billing:'Volgens afspraak',cancellation:'Volgens contract',notes:'Test',agreementId:g.id,agreementVersion:1,assignmentIds:[]});const id=state.orders[0].id;state=w.shareOrder(state,accounts[10],id);
 const project=render(ProjectWorkspace,{state,account:accounts[8],record:p.id,page:'projects'}),request=render(RequestWorkspace,{state,account:accounts[8],record:'rq-new',page:'requests'}),list=render(ProjectWorkspace,{state,account:accounts[8],page:'projects'});
 for(const html of [project,request]){assert.ok(html.includes('Opdrachtbevestiging bekijken en accepteren'));assert.ok(html.includes('action-center'));}
 assert.ok(list.includes('needs-action-badge'));assert.ok(list.includes('Akkoord nodig'));
 assert.ok(!render(ActionCenter,{state,account:accounts[9]}).includes('Opdrachtbevestiging bekijken en accepteren'));
 const offer=render(OrdersWorkspace,{state,account:accounts[8],record:id,page:'orders'});assert.ok(offer.includes('offer-sheet'));assert.ok(offer.includes('Ik accepteer de opdracht'));assert.ok(offer.includes('algemene voorwaarden'));assert.ok(!offer.includes('Wacht op mailkoppeling'));
 state=w.respondOrder(state,accounts[8],id,1,'accept','',true);
 const waiting=render(OrdersWorkspace,{state,account:accounts[8],record:id,page:'orders'});assert.ok(waiting.includes('definitieve bevestiging volgt per mail'));assert.ok(!waiting.includes('Definitieve opdrachtbevestiging per mail verstuurd'));
 state=w.completeOrderByMail(state,accounts[10],id,1,'werkelijk@example.test',new Date().toISOString(),true,'Test');
 const sent=render(OrdersWorkspace,{state,account:accounts[8],record:id,page:'orders'});assert.ok(sent.includes('Definitieve opdrachtbevestiging per mail verstuurd'));assert.ok(sent.includes('werkelijk@example.test'));
});

test('HR can upload both pre-signed contract types and manage company data without a repeated signature wizard',()=>{
 const home=render(ContractsWorkspace,{account:accounts[10],page:'agreements'});for(const label of ['Klantovereenkomst uploaden','ZZP-overeenkomst uploaden','Gegevens InfraNexus'])assert.ok(home.includes(label),label);
 for(const modal of [{kind:'agreement-new',customerId:'c1'},{kind:'cooperation',professionalId:'pro2'}]){
  const html=render(PortalFormContent,{account:accounts[10],modal});for(const label of ['Vooraf ondertekende raamovereenkomst','Ondertekend op','Algemene voorwaarden','Ondertekende overeenkomst opslaan'])assert.ok(html.includes(label),label);
  assert.ok(!html.includes('Basisvoorwaarden *'));assert.ok(!html.includes('Conceptovereenkomst opslaan'));
 }
 const company=render(PortalFormContent,{account:accounts[10],modal:{kind:'company-details',customerId:'c1'}});for(const label of ['KvK-nummer','Btw-nummer','Contactpersoon'])assert.ok(company.includes(label));
 const extension=render(PortalFormContent,{account:accounts[8],modal:{kind:'request',projectId:'p1'}});assert.ok(extension.includes('Opnieuw uploaden is niet vereist'));
});

test('account setup and signed contract uploads expose editable company identifiers to HR and supervisors',()=>{
 for(const account of [accounts[10],{role:'SUPERVISOR',name:'Toezicht',initials:'TZ'}]){
  const list=render(AccountsWorkspace,{account,page:'accounts'});assert.match(list,/Account inrichten/);assert.match(list,/Gegevens wijzigen/);assert.match(list,/Contract uploaden/);
  for(const modal of [{kind:'account-new'},{kind:'agreement-new',customerId:'c1'},{kind:'cooperation',professionalId:'pro2'}]){
   const html=render(PortalFormContent,{account,modal});for(const label of ['KvK-nummer','Btw-nummer','Contactpersoon'])assert.ok(html.includes(label),label);
  }
 }
});

test('customer contract page explains the signed framework, offers uploads for review and scopes pending submissions',async()=>{
 const {submitCustomerContract}=await import('../lib/contracts.ts'),{demoPdf}=await import('../lib/portal.ts');
 let state=portalSeed();const file=demoPdf('Klantupload voor controle',['Fictief testbestand']);state=submitCustomerContract(state,accounts[8],{file,from:'2026-01-01',until:'2029-12-31',signedOn:'2026-01-01'});
 const html=render(ContractsWorkspace,{state,account:accounts[8],page:'agreements'});assert.match(html,/Hier staat je ondertekende hoofdraamovereenkomst/);assert.match(html,/Overeenkomst aanleveren/);assert.match(html,/Ter controle/);assert.ok(!html.includes('HR uploadt de al ondertekende PDF'));assert.ok(!html.includes('Deze conceptomgeving registreert akkoord lokaal'));
 const pending=render(ContractsWorkspace,{state,account:accounts[8],page:'agreements',record:state.contractSubmissions[0].id});assert.match(pending,/nog niet actief/);assert.ok(!pending.includes('Goedkeuren &amp; activeren'));
 const other=render(ContractsWorkspace,{state,account:accounts[9],page:'agreements'});assert.ok(!other.includes('Klantupload voor controle'));
 const form=render(PortalFormContent,{state,account:accounts[8],modal:{kind:'client-contract'}});assert.match(form,/pas actief na goedkeuring/);
});

test('withdrawal is offered before acceptance, rejection is highlighted and removed requests disappear from the customer view',async()=>{
 const {reviewRequest}=await import('../lib/portal.ts'),{withdrawCustomerRequest}=await import('../lib/workflows.ts');let state=portalSeed();
 assert.match(render(RequestWorkspace,{state,account:accounts[8],record:'rq-new',page:'requests'}),/Intrekken of verwijderen/);
 const rejected=reviewRequest(state,accounts[10],'rq-new','reject','Geen capaciteit deze week');const html=render(RequestWorkspace,{state:rejected,account:accounts[8],record:'rq-new',page:'requests'});assert.match(html,/Aanvraag afgewezen/);assert.match(html,/Geen capaciteit deze week/);assert.match(html,/Afwijzing bekijken/);
 const accepted=reviewRequest(state,accounts[10],'rq-new','accept','');assert.ok(!render(RequestWorkspace,{state:accepted,account:accounts[8],record:'rq-new',page:'requests'}).includes('Intrekken of verwijderen'));
 state=withdrawCustomerRequest(state,accounts[8],'rq-new',true,'Niet meer nodig');assert.ok(!render(RequestWorkspace,{state,account:accounts[8],page:'requests'}).includes('Sanering Merwehaven'));assert.match(render(RequestWorkspace,{state,account:accounts[8],record:'rq-new',page:'requests'}),/niet beschikbaar/);
});

test('certificate intake and manual email records have usable upload fields and recipient visibility controls',async()=>{
 const certificate=render(PortalFormContent,{account:accounts[10],modal:{kind:'certificate'}});for(const label of ['Professional voor dit certificaat','Hoe ontvangen?','per e-mail heeft gestuurd','PDF of foto'])assert.ok(certificate.includes(label),label);
 const {MailEvidence}=await import('../components/portal/mail-evidence.tsx');const evidence={body:'Bewaar deze verzonden tekst <script>niet uitvoeren</script>',visibleToRecipient:false,attachments:[]};
 const Component=()=>React.createElement(MailEvidence,{evidence});assert.ok(!render(Component,{account:accounts[8]}).includes('Bewaar deze verzonden tekst'));const internal=render(Component,{account:accounts[10]});assert.match(internal,/Bewaar deze verzonden tekst/);assert.ok(!internal.includes('<script>'));
 const {reviewRequest}=await import('../lib/portal.ts'),w=await import('../lib/workflows.ts');let state=reviewRequest(portalSeed(),accounts[10],'rq-new','accept','');const p=state.projects[0],g=state.agreements.find(g=>g.customerId===p.customerId);
 state=w.createOrder(state,accounts[10],{requestId:'rq-new',projectId:p.id,party:'customer',customerId:p.customerId,dates:['2026-10-12'],start:'07:00',end:'16:00',breakMinutes:60,expectedHoursPerDay:8,rateCents:12500,unit:'uur',vat:'21',billing:'Volgens afspraak',cancellation:'Volgens contract',notes:'Test',agreementId:g.id,agreementVersion:1,assignmentIds:[]});const id=state.orders[0].id;state=w.shareOrder(state,accounts[10],id);state=w.respondOrder(state,accounts[8],id,1,'accept','',true);
 const mail=render(PortalFormContent,{state,account:accounts[10],modal:{kind:'order-mail',id}});for(const label of ['Verzonden mailtekst','Meerdere bijlagen toevoegen','De ontvanger mag deze mailtekst'])assert.ok(mail.includes(label),label);
 const waiting=render(OrdersWorkspace,{state,account:accounts[8],record:id,page:'orders'});assert.match(waiting,/InfraNexus verstuurt de definitieve bevestiging/);assert.ok(!waiting.includes('HR verstuurt de definitieve bevestiging'));
});

test('order confirmation uses the requested business terminology and short deviation statement',async()=>{
 const {reviewRequest}=await import('../lib/portal.ts'),w=await import('../lib/workflows.ts');let state=reviewRequest(portalSeed(),accounts[10],'rq-new','accept','');const p=state.projects[0],g=state.agreements.find(g=>g.customerId===p.customerId);
 state=w.createOrder(state,accounts[10],{requestId:'rq-new',projectId:p.id,party:'customer',customerId:p.customerId,dates:['2026-10-12'],start:'07:00',end:'16:00',breakMinutes:60,expectedHoursPerDay:8,rateCents:12500,unit:'uur',vat:'21',billing:'Volgens afspraak',cancellation:'Volgens contract',notes:'Test',agreementId:g.id,agreementVersion:1,assignmentIds:[]});state=w.shareOrder(state,accounts[10],state.orders[0].id);
 const html=render(OrdersWorkspace,{state,account:accounts[8],record:state.orders[0].id,page:'orders'});for(const label of ['OPDRACHTBEVESTIGING','hoofdraamovereenkomst','per e-mail van InfraNexus','De verwachte inzet kan afwijken'])assert.ok(html.includes(label),label);
 for(const old of ['OFFERTE / OPDRACHT','offerte / opdracht','mail van HR','HR stuurt de definitieve','factureerbare en verschuldigde uren'])assert.ok(!html.includes(old),old);
});

test('daily file drive and update form expose every attachment, photos, notes and retained files',async()=>{
 const w=await import('../lib/workflows.ts'),{demoPdf}=await import('../lib/portal.ts'),{DailyLogDetail}=await import('../components/portal/log-drive.tsx');let state=portalSeed();state.assignments.push({id:'render-bundle',projectId:'p1',professionalId:'pro2',date:'2026-10-02',role:'DLP',start:'07:00',end:'16:00',status:'Bevestigd'});
 state=w.saveDayLog(state,accounts[7],'p1','pro2','2026-10-02',[{id:'render-pdf',category:'Daglogboek',file:demoPdf('Dagboek compleet',['Test'])},{id:'render-photo',category:'Foto',caption:'Werkvak B',file:{name:'Foto werkvak.jpg',mime:'image/jpeg',size:3,url:'data:image/jpeg;base64,YWJj'}}],'',{activities:'Bodemwerk uitgevoerd',materials:'Transport T123'});const log=state.filledLogs[0];
 const detail=render(()=>React.createElement(DailyLogDetail,{id:log.id}),{state,account:accounts[10]});for(const value of ['Foto werkvak.jpg','Dagboek compleet','Bodemwerk uitgevoerd','Transport T123','alle bestanden en foto'])assert.ok(detail.includes(value),value);
 const form=render(PortalFormContent,{state,account:accounts[7],modal:{kind:'day-log',projectId:'p1',professionalId:'pro2',date:'2026-10-02'}});for(const value of ['Bestanden in deze dagversie','Dagboek compleet','Foto werkvak.jpg','Grondstromen en transportreferenties','multiple=""'])assert.ok(form.includes(value),value);
 const {LogFileDrive}=await import('../components/portal/log-drive.tsx');const drive=render(LogFileDrive,{state,account:accounts[10],page:'logs'});assert.ok(drive.includes('drive-folder'));assert.ok(drive.includes('Dagdossier openen'));
});

test('template library scopes company files and allows an explicit project exception',async()=>{
 const {publishCompanyTemplate}=await import('../lib/log-files.ts'),{demoPdf}=await import('../lib/portal.ts'),{LogTemplateLibrary}=await import('../components/portal/log-drive.tsx');let state=publishCompanyTemplate(portalSeed(),accounts[10],'c1',demoPdf('Klantstandaard',['Test']),'Delta standaard');
 state=publishCompanyTemplate(state,accounts[10],'c2',demoPdf('Andere klant geheim',['Test']),'Noordlijn standaard');const Component=()=>React.createElement(LogTemplateLibrary,{});
 const own=render(Component,{state,account:accounts[8]});for(const value of ['Delta standaard','Bedrijfssjabloon toevoegen','Projectsjabloon toevoegen'])assert.ok(own.includes(value),value);assert.ok(!own.includes('Andere klant geheim'));
 const form=render(PortalFormContent,{state,account:accounts[10],modal:{kind:'template',customerId:'c1'}});assert.ok(form.includes('Toepassing sjabloon'));assert.ok(form.includes('Bedrijfssjabloon')||form.includes('bedrijfssjabloon'));
});

test('multiple mail attachments and professional VAT data are visible while medical documents stay in the private dossier',async()=>{
 const {FilesPicker}=await import('../components/portal/files-picker.tsx');const picker=render(()=>React.createElement(FilesPicker,{files:[{name:'Bijlage1.pdf',size:50,lastModified:1},{name:'Bijlage2.pdf',size:50,lastModified:2}],onChange:noop}));assert.ok(picker.includes('multiple=""'));assert.ok(picker.includes('2 bestanden geselecteerd'));assert.ok(picker.includes('Bijlage2.pdf verwijderen uit selectie'));
 let state=portalSeed();state.professionals=state.professionals.map(p=>p.id==='pro2'?{...p,vatNumber:'NL123456789B01'}:p);const form=render(PortalFormContent,{state,account:accounts[10],modal:{kind:'professional',professionalId:'pro2'}});assert.ok(form.includes('Btw-nummer'));assert.ok(form.includes('NL123456789B01'));
 state.certificateSubmissions.unshift({id:'medical-render',professionalId:'pro2',type:'Medische keuring bodemsanering C',issuer:'Arbodienst',achieved:'2026-01-01',expiry:'2027-01-01',name:'Geschiktheidsverklaring.pdf',url:'data:application/pdf;base64,YWJj',mime:'application/pdf',status:'Goedgekeurd',submittedAt:'2026-10-02'});
 const medical=render(CertificateWorkspace,{state,account:accounts[10],record:'medical-render',page:'checks'});assert.ok(medical.toLowerCase().includes('medische onderzoeksresultaten'));assert.ok(!medical.includes('Dit gecontroleerde bewijs delen met klanten'));
 const planner=render(CertificateWorkspace,{state,account:accounts[2],record:'medical-render',page:'checks'});assert.ok(!planner.includes('Geschiktheidsverklaring.pdf'));
});
