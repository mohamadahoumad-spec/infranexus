import test from 'node:test';
import assert from 'node:assert/strict';
import {accounts} from '../lib/demo.ts';
import {portalSeed,reviewRequest,hydratePortal,demoPdf} from '../lib/portal.ts';
import {certificateTypes,uploadCertificate,customerCertificates,publishTemplate,reviewFilledLog,visibleFilledLogs} from '../lib/operations.ts';
import {reviewCertificate} from '../lib/professional.ts';
import {publishCompanyTemplate,templatesForProject,logFiles} from '../lib/log-files.ts';
import {registerSignedBase,contractEmailDraft} from '../lib/contracts.ts';
import {orderDeclaration} from '../lib/contract-utils.ts';
import * as w from '../lib/workflows.ts';
const hr=accounts[10],planner=accounts[2],customer=accounts[8],other=accounts[9],pro=accounts[7];
const file=demoPdf('Test daglogboek',['Fictief testdocument.']);
const photo={name:'Werkvak B.jpg',mime:'image/jpeg',size:3,url:'data:image/jpeg;base64,YWJj'};
const bundle=[{id:'daily-pdf',category:'Daglogboek',file},{id:'photo-b',category:'Foto',file:photo,caption:'Werkvak B bij einde werkdag'}];
function daily(){let s=portalSeed();s.projects=s.projects.map(p=>p.id==='p1'?{...p,start:'2026-09-28',end:'2026-10-02',endTime:'16:00'}:p);s.assignments.push({id:'bundle-day',projectId:'p1',professionalId:'pro2',date:'2026-10-02',role:'DLP',start:'07:00',end:'16:00',status:'Bevestigd'});return s;}
function ready(){let s=reviewRequest(portalSeed(),hr,'rq-new','accept','Gecontroleerd');return registerSignedBase(s,hr,'professional','pro2',file,'2026-01-01','2029-12-31','2026-01-01',true);}
function terms(s,party='customer'){const p=s.projects[0],g=party==='customer'?s.agreements.find(g=>g.customerId===p.customerId):s.cooperations[0];return {requestId:'rq-new',projectId:p.id,party,customerId:p.customerId,professionalId:party==='professional'?'pro2':undefined,dates:['2026-10-12'],start:'07:00',end:'16:00',breakMinutes:60,expectedHoursPerDay:8,rateCents:party==='customer'?12500:6800,unit:'uur',vat:'21',supplements:'Geen',travel:'Geen',billing:'Wekelijks',cancellation:'Conform raamovereenkomst',notes:'Test',agreementId:g.id,agreementVersion:g.versions.at(-1).version,assignmentIds:[]};}
function customerReady(){let s=ready();s=w.createOrder(s,hr,terms(s));const id=s.orders[0].id;s=w.shareOrder(s,hr,id);s=w.respondOrder(s,customer,id,1,'accept','',true);return w.completeOrderByMail(s,hr,id,1,'klant@example.test',new Date().toISOString(),true,'Test');}

test('medical A/B and C evidence has separate types, explicit review and no raw customer document sharing',()=>{
 let s=portalSeed();for(const type of ['Medische keuring bodemsanering A/B','Medische keuring bodemsanering C']){
  assert.ok(certificateTypes.includes(type));s=uploadCertificate(s,{...pro,professionalId:'pro1'},{professionalId:'pro1'},{type,issuer:'Test arbodienst',achieved:'2026-01-01',expiry:'2027-01-01',file});const id=s.certificateSubmissions[0].id;
  assert.equal(s.certificateSubmissions[0].status,'Controle nodig');s=reviewCertificate(s,hr,id,true,'Verklaring categorie en geldigheid gecontroleerd');
  s.certificateSubmissions=s.certificateSubmissions.map(c=>c.id===id?{...c,sharedWithCustomer:true}:c);assert.ok(!customerCertificates(s,customer,'p1').some(c=>c.id===id));
 }assert.ok(s.professionals.find(p=>p.id==='pro1').certificates.some(c=>c.type.includes('bodemsanering C')&&c.verified));
});

test('company templates apply across the customer’s projects, while a project override wins and other customers cannot upload',()=>{
 let s=portalSeed();s.logTemplates=[];s=publishCompanyTemplate(s,customer,'c1',file,'Bedrijfsstandaard');const company=s.logTemplates[0];
 s.projects.push({...s.projects.find(p=>p.id==='p1'),id:'future-project',name:'Later project'});assert.equal(templatesForProject(s,'future-project')[0].id,company.id);assert.equal(templatesForProject(s,'p1')[0].id,company.id);
 assert.ok(!templatesForProject(s,s.projects.find(p=>p.customerId==='c2').id).some(t=>t.id===company.id));assert.throws(()=>publishCompanyTemplate(s,other,'c1',file),/eigen klant/);
 s=publishTemplate(s,customer,'p1',{...file,name:'Projectafwijking.pdf'});assert.equal(templatesForProject(s,'p1')[0].scope,'project');assert.equal(templatesForProject(s,'future-project')[0].scope,'company');
});

test('daily bundle saves files, photos and notes as one immutable reviewed version and a replacement reopens review',()=>{
 let s=daily();s.logTemplates=[];s=publishCompanyTemplate(s,hr,'c1',file);const template=s.logTemplates[0].id;
 s=w.saveDayLog(s,pro,'p1','pro2','2026-10-02',bundle,template,{workArea:'B',activities:'Grondwerk',measurements:'Monster M1',deviations:'Geen afwijkingen'});const id=s.filledLogs[0].id;
 assert.equal(logFiles(s.filledLogs[0].versions[0]).length,2);assert.equal(s.filledLogs[0].versions[0].templateId,template);assert.equal(visibleFilledLogs(s,customer).filter(l=>l.id===id).length,0);
 s=reviewFilledLog(s,hr,id,true,'Gehele dagversie gecontroleerd');s=w.shareWeek(s,hr,'p1','2026-W40');const week=s.weeklyLogs[0];assert.equal(w.weeklyCurrent(s,week),true);
 s=w.saveDayLog(s,planner,'p1','pro2','2026-10-02',[bundle[0],{...bundle[1],id:'photo-c',file:{...photo,name:'Correctie.jpg'}}],template,{activities:'Bijgewerkt'});
 const versions=s.filledLogs[0].versions;assert.equal(versions[0].files[1].file.name,'Werkvak B.jpg');assert.equal(versions[0].status,'Goedgekeurd');assert.equal(versions[1].status,'Ingediend');assert.equal(w.weeklyCurrent(s,week),false);assert.equal(visibleFilledLogs(s,customer).filter(l=>l.id===id).length,0);
});

test('daily file updates enforce assignment, ownership, template scope, file type and atomic limits',()=>{
 let s=daily();s=publishCompanyTemplate(s,hr,'c2',file);const wrong=s.logTemplates[0].id;
 assert.throws(()=>w.saveDayLog(s,customer,'p1','pro2','2026-10-02',bundle),/Alleen/);assert.throws(()=>w.saveDayLog(s,pro,'p1','pro1','2026-10-02',bundle),/eigen professional/);
 assert.throws(()=>w.saveDayLog(s,pro,'p1','pro2','2026-10-02',bundle,wrong),/sjabloon/);assert.throws(()=>w.saveDayLog(s,pro,'p1','pro2','2026-10-02',[]),/ten minste/);
 assert.throws(()=>w.saveDayLog(s,pro,'p1','pro2','2026-10-02',[{...bundle[0],file:{...file,mime:'text/html'}}]),/PDF/);
 assert.throws(()=>w.saveDayLog(s,pro,'p1','pro2','2026-10-02',[{...bundle[0],file:{...file,size:11*1024*1024}}]),/10 MB/);assert.equal(s.filledLogs.length,0);
});

test('weekly mail exports all approved photos and documents plus day notes, excludes pending additions and preserves the exact snapshot',()=>{
 let s=w.saveDayLog(daily(),pro,'p1','pro2','2026-10-02',bundle,'',{workArea:'B',activities:'Afgegraven werkvak',materials:'Transportreferentie T1'});const id=s.filledLogs[0].id;s=reviewFilledLog(s,hr,id,true,'Compleet');s=w.shareWeek(s,hr,'p1','2026-W40');const week=s.weeklyLogs[0];
 const files=w.projectMailFiles(s,week);assert.ok(files.some(f=>f.name===photo.name));assert.ok(files.some(f=>f.name===file.name));assert.ok(files.some(f=>f.name.startsWith('Dagregistratie')));const eml=w.emailDraft(s,week);assert.match(eml,/Content-Type: image\/jpeg/);assert.match(eml,/Werkvak B.jpg/);
 s=w.respondWeek(s,customer,week.id,true,'Ontvangen');s=w.markProjectMailSent(s,hr,week.id,'klant@example.test',new Date().toISOString(),true,'Test');const original=s.deliveries[0].files;
 s=w.saveDayLog(s,pro,'p1','pro2','2026-10-02',[{...bundle[0],file:{...file,name:'Nog niet gecontroleerd.pdf'}}]);assert.equal(w.weeklyCurrent(s,week),false);assert.deepEqual(s.deliveries[0].files,original);assert.ok(!w.emailDraft(s,week).includes('Nog niet gecontroleerd.pdf'));
});

test('verified retention purge removes every attachment in every daily version, including photos',()=>{
 let s=w.saveDayLog(daily(),pro,'p1','pro2','2026-10-02',bundle);s=reviewFilledLog(s,hr,s.filledLogs[0].id,true,'Compleet');s=w.shareWeek(s,hr,'p1','2026-W40');const week=s.weeklyLogs[0];s=w.respondWeek(s,customer,week.id,true,'');s=w.queueWeekDelivery(s,hr,week.id);const id=s.deliveries[0].id;s=w.setRetention(s,hr,'c1','Na aflevering verwijderen');
 assert.throws(()=>w.purgeDeliveredWeek(s,hr,id),/mailaflevering/);s=w.acknowledgeDelivery(s,id,{verified:true,providerId:'fictief-test-event',deliveredAt:new Date().toISOString()});s=w.purgeDeliveredWeek(s,hr,id);
 assert.equal(s.filledLogs[0].versions[0].file.url,'');assert.ok(logFiles(s.filledLogs[0].versions[0]).every(f=>f.file.url===''&&f.file.size===0));
});

test('professional confirmation automatically carries the project V&G snapshot without customer prices or HR files',()=>{
 let s=customerReady(),p=s.projects[0],vg=s.documents.find(d=>d.projectId===p.id&&d.type==='V&G-plan');assert.ok(vg);s=w.offerWork(s,planner,terms(s,'professional'));const id=s.orders[0].id,v=s.orders[0].versions[0];assert.equal(v.projectFiles[0].url,vg.url);
 s.documents=s.documents.map(d=>d.id===vg.id?{...d,url:'data:application/pdf;base64,bmV3',name:'Later V&G.pdf'}:d);s=w.respondOrder(s,pro,id,1,'accept','',true);const mail=s.contractMails.find(m=>m.recordId===id);
 assert.ok(mail.files.some(f=>f.url===vg.url));assert.ok(!mail.files.some(f=>f.name==='Later V&G.pdf'));assert.ok(!mail.files.some(f=>f.name.startsWith('OPD-')));assert.match(contractEmailDraft(mail),/Content-Disposition: attachment/);
});

test('manual mail drafts combine several saved and newly selected attachments without registering a send',()=>{
 let s=customerReady();const id=s.orders[0].id;s=w.appendManualMailEvidence(s,hr,'opdracht',id,1,{body:'Verzonden bericht',attachments:[file,photo],visibleToRecipient:true});s=w.appendManualMailEvidence(s,hr,'opdracht',id,1,{attachments:[{...photo,name:'Tweede fotoreferentie.jpg'}]});assert.equal(s.contractMails.find(m=>m.recordId===id).manual.attachments.length,3);const mail=s.contractMails.find(m=>m.recordId===id),before=JSON.stringify(s);
 const third={name:'Extra meetstaat.csv',mime:'text/csv',size:3,url:'data:text/csv;base64,YWJj'},eml=contractEmailDraft(mail,{attachments:[third,photo],body:'Concept met alle bestanden'});
 for(const name of [file.name,photo.name,third.name])assert.ok(eml.includes(name),name);assert.equal(eml.split('filename="Werkvak B.jpg"').length-1,1);assert.match(eml,/Concept met alle bestanden/);assert.equal(JSON.stringify(s),before);
});

test('order terminology changes notifications and future consent without rewriting prior acceptance evidence',()=>{
 let s=portalSeed();s.notifications.unshift({id:'old-order-notice',title:'Akkoord nodig: offerte / opdracht',body:'offerte / opdracht',audience:'customer',customerId:'c1',target:'meldingen',read:false});
 const original=customerReady().orders[0];original.versions[0].acceptance.declaration='Oorspronkelijk akkoord op offerte / opdracht';s.orders=[original];const next=hydratePortal(s);
 assert.equal(next.notifications[0].title,'Akkoord nodig: opdrachtbevestiging');assert.equal(next.orders[0].versions[0].acceptance.declaration,'Oorspronkelijk akkoord op offerte / opdracht');assert.ok(!orderDeclaration.includes('offerte'));assert.match(orderDeclaration,/hoofdraamovereenkomst/);assert.match(orderDeclaration,/kunnen lezen en opslaan/);
});
