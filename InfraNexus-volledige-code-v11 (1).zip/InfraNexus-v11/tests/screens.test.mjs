import test from 'node:test';
import assert from 'node:assert/strict';
import React from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {seed,accounts} from '../lib/demo.ts';
import {InfraContext} from '../components/infra-context.tsx';
import {SidebarProvider} from '../components/ui/sidebar.tsx';
import {ProfessionalViews} from '../components/professional-portal.tsx';
import {OperationsForm} from '../components/operations-forms.tsx';
import {RequestWorkspace,ChatWorkspace,FinanceWorkspace,BrandingWorkspace,LogDocuments,CertificatePanel} from '../components/operations-screens.tsx';
import {CandidateDetail,ProfessionalDetail,ProjectDetail} from '../components/infra-screens.tsx';
const noop=()=>{};
function render(component,{account=accounts[0],view='dashboard',detail=null,modal=null}={}){const context={state:seed(),account,view,detail,modal,go:noop,setModal:noop,change:noop};return renderToStaticMarkup(React.createElement(InfraContext.Provider,{value:context},React.createElement(SidebarProvider,null,component)));}
test('all professional destinations render without errors and show no direct customer telephone links',()=>{
 for(const view of ['dashboard','planning','projecten','logboeken','documenten','kwalificaties','academy','profiel','meldingen','beschikbaarheid','financieel','chat']){const html=render(React.createElement(ProfessionalViews),{account:accounts[6],view});assert.ok(html.length>300,view);assert.ok(!html.includes('href="tel:'),view);}
 const project=render(React.createElement(ProfessionalViews),{account:accounts[6],view:'projecten',detail:{type:'project',id:'p1'}});assert.match(project,/InfraNexus Planning/);assert.ok(!project.includes('href="tel:'));
});
test('new HR, client and finance screens render with existing records',()=>{
 for(const account of [accounts[0],accounts[8],accounts[10],accounts[4]])for(const Component of [RequestWorkspace,ChatWorkspace,FinanceWorkspace,LogDocuments])assert.ok(render(React.createElement(Component),{account}).length>300);
 assert.match(render(React.createElement(BrandingWorkspace)),/Huisstijl/);
 for(const [Component,id] of [[CandidateDetail,'k1'],[ProfessionalDetail,'pro1'],[ProjectDetail,'p1']])assert.ok(render(React.createElement(Component,{id})).length>300);
});
test('new forms render and candidate form contains HR fields without V&G job role',()=>{
 const html=render(React.createElement(OperationsForm,{type:'candidate'}),{modal:{type:'candidate'}});assert.match(html,/Telefoonnummer/);assert.match(html,/KvK-nummer/);assert.match(html,/CV voor het HR-dossier/);assert.ok(!html.includes('V&amp;G'));
 for(const type of ['assignment','request','certificate-upload','staff-file','invoice-create'])assert.ok(render(React.createElement(OperationsForm,{type}),{modal:{type,professionalId:'pro1'}}).length>300);
});
